// SPDX-License-Identifier: GPL-3.0-only
// Host stand-ins for the game's libm PLTs used by the FlyX planner (tests only).
#include <math.h>
float spiral_flyx_sin(float angle) { return sinf(angle); }
float spiral_flyx_cos(float angle) { return cosf(angle); }
float spiral_flyx_sqrt(float value) { return sqrtf(value); }
