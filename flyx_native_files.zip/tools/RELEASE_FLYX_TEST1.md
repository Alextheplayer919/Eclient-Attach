## Minecraft FlyX v1.0.7-test1 — Up H / Up V, no anti-lagback

**Adds native FlyX under Movement**, with **Up H Factor** and **Up V Factor**. FlyX starts **OFF** and both factors start at **1.00×** every launch. AutoTotem test2 remains under **Combat**, also default OFF. All original module implementations/defaults are retained.

- **Original FlyX speeds unchanged:** `2.42 / 1.62 / 1.1585 / 1.086 / 2.18 / 1.42 / 1.09 / 1.05 / -0.1266 / 0.09 / 4.2997 / 1.1`.
- Horizontal movement uses analog input relative to the **current yaw**, with normalized diagonals and the original horizontal smoothing/release behavior. Partial stick input stays partial rather than snapping to eight directions.
- **Up H Factor** scales horizontal movement only while ascending (jumping, not sneaking). **Up V Factor** scales upward lift, not glide or descent. Both sliders run from **0.10× to 2.00×**. Leave both at **1.00×** for unchanged original speeds.
- **No anti-lagback envelope, 3D speed clamp, climb cap, climb pulse or server-correction handling added.** The original alternating moving descent remains; it is not a new anti-lagback planner.

This is an exact-build **native Minecraft integration**, not a relay APK or source-only feature. It chains the two already-owned GUI/alive-tick callsites into a compiled ARM64 helper, forwards the unchanged AutoTotem/original tick exactly once, reads the native input component without constructing one, and applies velocity through the original LocalPlayer slot 23 setter. The native zero/raw-axis fallback is preserved through the game's read-only vector helper. There are no new Minecraft hooks, saved-trampoline writes, ability/privilege grants, raw position writes, packet injections or authentication changes.

The complete **1,536-byte AutoTotem test2 helper** is byte-identical. Its empty-offhand-only, 36-slot, 100 ms native-inventory behavior and GUI visibility fix remain. ChatSpammer, PopCounter and Kiwi KaX are still parked.

The app remains **Minecraft**, `com.mojang.minecraftpe`, version `1.21.114.1`, with matching original signer, unchanged icons/resources/manifest/all DEX/game libraries and all other assets. The classic header, small caps, enlarged charcoal/white GUI and **red → purple → blue → green** outlines (2 seconds per color) remain:

**The Spiral Client V1 MCPE 1.21.114 (by shrimp)**

### Validation and limits

Automated gates compile/reproduce the frozen native helper, run 123 unit tests including the real C motion planner, check the whole original Android game ELF/RTTI/native input and setter windows, and execute installed ARM64 GUI/tick/component/raw-vector/collision/native-velocity paths across 3 ASLR bases and 3 page sizes. They check default OFF, original tick/AutoTotem forwarding, input priority, current-vs-previous yaw, generation rejection, factors, lifecycle resets, all eight GUI categories with both suspension states, and unchanged Combat AutoTotem. Preserved AutoTotem inventory action/queue paths and older GUI/RGB/font checks run independently. The signed APK audit requires **every other original payload byte-identical**, and reverses FlyX exactly to AutoTotem test2.

**This build introduces one appended read/execute-only engine LOAD and a self-mapped relocated program-header table. All old LOAD descriptors and ELF sections remain exact, no new import/library or writable-executable mapping is introduced, and private FlyX state is 72 bytes of separate existing RW zero-fill. Android startup with this new layout has not been tested on a phone.**

**Emulation is not phone/game/server validation:** registry/world/input objects, libm/clock/original-tick endpoints and UI widgets are controlled fixtures. Preserved inventory emulation also models NBT/ItemStack internals, ECS bookkeeping, complex-action aggregation and final transport. **Real touch/joystick flight, Android startup, real AutoTotem equip/pop, and server acceptance remain unverified.** This is an experimental test build, not a claim that any server accepts the movement.

### Please test safely

Back up worlds and update normally. **Do not clear data/cache or delete worlds.** If Android reports a signature conflict, stop and back up worlds/data before considering uninstalling.

1. Launch normally; confirm the original GUI/modules and Combat → AutoTotem still appear.
2. In a disposable world, test **Movement → FlyX by itself**, with both factors at **1.00×** first.
3. Check forward/back/strafe at different view angles, analog/diagonal turns, release-to-stop, ascent and descent. Then try the two factors separately.
4. Check disabling, death/respawn, world changes and background/resume. Restart should return FlyX and AutoTotem to OFF, factors to 1.00×.
5. Report any crash, missing control, wrong direction or lagback. No anti-lagback has been added.

Retained rollback downloads:
- [AutoTotem test2](https://github.com/shrimpoiddd/Dc4/releases/download/Minecraft_AutoTotem_v1.0.6-test2/Minecraft.apk)
- [RGB GUI v1.0.5](https://github.com/shrimpoiddd/Dc4/releases/download/Minecraft_GUI_v1.0.5/Minecraft.apk)
- [Phone-confirmed GUI base v1.0.2](https://github.com/shrimpoiddd/Dc4/releases/download/Minecraft_GUI_Base_v1.0.2/Minecraft.apk)
