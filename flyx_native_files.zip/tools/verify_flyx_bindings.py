#!/usr/bin/env python3
"""Require exact Android FlyX read-only input bindings and native motion setter.

Release CI uses --game (whole SHA-checked ELF). --pages is local recovery only.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
import build_flyx as fx
from verify_autototem_bindings import GameCode

PROFILE = json.loads((fx.ROOT / 'bundle/native/flyx_bindings.json').read_text())


def verify(code):
    if PROFILE['game_sha256'] != fx.at.GAME_SHA256:
        raise ValueError('wrong FlyX game profile')
    decoder, windows = Cs(CS_ARCH_ARM64, CS_MODE_ARM), []
    for f in PROFILE['native_functions']:
        address = int(f['rva'], 16)
        data = code.read(address, f['bytes'])
        if hashlib.sha256(data).hexdigest() != f['sha256']:
            raise ValueError('native FlyX function window differs: ' + f['name'])
        windows.append({'rva': f['rva'], 'name': f['name'], 'sha256_matches': True})
    table = int(PROFILE['localplayer_vtable_rva'], 16)
    if code.pointer(table + 23 * 8) != 0xc94c3f0 or code.pointer(table - 8) != 0x10037288:
        raise ValueError('LocalPlayer RTTI or velocity setter slot differs')
    if code.read(0xc94c3f0, 24).hex() != '080441f9290840b92a0040f9092100b90a0d00f9c0035fd6':
        raise ValueError('native velocity setter writes something other than StateVector velocity')
    consumer = list(decoder.disasm(code.read(0x660266c, 0x2a0), 0x660266c))
    if not any(i.mnemonic == 'bl' and i.op_str == '#0x9d03e90' for i in consumer):
        raise ValueError('native raw vector fallback caller differs')
    for address, vector in PROFILE['raw_helper_constant_vectors'].items():
        if code.read(int(address, 16), 8).hex() != vector:
            raise ValueError('raw diagonal vector constant differs')
    unset = int(PROFILE['raw_vector_unset_rva'], 16)
    got = int(PROFILE['raw_helper_zero_got_rva'], 16)
    if (code.read(unset, 8).hex() != PROFILE['raw_vector_unset_hex'] or
            code.pointer(got) != int(PROFILE['raw_helper_zero_target_rva'], 16)):
        raise ValueError('native raw vector sentinel/zero GOT differs')
    return {'game_sha256': fx.at.GAME_SHA256, 'input_verification': code.mode,
            'native_function_windows': windows, 'localplayer_slot23_native_velocity_setter': True,
            'logical_motion_58_raw_3c_logical_analog_14_priority': True,
            'raw_zero_falls_back_to_original_pure_raw_state_helper_at_9d03e90': True,
            'jumping_98_sneaking_94_water_auto_jump_99_match_packet_bits_6_8_7': True,
            'no_extra_want_up_jump_down_start_jumping_semantics_added': True,
            'horizontal_collision_is_native_sparse_membership_not_a_payload_field': True,
            'current_actor_yaw_at_rotation_component_plus4_not_previous_plus12': True,
            'nullable_reader_does_not_call_asserting_getter_or_construct_components': True,
            'windows_sdk_used_as_android_layout_proof': False,
            'phone_controller_flight_or_server_acceptance_verified': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument('--game', type=Path)
    source.add_argument('--pages', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    code = GameCode(game=args.game, pages=args.pages)
    try:
        report = verify(code)
    finally:
        code.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
