#!/usr/bin/env python3
"""Execute appended ARM64 FlyX, native nullable lookup peers and motion setter.

Synthetic registry/input/world objects and libm/clock/UI/original-tick endpoints
are explicit models, not a phone/world/server test. Native MoveInput getter,
collision membership, raw-vector helper and lerpMotion instructions are real.
"""
from __future__ import annotations
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import struct

import build_flyx as fx
from inspect_bundle_runtime import Elf64
from test_autototem_gui_route import CombatRoute, RAM, STACK
from verify_autototem_bindings import GameCode
from verify_flyx_bindings import verify as verify_bindings, PROFILE

PLAYER, REGISTRY, BUCKETS, NODES = (RAM + x for x in (0x1000, 0x2000, 0x3000, 0x4000))
POOL, FLAGPOOL, SPARSE, ENTRIES, PAGES = (RAM + x for x in (0x5000, 0x5100, 0x6000, 0x7000, 0x9000))
DATA0, DATA1 = RAM + 0xa000, RAM + 0xf000
FLAGSPARSE, FLAGENTRIES = RAM + 0x15000, RAM + 0x16000
POSITION, ROTATION, WORLD, OUTPUT = RAM + 0x19004, RAM + 0x19100, RAM + 0x20000, RAM + 0x25000
MOVE = DATA1 + 160  # Dense element 129, page 1, element 1 (not a trivial index).
GAME, CAPTURED, RETURN = 0x60000000, 0x1120, 0x1140
ENTITY, PACKED = 0x04000005, 0x04000081
RESULT = 0x11223344fedcba98
NATIVE = {0x6bf1d18: 0xe8, 0xcdf9fb4: 0xb8, 0x9d03e90: 0x118, 0xc94c3f0: 24}


def fbits(value):
    return struct.unpack('<I', struct.pack('<f', value))[0]


class Flight:
    def __init__(self, engine, code, *, base=0, page=4096):
        from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE, UC_HOOK_MEM_WRITE
        from unicorn import UC_PROT_READ, UC_PROT_WRITE, UC_PROT_EXEC, arm64_const as reg
        fx.assert_delta(fx.restore_parent(engine), engine)
        self.cpu, self.reg, self.base = Uc(UC_ARCH_ARM64, UC_MODE_ARM), reg, base
        self.events, self.writes = Counter(), []
        self.now = 1000000000
        c = self.cpu
        for kind, flags, offset, address, _, filesz, memsz, _ in Elf64(engine).segments:
            if kind != 1:
                continue
            start = (base + address) & ~(page - 1)
            end = (base + address + memsz + page - 1) & ~(page - 1)
            c.mem_map(start, end - start)
            c.mem_write(base + address, engine[offset:offset + filesz])
            perm = (UC_PROT_READ if flags & 4 else 0) | (UC_PROT_WRITE if flags & 2 else 0) | (UC_PROT_EXEC if flags & 1 else 0)
            c.mem_protect(start, end - start, perm)
        c.mem_map(RAM, 0x40000)
        mapped = set()
        def map_game(address, size):
            for rva in range(address & ~4095, (address + size + 4095) & ~4095, 4096):
                if rva not in mapped:
                    c.mem_map(GAME + rva, 4096)
                    mapped.add(rva)
        for address, size in NATIVE.items():
            map_game(address, size)
            c.mem_write(GAME + address, code.read(address, size))
        for address in (CAPTURED, RETURN, 0x10036a70, 0x34f189c, 0x105d35f0, 0x2645a00, 0x26451a0):
            map_game(address, 0x100)
        for address in (0x34f189c, 0x2645a00, 0x26451a0):
            c.mem_write(GAME + address, code.read(address, 8))
        self.u64(GAME + 0x105d35f0, GAME + code.pointer(0x105d35f0))
        self.u64(GAME + 0x10036a70 + 23 * 8, GAME + 0xc94c3f0)
        self.u64(base + 0x3b4100, GAME)
        c.mem_write(base + 0x2691a0, b'\0')
        self.u64(PLAYER, GAME + 0x10036a70)
        self.u64(PLAYER + 0x10, REGISTRY)
        self.u32(PLAYER + 0x18, ENTITY)
        self.u64(PLAYER + 0x1d0, WORLD)
        self.u64(PLAYER + 0x208, POSITION)  # Deliberately only 4-byte aligned.
        self.u64(PLAYER + 0x218, ROTATION)
        self.u64(REGISTRY + 0x38, BUCKETS)
        self.u64(REGISTRY + 0x40, BUCKETS + 16 * 8)
        self.u64(REGISTRY + 0x50, NODES)
        self.u64(REGISTRY + 0x58, NODES + 64)
        c.mem_write(BUCKETS, b'\xff' * (16 * 8))
        self.u64(BUCKETS + (0x018b1887 & 15) * 8, 0)
        self.u64(BUCKETS + (0xd5ee0bd8 & 15) * 8, 1)
        for index, hash_, pool in ((0, 0x018b1887, POOL), (1, 0xd5ee0bd8, FLAGPOOL)):
            self.u64(NODES + 32 * index, 0xffffffffffffffff)
            self.u32(NODES + 32 * index + 8, hash_)
            self.u64(NODES + 32 * index + 16, pool)
        self.u64(POOL + 8, SPARSE)
        self.u64(POOL + 16, SPARSE + 8)
        self.u64(SPARSE, ENTRIES)
        self.u32(ENTRIES + (ENTITY & 2047) * 4, PACKED)
        self.u64(POOL + 0x50, PAGES)
        self.u64(POOL + 0x58, PAGES + 16)
        self.u64(PAGES, DATA0)
        self.u64(PAGES + 8, DATA1)
        self.u64(FLAGPOOL + 8, FLAGSPARSE)
        self.u64(FLAGPOOL + 16, FLAGSPARSE + 8)
        self.u64(FLAGSPARSE, FLAGENTRIES)
        self.u32(FLAGENTRIES + (ENTITY & 2047) * 4, 0xffffffff)
        self.axis(0x58, 0, 1)
        c.mem_write(ROTATION, struct.pack('<4f', 0, 0, 0, 137))  # Previous yaw differs.
        c.mem_write(POSITION, struct.pack('<9f', 0, 90, 0, 0, 90, 0, 9, 8, 7))
        c.reg_write(reg.UC_ARM64_REG_SP, STACK)
        c.reg_write(reg.UC_ARM64_REG_CPACR_EL1, 0x300000)
        self.saved = {getattr(reg, 'UC_ARM64_REG_X' + str(n)): 0x1122334400000000 + n for n in range(18, 30)}
        self.saved.update({getattr(reg, 'UC_ARM64_REG_D' + str(n)): 0x1122334400000000 + n for n in range(8, 16)})
        for register, value in self.saved.items():
            c.reg_write(register, value)
        c.hook_add(UC_HOOK_CODE, self.instruction)
        c.hook_add(UC_HOOK_MEM_WRITE, self.write)

    def u64(self, address, value): self.cpu.mem_write(address, struct.pack('<Q', value))
    def u32(self, address, value): self.cpu.mem_write(address, struct.pack('<I', value))
    def x(self, n): return self.cpu.reg_read(getattr(self.reg, 'UC_ARM64_REG_X' + str(n)))
    def s(self, n): return struct.unpack('<f', struct.pack('<I', self.cpu.reg_read(getattr(self.reg, 'UC_ARM64_REG_S' + str(n)))))[0]
    def axis(self, offset, x, y): self.cpu.mem_write(MOVE + offset, struct.pack('<2f', x, y))
    def flag(self, offset, value): self.cpu.mem_write(MOVE + offset, bytes([value]))
    def enabled(self, value=3): self.u32(self.base + fx.STATE, value)
    def motion(self): return struct.unpack('<3f', self.cpu.mem_read(POSITION + 24, 12))
    def ret(self, value=None):
        if value is not None: self.cpu.reg_write(self.reg.UC_ARM64_REG_X0, value)
        self.cpu.reg_write(self.reg.UC_ARM64_REG_PC, self.x(30))

    def instruction(self, cpu, address, size, _):
        rva = address - self.base
        if address == GAME + CAPTURED:
            self.events['original_tick'] += 1
            self.ret(RESULT)
        elif rva == 0x182cb8:
            self.events['clock'] += 1
            self.ret(self.now)
        elif rva in (0x3e430, 0x3d6e0, 0x3e300):
            func = {0x3e430: math.sin, 0x3d6e0: math.cos, 0x3e300: math.sqrt}[rva]
            cpu.reg_write(self.reg.UC_ARM64_REG_S0, fbits(func(self.s(0))))
            self.ret()
        elif address == GAME + 0xc94c3f0:
            self.events['native_velocity_setter'] += 1
        elif address == self.base + 0x2511d8:
            self.events['unchanged_autototem_tick'] += 1
        elif address == GAME + 0x9d03e90:
            self.events['native_raw_input_helper'] += 1

    def write(self, cpu, access, address, size, value, _):
        if not RAM + 0x30000 <= address < STACK:
            self.writes.append((address, size, cpu.reg_read(self.reg.UC_ARM64_REG_PC)))

    def invoke(self, address, *args):
        c, r = self.cpu, self.reg
        c.reg_write(r.UC_ARM64_REG_SP, STACK)
        c.reg_write(r.UC_ARM64_REG_X30, GAME + RETURN)
        for n, value in enumerate(args): c.reg_write(getattr(r, 'UC_ARM64_REG_X' + str(n)), value)
        c.emu_start(address, GAME + RETURN, count=50000)
        if c.reg_read(r.UC_ARM64_REG_PC) != GAME + RETURN or c.reg_read(r.UC_ARM64_REG_SP) != STACK:
            raise ValueError('native helper did not return with balanced stack')
        for register, expected in self.saved.items():
            if c.reg_read(register) != expected: raise ValueError('callee/platform register corrupted')
        return self.x(0)

    def tick(self, player=PLAYER):
        self.events, self.writes = Counter(), []
        self.cpu.reg_write(self.reg.UC_ARM64_REG_X8, GAME + CAPTURED)
        # Execute actual already-owned engine BL, not a direct planner call.
        self.cpu.reg_write(self.reg.UC_ARM64_REG_SP, STACK)
        self.cpu.reg_write(self.reg.UC_ARM64_REG_X0, player)
        self.cpu.emu_start(self.base + fx.at.TICK, self.base + fx.at.TICK + 4, count=50000)
        if self.x(0) != RESULT or self.events['original_tick'] != 1 or self.events['unchanged_autototem_tick'] != 1:
            raise ValueError('captured original/AutoTotem tick not forwarded exactly once with its return bits')
        if self.cpu.reg_read(self.reg.UC_ARM64_REG_SP) != STACK:
            raise ValueError('tick stack imbalance')
        for register, expected in self.saved.items():
            if self.cpu.reg_read(register) != expected: raise ValueError('tick callee/platform register corrupted')
        for address, size, pc in self.writes:
            if POSITION + 24 <= address < POSITION + 36 and not GAME + 0xc94c3f0 <= pc < GAME + 0xc94c408:
                raise ValueError('velocity changed outside original native setter')
            allowed = ((self.base + fx.STATE <= address and address + size <= self.base + fx.STATE + fx.STATE_BYTES) or
                       (POSITION + 24 <= address and address + size <= POSITION + 36))
            if not allowed: raise ValueError('unexpected non-stack game/old-module state write: ' + hex(address))
        return dict(self.events)

    def snapshot(self):
        target = self.base + int(fx.META['symbols']['spiral_flyx_snapshot'], 16)
        result = self.invoke(target, GAME, PLAYER, OUTPUT)
        if not result: return None
        values = struct.unpack('<5f3B', self.cpu.mem_read(OUTPUT, 23))
        return values


class MovementGUI(CombatRoute):
    def __init__(self, engine, **kwargs):
        self.fly_change, self.factor_changes = None, {}
        super().__init__(engine, **kwargs)

    def instruction(self, cpu, address, size, data):
        rva = address - self.base
        if rva == 0x16f9ac:
            label, pointer, fmt = self.text(self.x(0)), self.x(1), self.text(self.x(2))
            lo, hi = [struct.unpack('<f', struct.pack('<I', cpu.reg_read(getattr(self.reg, 'UC_ARM64_REG_S' + str(n)))))[0] for n in (0, 1)]
            if (lo, hi) != (struct.unpack('<f', struct.pack('<f', .1))[0], 2.) or fmt != '%.2fx' or self.x(3) != 0:
                raise ValueError('SliderFloat native ABI/range/format differs')
            if not STACK - 256 <= pointer < STACK: raise ValueError('factor slider not using local mailbox copy')
            value = struct.unpack('<f', cpu.mem_read(pointer, 4))[0]
            change = self.factor_changes.get(label)
            if change is not None: cpu.mem_write(pointer, struct.pack('<f', change))
            self.events.append({'api': 'SliderFloat', 'label': label, 'before': value, 'after': change if change is not None else value})
            self.ret(int(change is not None))
        elif rva == 0x16799c and self.text(self.x(0)) == 'FlyX':
            pointer = self.x(1)
            if not STACK - 256 <= pointer < STACK: raise ValueError('FlyX checkbox not using local mailbox copy')
            if self.fly_change is not None: cpu.mem_write(pointer, bytes([self.fly_change]))
            self.events.append({'api': 'Checkbox', 'label': 'FlyX'})
            self.ret(int(self.fly_change is not None))
        else:
            super().instruction(cpu, address, size, data)


def close(actual, expected, tolerance=1e-5):
    if abs(actual - expected) > tolerance: raise ValueError(f'actual {actual}, expected {expected}')


def verify(engine, code):
    binding_report = verify_bindings(code)
    fx.assert_delta(fx.restore_parent(engine), engine)
    cases = []
    for base in (0, 0x40000000, 0x7000000000):
        for page in (4096, 16384, 65536):
            model = Flight(engine, code, base=base, page=page)
            model.tick(player=0x123)  # OFF forwards without touching invalid game object.
            if model.writes or model.events['clock'] or model.events['native_velocity_setter']:
                raise ValueError('default-OFF FlyX read/planned/wrote movement state')
            component = model.invoke(base + int(fx.META['symbols']['spiral_flyx_component'], 16), PLAYER, 0x018b1887, 160)
            if component != MOVE or model.invoke(GAME + 0x6bf1d18, PLAYER) != MOVE:
                raise ValueError('bounded nullable reader differs from actual native dense lookup')
            if model.invoke(GAME + 0xcdf9fb4, PLAYER + 8) != 0: raise ValueError('native absent collision mismatch')
            model.enabled()
            model.tick()
            close(model.motion()[0], 0)
            close(model.motion()[2], 2.42 * .32)
            if model.events['native_velocity_setter'] != 1: raise ValueError('missing real native velocity setter call')
            model.cpu.mem_write(ROTATION + 4, struct.pack('<f', 90))
            model.enabled(5)
            model.tick()
            close(model.motion()[0], -2.42 * .32)
            close(model.motion()[2], 0)
            # Runtime factors, enable generation, idle gap and world resets.
            model.cpu.mem_write(ROTATION + 4, struct.pack('<f', 0))
            model.flag(0x98, 1)
            model.u32(base + fx.STATE + 4, fbits(1.25))
            model.u32(base + fx.STATE + 8, fbits(.5))
            model.enabled(7)
            model.tick()
            close(model.motion()[2], 1.1585 * 1.25 * .32)
            close(model.motion()[1], -.1266 + 1.086 * .5 * .22)
            first = model.motion()
            model.now += 600000000
            model.tick()
            for a, b in zip(model.motion(), first): close(a, b)
            model.u64(PLAYER + 0x1d0, WORLD + 8)
            model.tick()
            for a, b in zip(model.motion(), first): close(a, b)
            model.enabled(8)
            model.tick(player=0x123)
            if model.writes or model.events['native_velocity_setter']: raise ValueError('disabled feature still changed motion/state')
            model.enabled(9)
            model.flag(0x98, 0)
            model.axis(0x58, 0, 0)
            model.axis(0x3c, .3, .4)
            model.axis(0x14, -.8, .8)
            snap = model.snapshot()
            close(snap[0], .3); close(snap[1], .4)
            model.axis(0x3c, 0, 0)
            model.flag(0x28 + 0xd, 1)
            snap = model.snapshot()
            close(snap[0], 0); close(snap[1], 1)
            if not model.events['native_raw_input_helper']: raise ValueError('native raw zero fallback not executed')
            model.flag(0x28 + 0xd, 0)
            snap = model.snapshot()
            close(snap[0], -.8); close(snap[1], .8)
            model.axis(0x14, float('nan'), float('inf'))
            model.flag(0xf, 1)
            snap = model.snapshot()
            close(snap[0], 1); close(snap[1], 0)
            model.flag(0x96, 1)  # WANT_UP must NOT silently change the active source's ascent semantics.
            if model.snapshot()[5]: raise ValueError('extra ascent flags added')
            model.flag(0x98, 1)
            if not model.snapshot()[5]: raise ValueError('native JUMPING flag not read')
            model.flag(0x99, 1)
            if not model.snapshot()[7]: raise ValueError('native water autojump terrain cap not read')
            model.flag(0x99, 0)
            model.u32(FLAGENTRIES + (ENTITY & 2047) * 4, ENTITY & 0xfffc0000)
            if not model.snapshot()[7] or model.invoke(GAME + 0xcdf9fb4, PLAYER + 8) != 1:
                raise ValueError('collision flag not native sparse membership')
            model.u32(ENTRIES + (ENTITY & 2047) * 4, PACKED ^ 0x40000)
            model.tick()
            if model.events['native_velocity_setter']: raise ValueError('stale-generation input component was used')
            model.u32(ENTRIES + (ENTITY & 2047) * 4, PACKED)
            model.cpu.mem_write(base + 0x2691a0, b'\1')
            model.tick()
            if model.events['native_velocity_setter']: raise ValueError('original suspended gate bypassed')
            gui = MovementGUI(engine, base=base, page=page)
            for suspended in (True, False):
                gui.fly_change, gui.factor_changes = True, {'Up H Factor##FlyX': 1.25, 'Up V Factor##FlyX': .5}
                for category in range(8):
                    events = gui.frame(suspended=suspended, category=category)
                    labels = [e.get('label') for e in events if e['api'] in ('Checkbox', 'SliderFloat')]
                    if any(label in labels for label in ('FlyX', 'Up H Factor##FlyX', 'Up V Factor##FlyX')) != (category == 0):
                        raise ValueError('FlyX controls missing from Movement or leaking into another category')
                    if sum(e['api'] == 'BeginGroup' for e in events) != 1:
                        raise ValueError('original BeginGroup missing or duplicated')
                    if category == 0 and labels != ['FlyX', 'Up H Factor##FlyX', 'Up V Factor##FlyX']:
                        raise ValueError('FlyX checkbox and both factor sliders not visible together')
                    if category == 1 and labels.count('AutoTotem') != 1:
                        raise ValueError('retained Combat AutoTotem row hidden or duplicated')
            h, v = struct.unpack('<2f', gui.cpu.mem_read(base + fx.STATE + 4, 8))
            close(h, 1.25); close(v, .5)
            cases.append({'aslr_base': hex(base), 'page_bytes': page, 'gui_all_8_categories_both_suspend_states': True,
                          'native_input_dense_lookup_raw_flags_collision_and_motion_setter': True})
    return {'scope': 'actual installed ARM64 wrappers + synthetic game objects; libm/clock/UI/original-tick endpoints modelled',
            'cases': cases, 'native_bindings': binding_report, 'default_off_no_game_object_read_or_motion_work': True,
            'original_tick_and_unchanged_autototem_forwarded_once_return_bits_preserved': True,
            'velocity_writes_only_inside_original_native_slot23_setter': True,
            'no_input_position_old_module_auth_or_gameplay_gate_writes': True,
            'native_raw_sentinel_fallback_and_logical_fallback_priority_checked': True,
            'statevector_only_4_byte_alignment_and_distinct_previous_yaw_fixture': True,
            'stale_component_generation_and_suspension_skip_safely': True,
            'movement_checkbox_and_both_factor_slider_native_abi_and_combat_autototem_preserved': True,
            'phone_startup_real_touch_controller_world_flight_or_server_acceptance_verified': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate', type=Path, required=True)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument('--game', type=Path)
    source.add_argument('--pages', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    code = GameCode(game=args.game, pages=args.pages)
    try:
        report = verify(args.candidate.read_bytes(), code)
    finally:
        code.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
