#!/usr/bin/env python3
"""Reproduce the reviewed freestanding ARM64 FlyX helper, without new imports."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

from compile_autototem import FLAGS
from build_gui_base import sections
from inspect_bundle_runtime import Elf64

ROOT = Path(__file__).resolve().parents[1]


def compile_payload(work, *, zig=None):
    if zig is None:
        import ziglang
        zig = str(Path(ziglang.__file__).parent / 'zig')
    version = subprocess.check_output([str(zig), 'version'], text=True).strip()
    if version != '0.13.0':
        raise ValueError('use pinned ziglang 0.13.0')
    work.mkdir(parents=True, exist_ok=True)
    native = ROOT / 'bundle/native'
    objects = []
    for source in ('flyx_adapter.c', 'flyx_core.c', 'flyx_bindings.c'):
        out = work / (Path(source).stem + '.o')
        subprocess.run([str(zig), 'cc', *FLAGS, '-c', str(native / source), '-o', str(out)], check=True)
        objects.append(str(out))
    veneer = work / 'veneer.o'
    subprocess.run([str(zig), 'cc', '-target', 'aarch64-freestanding-none', '-c', str(native / 'flyx_veneer.S'), '-o', str(veneer)], check=True)
    subprocess.run([str(zig), 'build-exe', '-target', 'aarch64-freestanding-none', '-fno-entry',
                    '-femit-bin=' + str(work / 'payload.elf'), '--script', str(native / 'flyx.ld'),
                    str(veneer), *objects], check=True)
    raw = (work / 'payload.elf').read_bytes()
    inventory = sections(raw)
    section = inventory['.spiral_flyx']
    for name, item in inventory.items():
        if name != '.spiral_flyx' and item[2] & 2 and item[5]:
            raise ValueError('unexpected allocated helper section: ' + name)
        if item[1] in (4, 9) and item[5]:
            raise ValueError('unresolved helper relocation')
    functions = [s for s in Elf64(raw).symbols() if s['type'] == 2]
    symbols = {s['name']: s['rva'] for s in functions}
    sizes = {s['name']: s['size'] for s in functions}
    payload = raw[section[4]:section[4] + section[5]]
    expected = json.loads((native / 'flyx_payload.json').read_text())
    if (payload != bytes.fromhex(expected['hex']) or hashlib.sha256(payload).hexdigest() != expected['sha256'] or
            symbols != expected['symbols'] or sizes != expected['function_bytes'] or hex(section[3]) != expected['entry_rva']):
        raise ValueError('source does not reproduce reviewed FlyX payload')
    from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
    decoder = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
    decoder.detail = True
    for function in functions:
        start = int(function['rva'], 16) - section[3]
        for instruction in decoder.disasm(payload[start:start + function['size']], int(function['rva'], 16)):
            reads, writes = instruction.regs_access()
            if any(instruction.reg_name(r) in ('x18', 'w18') for r in (*reads, *writes)):
                raise ValueError('Android platform register x18 used by helper')
            if instruction.mnemonic in ('svc', 'hvc', 'smc'):
                raise ValueError('unexpected helper syscall')
    (work / 'payload.bin').write_bytes(payload)
    return {'compiler_version': version, 'payload_bytes': len(payload), 'payload_sha256': expected['sha256'],
            'symbols': symbols, 'function_bytes': sizes, 'source_matches_frozen_payload': True,
            'no_unresolved_relocations_or_new_imports': True, 'android_x18_reserved_and_disassembly_checked': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--zig', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = compile_payload(args.work, zig=args.zig)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
