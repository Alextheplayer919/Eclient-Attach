import ctypes
import hashlib
import math
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).parents[1]))

import build_flyx as fx
import build_autototem as at
from inspect_bundle_runtime import Elf64
import test_autototem as at_fixtures


class Vec3(ctypes.Structure):
    _fields_ = [('x', ctypes.c_float), ('y', ctypes.c_float), ('z', ctypes.c_float)]


class Input(ctypes.Structure):
    _fields_ = [(x, ctypes.c_float) for x in ('strafe', 'forward', 'yaw_degrees', 'position_x', 'position_z')] + [
        ('jump', ctypes.c_ubyte), ('sneak', ctypes.c_ubyte), ('touching_terrain', ctypes.c_ubyte), ('now_ns', ctypes.c_uint64)]


class Core(ctypes.Structure):
    _fields_ = [('phase_start_ns', ctypes.c_uint64), ('vx', ctypes.c_float), ('vy', ctypes.c_float),
                ('vz', ctypes.c_float), ('bypass_phase', ctypes.c_ubyte), ('alternate_tick', ctypes.c_ubyte)]


class FlyXMotionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory(prefix='flyx-core-')
        work = Path(cls.directory.name)
        (work / 'math.c').write_text('#include <math.h>\nfloat spiral_flyx_sin(float x){return sinf(x);}\n'
                                   'float spiral_flyx_cos(float x){return cosf(x);}\n'
                                   'float spiral_flyx_sqrt(float x){return sqrtf(x);}\n')
        cc = shutil.which('cc')
        if not cc:
            raise RuntimeError('C compiler required; do not silently skip the actual native planner')
        subprocess.run([cc, '-std=c11', '-O2', '-shared', '-fPIC', str(fx.ROOT / 'bundle/native/flyx_core.c'),
                        str(work / 'math.c'), '-lm', '-o', str(work / 'core.so')], check=True)
        cls.native = ctypes.CDLL(str(work / 'core.so'))
        cls.native.spiral_flyx_reset.argtypes = [ctypes.POINTER(Core)]
        cls.native.spiral_flyx_plan.argtypes = [ctypes.POINTER(Core), ctypes.POINTER(Input), ctypes.c_float,
                                              ctypes.c_float, ctypes.POINTER(Vec3)]
        cls.native.spiral_flyx_plan.restype = ctypes.c_ubyte

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def state(self):
        state = Core()
        self.native.spiral_flyx_reset(ctypes.byref(state))
        return state

    def plan(self, state=None, h=1.0, v=1.0, **kwargs):
        if state is None:
            state = self.state()
        values = {'now_ns': 1000000000, **kwargs}
        inp = Input(**values)
        result = Vec3()
        self.assertTrue(self.native.spiral_flyx_plan(ctypes.byref(state), ctypes.byref(inp), h, v, ctypes.byref(result)))
        return result

    def test_twelve_original_speed_constants_remain_exact(self):
        text = (fx.ROOT / 'bundle/native/flyx_core.c').read_text()
        actual = {name.lower(): float(value) for name, value in re.findall(r'^#define (\w+) (-?[0-9.]+)f$', text, re.M)}
        self.assertEqual(actual, fx.BASE_SPEEDS)

    def test_cardinals_and_every_view_yaw_have_correct_local_to_world_basis(self):
        for yaw in (-180, -135, -90, -37, 0, 42, 90, 135, 180):
            for strafe, forward in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                with self.subTest(yaw=yaw, strafe=strafe, forward=forward):
                    out = self.plan(strafe=strafe, forward=forward, yaw_degrees=yaw)
                    sin, cos = math.sin(math.radians(yaw)), math.cos(math.radians(yaw))
                    self.assertAlmostEqual(out.x, (strafe * cos - forward * sin) * 2.42 * .32, places=5)
                    self.assertAlmostEqual(out.z, (forward * cos + strafe * sin) * 2.42 * .32, places=5)

    def test_analog_directions_are_not_quantized_to_eight_angles(self):
        for angle in range(0, 360, 7):
            x, z = math.sin(math.radians(angle)), math.cos(math.radians(angle))
            out = self.plan(strafe=x, forward=z)
            self.assertAlmostEqual(out.x, x * 2.42 * .32, places=5)
            self.assertAlmostEqual(out.z, z * 2.42 * .32, places=5)

    def test_partial_stick_preserves_analog_magnitude(self):
        out = self.plan(forward=.1)
        self.assertAlmostEqual(out.z, 2.42 * .1 * .32, places=6)

    def test_diagonal_is_normalized_without_speed_boost(self):
        out = self.plan(strafe=1, forward=1)
        self.assertAlmostEqual(math.hypot(out.x, out.z), 2.42 * .32, places=6)

    def test_no_input_damps_and_eventually_stops_without_drift(self):
        state = self.state()
        self.plan(state=state, forward=1)
        last = state.vz
        out = self.plan(state=state)
        self.assertAlmostEqual(out.z, last * .65, places=6)
        for tick in range(80):
            out = self.plan(state=state, now_ns=1000000000 + tick * 50000000)
        self.assertEqual((out.x, out.z), (0, 0))

    def test_distance_blend_keeps_initial_final_and_midpoint_speeds(self):
        for distance, speed in ((0, 2.42), (2750000, 2.30), (5500000, 2.18), (10000000, 2.18)):
            out = self.plan(forward=1, position_x=distance)
            self.assertAlmostEqual(out.z, speed * .32, places=5)

    def test_neutral_factors_preserve_original_vertical_and_bypass_targets(self):
        out = self.plan(jump=1)
        self.assertAlmostEqual(out.y, -.1266 + 1.62 * .22, places=6)
        out = self.plan(jump=1, forward=1)
        self.assertAlmostEqual(out.y, -.1266 + 1.086 * .22, places=6)
        self.assertAlmostEqual(out.z, 1.1585 * .32, places=6)

    def test_up_h_factor_changes_only_horizontal_while_ascending(self):
        neutral = self.plan(jump=1, forward=1)
        scaled = self.plan(jump=1, forward=1, h=.5)
        self.assertAlmostEqual(scaled.z, neutral.z * .5, places=6)
        self.assertEqual(scaled.y, neutral.y)
        self.assertEqual(self.plan(forward=1, h=.5).z, self.plan(forward=1).z)

    def test_up_v_factor_changes_lift_not_glide_or_horizontal(self):
        neutral = self.plan(jump=1, forward=1)
        scaled = self.plan(jump=1, forward=1, v=.5)
        self.assertAlmostEqual(scaled.y, -.1266 + 1.086 * .5 * .22, places=6)
        self.assertEqual(scaled.z, neutral.z)
        self.assertEqual(self.plan(v=.5).y, self.plan().y)

    def test_original_90ms_release_phase_is_unchanged(self):
        state = self.state()
        self.plan(state=state, jump=1, forward=1)
        self.plan(state=state, forward=1, now_ns=1050000000)
        self.assertTrue(state.bypass_phase)
        self.plan(state=state, forward=1, now_ns=1090000000)
        self.assertFalse(state.bypass_phase)

    def test_original_terrain_cap_remains_two(self):
        out = self.plan(forward=1, touching_terrain=1)
        self.assertAlmostEqual(out.z, 2.0 * .32, places=6)

    def test_original_descent_speed_horizontal_and_alternation_are_unchanged(self):
        state = self.state()
        first = self.plan(state=state, forward=1, sneak=1, h=.5, v=.5)
        self.assertAlmostEqual(first.z, 1.1 * .32, places=6)
        self.assertAlmostEqual(first.y, -.1266, places=6)
        second = self.plan(state=state, forward=1, sneak=1)
        self.assertEqual((second.x, second.z), (0, 0))
        self.assertAlmostEqual(second.y, -4.2997, places=5)

    def test_no_anti_lagback_3d_cap_or_seventh_tick_climb_pulse(self):
        state = self.state()
        for tick in range(100):
            out = self.plan(state=state, forward=1, jump=1, now_ns=1000000000 + tick * 50000000)
            if tick > 35:
                self.assertGreater(out.y, .9)
        self.assertGreater(math.sqrt(out.x ** 2 + out.y ** 2 + out.z ** 2), 1.08)
        self.assertAlmostEqual(out.z, 1.1585, places=5)
        self.assertAlmostEqual(out.y, 1.086 - .1266, places=5)

    def test_nonfinite_inputs_and_invalid_factors_fail_without_mutation(self):
        for field in ('strafe', 'forward', 'yaw_degrees', 'position_x', 'position_z'):
            for invalid in (float('nan'), float('inf'), -float('inf')):
                state = self.state()
                before = bytes(state)
                result = Vec3()
                inp = Input(**{field: invalid})
                self.assertFalse(self.native.spiral_flyx_plan(ctypes.byref(state), ctypes.byref(inp), 1., 1., ctypes.byref(result)))
                self.assertEqual(bytes(state), before)
        for invalid in (.01, 2.1, float('nan'), float('inf')):
            result, state, inp = Vec3(), self.state(), Input()
            self.assertFalse(self.native.spiral_flyx_plan(ctypes.byref(state), ctypes.byref(inp), invalid, 1., ctypes.byref(result)))


class FlyXPatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        at_fixtures.AutoTotemTests.setUpClass()
        cls.parent = at_fixtures.AutoTotemTests.candidate
        cls.candidate, cls.report = fx.patch_parent(cls.parent, expected_parent_sha256=None, expected_candidate_sha256=None)

    def test_reversal_preserves_entire_previous_autototem_rgb_engine(self):
        self.assertEqual(fx.restore_parent(self.candidate), self.parent)
        self.assertEqual(self.candidate[at.HELPER:at.HELPER_END], at.PAYLOAD)

    def test_no_old_load_descriptor_or_elf_section_changes(self):
        before, after = Elf64(self.parent), Elf64(self.candidate)
        self.assertEqual(after.segments[:-1], before.segments)
        self.assertEqual(after.sections, before.sections)
        self.assertEqual(after.segments[-1][1], 5)
        self.assertEqual(after.segments[-1][2:4], (fx.EXTENSION, fx.EXTENSION))

    def test_program_table_is_mapped_at_bionic_fallback_address(self):
        address = struct.unpack_from('<Q', self.candidate, 32)[0]
        self.assertEqual(address, fx.EXTENSION)
        self.assertEqual(struct.unpack_from('<H', self.candidate, 56)[0], 9)
        self.assertEqual(self.candidate[address:address + 8 * 56], self.parent[64:64 + 8 * 56])
        self.assertEqual(self.candidate[fx.HELPER:fx.HELPER + len(fx.PAYLOAD)], fx.PAYLOAD)

    def test_parent_and_payload_are_pinned_by_default(self):
        with self.assertRaises(ValueError): fx.patch_parent(self.parent)
        self.assertEqual(hashlib.sha256(fx.PAYLOAD).hexdigest(), fx.PAYLOAD_SHA256)

    def test_tampered_preserved_code_or_new_load_is_rejected(self):
        for address in (at.HELPER + 32, at.rgb.HELPER + 8, 0x40000, fx.EXTENSION + 8 * 56 + 4, fx.HELPER + 12):
            data = bytearray(self.candidate)
            data[address] ^= 1
            with self.subTest(address=hex(address)), self.assertRaises(ValueError):
                fx.assert_delta(self.parent, bytes(data), expected_parent_sha256=None, expected_candidate_sha256=None)

    def test_source_call_words_chain_existing_captured_trampoline_and_gui(self):
        self.assertEqual(self.candidate[at.TICK:at.TICK + 4], fx.TICK_CALL)
        self.assertEqual(self.candidate[at.GUI:at.GUI + 4], fx.GUI_CALL)
        self.assertEqual(self.candidate[0xb6b90:0xb6b94], self.parent[0xb6b90:0xb6b94])
        self.assertEqual(self.candidate[0xb7a88:0xb7a8c], self.parent[0xb7a88:0xb7a8c])

    def test_scope_defaults_no_anti_lagback_and_other_modules_still_parked(self):
        self.assertFalse(self.report['flyx']['default_enabled'])
        self.assertEqual(self.report['flyx']['up_h_factor_default'], 1.)
        self.assertEqual(self.report['flyx']['up_v_factor_default'], 1.)
        self.assertFalse(self.report['flyx']['anti_lagback_envelope_cap_pulse_or_server_correction_hook'])
        self.assertEqual(self.report['other_modules_parked'], ['ChatSpammer', 'PopCounter', 'Kiwi KaX'])


if __name__ == '__main__':
    unittest.main()
