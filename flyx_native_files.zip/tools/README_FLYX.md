# Native FlyX experiment (Minecraft, not relay)

Current candidate source: `bundle/native/flyx_*`, `flyx.ld`, frozen `flyx_payload.json`.
Build: `.github/workflows/minecraft-flyx.yml`, separate `Minecraft_FlyX_v1.0.7-test1` release.
No phone/startup/real-controller/server claim is implied by a passing gate.

## Scope

FlyX only, retaining the complete, strict AutoTotem test2 layer and RGB v1.0.5.
Do not weaken `build_autototem.py` or overwrite historical releases. The new
builder restores the exact test2 engine before running its original audits.
Minecraft label/package/version/signer/icons/resources/authentication/worlds and
original modules/defaults are unchanged. ChatSpammer, PopCounter and Kiwi KaX
remain parked. See `RELEASE_FLYX_TEST1.md` for controls, speeds and device tests.

The unchanged `D4Cplus.zip` Kotlin reference is **not** the installed payload.
The port preserves the active `BypassFlyModule.kt` phase/release, distance blend,
vertical/horizontal smoothing, glide/descent and twelve constants. Do **not**
port its unused `FlyXMotionPlanner.applyAntiLagbackEnvelope`, alternate `Fly2`
full-tilt scaling, climb caps/pulses, 3D envelope, or correction interception.
Neutral factors are 1.0; optional range 0.1–2.0. Up H affects ascending H only;
Up V affects upward lift, not glide/descent. No extra WANT_UP/JUMP_DOWN/START_JUMPING
ascent flags are silently substituted for the active source's JUMPING flag.

## Native bindings / lifecycle

`flyx_bindings.json` pins exact ANDROID native windows under original game SHA
`dd46d26a2055b1dab9675034f94f4ac9860d4ac06e280809e730e70eded611bc`.
Windows semantic SDK headers are not Android layout evidence.

- Nullable bounded, read-only ECS clone of `0x6bf1d18`/nullable packet caller.
  Never call that asserting getter on missing input or construct components.
- Actor EntityContext registry `+0x10`, entity `+0x18`, 32-byte pool nodes;
  sparse generation check and 128-element dense pages. Vector/chains bounded.
  Tagged pointers are retained, not rejected using arbitrary 48-bit limits.
- MoveInput `0x018b1887`, stride 160. Native `0x660266c` copies motion `+0x58`,
  logical analog `+0x14`, raw analog `+0x3c`. Raw zero/sentinel uses native pure
  helper `0x9d03e90(component+0x28)`, including raw diagonal buttons. Extraction
  priority is motion → packet-equivalent raw → logical analog → logical buttons.
  Nonfinite/bad vectors never turn into full-stick movement; `+0x60` is look delta.
- JUMPING `+0x98` → packet bit 6, SNEAKING `+0x94` → 8, water autojump `+0x99` → 7.
  Horizontal collision `0xd5ee0bd8` is sparse tag membership, not a bool payload.
  No unproved extra input-lock byte ABI is used.
- Cached StateVector `actor+0x208` has 36-byte stride/alignment 4 (odd elements
  must NOT be rejected as unaligned 8-byte pointers). Position X/Z `+0/+8` read
  only. ActorRotation `actor+0x218`, current yaw `+4`, not previous yaw `+12`.
- Native motion setter is LocalPlayer slot 23 / `0xc94c3f0`; its original body
  writes the three StateVector velocity floats `+0x18/+0x1c/+0x20`. No raw game
  position/input/velocity writes exist in the payload itself.
- No second LocalPlayer hook or saved-trampoline change. Original outer
  normal/alive dispatch, auth and gameplay/session gates are retained. New
  wrapper calls exact AutoTotem tick/original callee once and preserves return.
  Disabled FlyX performs no native snapshot, clock or movement/state writes.
- Private state `0x3b3c30`, 72 bytes, after original AutoTotem's end `0x3b3c28`.
  Atomic UI control generation/factors; game-thread smoothing state; reentry
  flag. Reset on enable generation/player/world or >500ms/backward-clock gaps;
  this is lifecycle hygiene, not server-correction or anti-lagback handling.

## ELF / GUI

Only 1,688 bytes remain in the old RX helper gap: do not silently use unproved
zero runs inside old `.text`. FlyX instead occupies a dedicated RX LOAD at
file offset/RVA `0x400000`, 64-KiB aligned. The old eight program descriptors are
copied unchanged there, followed by one RX descriptor and bounded padding;
code starts at `0x400200`. `e_phoff` points to the new self-mapped table, `e_phnum`
is 9. This satisfies Bionic's no-PT_PHDR fallback address (`load_bias+e_phoff`)
and original LOADs/sections are unchanged. It has not been phone-loader-tested.
No new import, dependency, library, relocation or RWX mapping. Reversal truncates
the append, restores two ELF header fields and the two already-owned call words,
then requires the exact old AutoTotem SHA. Original helper bytes remain exact.

GUI wrapper calls unchanged AutoTotem GUI/BeginGroup once, then adds Movement
(category 0) `FlyX`, `Up H Factor##FlyX`, `Up V Factor##FlyX`. Both sliders call
actual **SliderFloat `0x16f9ac`**, not DragFloat `0x16c3ac`. No GUI gameplay-byte
gate: both session flag states must still render the rows. Original category
jump table and Combat tabs/first original control execute in emulation.

## Reproduce

```
python3 -m pip install -r tools/requirements_autototem.txt
python3 -m unittest discover -s tools/tests -v
python3 tools/compile_flyx.py --work WORK/compiler --output WORK/compile.json
python3 tools/build_flyx.py ORIGINAL.apk --output WORK/unsigned.apk --report WORK/build.json
python3 tools/verify_flyx_bindings.py --game ORIGINAL-GAME.so --output WORK/bindings.json
python3 tools/test_flyx_emulation.py --candidate WORK/flyx-engine.so --game ORIGINAL-GAME.so --output WORK/emulation.json
```

Release CI checks full game hash (not just recovered pages), old AutoTotem
compiler/native/GUI/inventory paths, and older RGB/style/font gates; signs and
aligns `Minecraft.apk`; compares badging/signer and hashes all other 33,478
payloads. Publish only if all gates pass. Never silently clobber an earlier APK.
The native/emulated models are explicitly synthetic, not phone/server evidence.
