#!/usr/bin/env python3
"""Strict release gate for the native FlyX + byte-exact AutoTotem test2 + RGB GUI APK."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import zipfile

from audit_bundle_stability import snapshot, compare
from build_spiral_compat import is_signature, sha256
from verify_compat_bundle import CERT
from verify_gui_base import gui_structure
import build_autototem as at
import build_flyx as fx


def identity(base_badging, candidate_badging, base_signature, candidate_signature):
    if not base_badging.strip() or base_badging != candidate_badging or "application-label:'Minecraft'" not in candidate_badging:
        raise ValueError('Minecraft name/package/version/icons/badging changed')
    for text in (base_signature, candidate_signature):
        certs = re.findall(r'certificate SHA-256 digest:\s*([0-9a-f]{64})', text, re.I)
        if len(certs) != 1 or certs[0].lower() != CERT:
            raise ValueError('original signing identity changed')


def verify(base, candidate, base_badging, candidate_badging, base_signature, candidate_signature):
    original, rebuilt = snapshot(base), snapshot(candidate)
    if original['sha256'] != at.rgb.BASE_SHA256:
        raise ValueError('unexpected original Minecraft APK')
    if original['duplicate_entries'] or rebuilt['duplicate_entries']:
        raise ValueError('duplicate APK entries')
    result = compare(original, rebuilt)
    if [name for name in result['changed_entries'] if not is_signature(name)] != [at.ENGINE]:
        raise ValueError('payload changed beyond the reviewed native engine')
    if result['added_non_signature_entries'] or result['removed_non_signature_entries'] or result['compression_changes']:
        raise ValueError('original payload paths/compression changed')
    identity(base_badging, candidate_badging, base_signature, candidate_signature)
    with zipfile.ZipFile(base) as left, zipfile.ZipFile(candidate) as right:
        expected, build_report = fx.patch_engine(left.read(at.ENGINE))
        actual = right.read(at.ENGINE)
        if actual != expected:
            raise ValueError('unreviewed combined FlyX engine bytes')
        parent = fx.restore_parent(actual)
        delta = fx.assert_delta(parent, actual)
        reference = at.restore_rgb(parent)
        preserved_at = at.assert_delta(reference, parent)
        static = at.rgb.restore_static(reference)
        # The lower layer remains the already-reviewed exact RGB v1.0.5;
        # independently reverse it and enforce the older data-only style gate.
        at.rgb.assert_rgb_delta(static, reference)
        at.rgb.style.assert_data_only(left.read(at.ENGINE), static)
        if at.rgb.base.decoded_title(actual) != at.rgb.style.GUI_TITLE:
            raise ValueError('classic header changed')
        with right.open(at.GAME) as game:
            if sha256(game) != at.GAME_SHA256:
                raise ValueError('pinned original Minecraft game ELF changed')
        preserved = 0
        for name in left.namelist():
            if name == at.ENGINE or is_signature(name):
                continue
            with left.open(name) as a, right.open(name) as b:
                if sha256(a) != sha256(b):
                    raise ValueError('original payload changed: ' + name)
            preserved += 1
        gui_structure(right, actual)
    result.update({
        'app_label': 'Minecraft', 'gui_title': at.rgb.style.GUI_TITLE,
        'flyx_delta_from_exact_autototem_test2': delta,
        'preserved_strict_autototem_test2_delta_from_rgb': preserved_at,
        'all_other_payload_entries_byte_identical': preserved,
        'game_sha256': at.GAME_SHA256, 'original_signer_sha256': CERT,
        'invariants': {
            'original_manifest_resources_icons_all_dex_game_libraries_and_other_assets': True,
            'original_engine_module_bodies_data_auth_loader_and_jni_touch_lifecycle': True,
            'two_already_owned_call_words_chained_not_an_entire_tick_replacement': True,
            'dead_and_bypass_tick_paths_saved_trampoline_slot_and_hook_installer_untouched': True,
            'rgb_title_font_static_palette_window_size_and_widgets_unchanged': True,
            'private_72_byte_flyx_state_separate_from_unchanged_autototem_state': True,
            'single_appended_rx_load_no_new_import_library_or_writable_executable_mapping': True,
            'original_load_descriptors_unchanged_self_mapped_relocated_program_table': True,
            'chat_pop_kax_not_linked_or_enabled': True,
            'flyx_default_off_both_up_factors_neutral_one_no_anti_lagback': True,
        },
        'new_modules_added': ['FlyX (experimental; Up H Factor and Up V Factor)'],
        'retained_module': 'AutoTotem test2 (empty-offhand refill only)',
        'phone_startup_verified': False, 'phone_gui_touch_verified': False,
        'server_inventory_acceptance_verified': False, 'existing_modules_phone_tested': False,
        'phone_tests_required': [
            'Back up worlds; update normally without clearing data',
            'Start past Mojang logo, sign in normally and open Movement; confirm FlyX and both factor sliders',
            'FlyX defaults OFF, both Up factors 1.00x; test yaw-relative analog/cardinal/diagonal motion in a disposable world',
            'Check ascent/descent, stop/turn, factors, disable, world changes, background/resume; restart is OFF again',
            'Open Combat; confirm AutoTotem and all original controls still appear',
            'Confirm original GUI/RGB and existing modules still work',
            'AutoTotem starts OFF; enable it with an empty offhand and a totem in inventory',
            'Test inventory and selected/nonselected hotbar sources in a disposable world',
            'Check server-authoritative inventory/offhand state, consume a totem and check refill',
            'Confirm shields/food/other occupied offhand items are never replaced',
            'Disable, change worlds, die/respawn, background/resume, restart (OFF again)',
        ],
    })
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    for name in ('base-badging', 'candidate-badging', 'base-signature', 'candidate-signature'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = verify(args.base, args.candidate, args.base_badging.read_text(), args.candidate_badging.read_text(),
                    args.base_signature.read_text(), args.candidate_signature.read_text())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
