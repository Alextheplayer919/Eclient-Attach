#!/usr/bin/env python3
"""Read-only exact Android movement/input recovery. Never builds an APK."""
from __future__ import annotations
import argparse
import hashlib
import json
import mmap
from pathlib import Path
import re

from build_autototem import GAME_SHA256, GAME_BUILD_ID
from build_spiral_compat import sha256
from export_game_abi import Pages, gnu_build_id
from inspect_bundle_runtime import Elf64
from map_runtime_rtti import load_pointers

# Bounded native LocalPlayer, Actor, Player and entity/input-accessor neighborhoods.
# These are analysis windows, NOT callable ABI declarations.
WINDOWS = ((0x6bec000, 0xc000), (0xc930000, 0x34000),
           (0xce00000, 0x30000), (0xcdd0000, 0x2c000),
           (0x6602000, 0x4000), (0x6051000, 0x2000), (0x9d03000, 0x2000),
           (0x2645000, 0x1000), (0x34f1000, 0x1000), (0x105d3000, 0x1000))


def probe(game):
    with game.open('rb') as source:
        if sha256(source) != GAME_SHA256:
            raise ValueError('wrong original Android Minecraft ELF')
        with mmap.mmap(source.fileno(), 0, access=mmap.ACCESS_READ) as mapped:
            elf = Elf64(mapped)
            if gnu_build_id(elf) != GAME_BUILD_ID:
                raise ValueError('wrong game build ID')
            pages = Pages(elf, maximum=8 * 1024 * 1024)
            for start, size in WINDOWS:
                pages.add(start, size, code=True)
            symbols = []
            for symbol in elf.symbols():
                if re.search(r'MoveInput|StateVector|MovementInput|InputHandler|ActorRotation', symbol['name']):
                    symbols.append(symbol)
                    if symbol['type'] == 2:
                        pages.add(int(symbol['rva'], 16), min(symbol['size'], 4096), code=True)
            strings = []
            for match in re.finditer(rb'(?:MoveInput|StateVector|MovementInput|ActorRotation|MoveInputHandler)[A-Za-z0-9_:]*', mapped):
                strings.append({'file_offset': hex(match.start()), 'rva': elf.file_rva(match.start()),
                                'text': match[0].decode('ascii')})
                if len(strings) >= 200:
                    break
            pointers = load_pointers(game, elf)
            # Native pure raw-axis helper reads the shared Vec2 zero through GOT.
            pages.add(pointers.pointer(0x105d35f0), 8)
            # Actual primary LocalPlayer table, for later slot checks/recovery.
            pages.add(0x10036a60, 16 + 246 * 8)
            relocs = [{'rva': hex(address), 'target_rva': hex(target)}
                      for address, target in pointers.resolved.items() if pages.contains(address)]
            return {'schema': 1, 'read_only_analysis': True, 'elf_sha256': GAME_SHA256,
                    'gnu_build_id': GAME_BUILD_ID, 'page_bytes': pages.bytes,
                    'pages': sorted(pages.pages.values(), key=lambda p: int(p['rva'], 16)),
                    'relocations': relocs, 'input_symbol_leads': symbols, 'input_string_leads': strings,
                    'runtime_adapter_complete': False, 'device_tested': False,
                    'limitations': ['Read-only native windows; no inferred type/offset is a binding until checked.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(probe(args.game), indent=2) + '\n')


if __name__ == '__main__':
    main()
