#!/usr/bin/env python3
"""Layer native FlyX over exact AutoTotem test2, preserving Minecraft/RGB/auth.

Only the two already-owned engine call words are chained. Existing AutoTotem
instructions/state and every old LOAD remain exact. A self-mapped appended RX
LOAD holds FlyX and the relocated (old entries exact + one new) program table.
"""
from __future__ import annotations
import argparse
from copy import copy
import hashlib
import json
from pathlib import Path
import shutil
import struct
import zipfile

import build_autototem as at
from inspect_bundle_runtime import Elf64
from build_spiral_compat import is_signature, sha256

ROOT = at.ROOT
ENGINE = at.ENGINE
META = json.loads((ROOT / 'bundle/native/flyx_payload.json').read_text())
PAYLOAD = bytes.fromhex(META['hex'])
PAYLOAD_SHA256 = 'b380694d8b270010dbe65b0e3b92fb96ec59f08128594c0ba35ef9af1b77d338'
ENGINE_SHA256 = 'c43b2619f531ce4afd4e2627af16863cedd025fe9561a918e1f14c7fad44a4bf'
PARENT_BYTES = 3818640
EXTENSION = 0x400000
HELPER = EXTENSION + 0x200
STATE = 0x3b3c30
STATE_BYTES = 72
GUI_HELPER = int(META['symbols']['spiral_flyx_gui'], 16)
TICK_HELPER = int(META['symbols']['spiral_flyx_tick_veneer'], 16)
GUI_CALL = at.branch(at.GUI, GUI_HELPER)
TICK_CALL = at.branch(at.TICK, TICK_HELPER)
HEADER_RANGES = ((32, 8), (56, 2), (at.GUI, 4), (at.TICK, 4))
BASE_SPEEDS = {'initial_h': 2.42, 'initial_v': 1.62, 'initial_bypass_h': 1.1585,
               'initial_bypass_v': 1.086, 'final_h': 2.18, 'final_v': 1.42,
               'final_bypass_h': 1.09, 'final_bypass_v': 1.05, 'glide': -0.1266,
               'release_delay': 0.09, 'descent_speed': 4.2997, 'descent_h': 1.1}


def _layout(parent, *, expected_parent_sha256=at.ENGINE_SHA256):
    if expected_parent_sha256 and hashlib.sha256(parent).hexdigest() != expected_parent_sha256:
        raise ValueError('unsupported AutoTotem test2 parent')
    at.assert_delta(at.restore_rgb(parent), parent,
                    expected_reference_sha256=at.rgb.RGB_ENGINE_SHA256 if expected_parent_sha256 else None,
                    expected_candidate_sha256=expected_parent_sha256)
    elf = Elf64(parent)
    if len(parent) != PARENT_BYTES or struct.unpack_from('<Q', parent, 32)[0] != 64 or len(elf.segments) != 8:
        raise ValueError('unexpected original ELF/program-header geometry')
    if (HELPER != int(META['entry_rva'], 16) or META['size'] != len(PAYLOAD) or
            META['sha256'] != PAYLOAD_SHA256 or hashlib.sha256(PAYLOAD).hexdigest() != PAYLOAD_SHA256 or
            TICK_HELPER != HELPER or HELPER + len(PAYLOAD) > EXTENSION + 65536):
        raise ValueError('unreviewed FlyX helper/extent')
    if STATE < at.STATE + at.STATE_BYTES:
        raise ValueError('FlyX state overlaps AutoTotem state')
    for section in elf.sections:
        if section[2] & 2 and section[5]:
            if max(STATE, section[3]) < min(STATE + STATE_BYTES, section[3] + section[5]):
                raise ValueError('FlyX state overlaps original allocated section')
    if not any(s[0] == 1 and s[1] == 6 and s[3] + s[5] <= STATE and STATE + STATE_BYTES <= s[3] + s[6]
               for s in elf.segments):
        raise ValueError('FlyX state not in original unused RW zero-fill')
    if any(s[0] == 1 and s[3] + s[6] > EXTENSION for s in elf.segments):
        raise ValueError('appended RX LOAD overlaps an original LOAD')
    return elf


def restore_parent(candidate):
    if len(candidate) <= EXTENSION:
        raise ValueError('truncated FlyX candidate')
    parent = bytearray(candidate[:PARENT_BYTES])
    struct.pack_into('<Q', parent, 32, 64)
    struct.pack_into('<H', parent, 56, 8)
    parent[at.GUI:at.GUI + 4] = at.GUI_CALL
    parent[at.TICK:at.TICK + 4] = at.TICK_CALL
    return bytes(parent)


def _tail(parent):
    elf = Elf64(parent)
    size = HELPER + len(PAYLOAD) - EXTENSION
    extra = (1, 5, EXTENSION, EXTENSION, EXTENSION, size, size, 65536)
    table = b''.join(struct.pack('<IIQQQQQQ', *s) for s in [*elf.segments, extra])
    if len(table) > HELPER - EXTENSION:
        raise ValueError('program table overlaps FlyX code')
    return table + bytes(HELPER - EXTENSION - len(table)) + PAYLOAD, extra


def assert_delta(parent, candidate, *, expected_parent_sha256=at.ENGINE_SHA256,
                 expected_candidate_sha256=ENGINE_SHA256):
    elf = _layout(parent, expected_parent_sha256=expected_parent_sha256)
    before, after = (hashlib.sha256(x).hexdigest() for x in (parent, candidate))
    if expected_candidate_sha256 and after != expected_candidate_sha256:
        raise ValueError('unsupported/unreviewed FlyX candidate hash')
    tail, extra = _tail(parent)
    if len(candidate) != EXTENSION + len(tail):
        raise ValueError('unexpected FlyX file extent')
    end = 0
    for offset, size in sorted(HEADER_RANGES):
        if parent[end:offset] != candidate[end:offset]:
            raise ValueError('changed preserved original/AutoTotem/RGB bytes')
        end = offset + size
    if candidate[end:PARENT_BYTES] != parent[end:] or any(candidate[PARENT_BYTES:EXTENSION]):
        raise ValueError('changed preserved prefix or unreviewed appended padding')
    if candidate[EXTENSION:] != tail:
        raise ValueError('appended program table/FlyX code differs')
    if (candidate[at.GUI:at.GUI + 4] != GUI_CALL or candidate[at.TICK:at.TICK + 4] != TICK_CALL or
            struct.unpack_from('<Q', candidate, 32)[0] != EXTENSION or struct.unpack_from('<H', candidate, 56)[0] != 9):
        raise ValueError('FlyX call/header words differ')
    new = Elf64(candidate)
    if new.segments != [*elf.segments, extra] or new.sections != elf.sections:
        raise ValueError('changed original LOAD/section layout or new permissions')
    if restore_parent(candidate) != parent:
        raise ValueError('FlyX reversal did not recover exact test2')
    # Bionic's no-PT_PHDR fallback reads Ehdr through offset-zero LOAD, then
    # uses load_bias + e_phoff. Our appended table maps at that exact address.
    phoff, phbytes = struct.unpack_from('<Q', candidate, 32)[0], len(new.segments) * 56
    if not (extra[2] == extra[3] == phoff and phoff + phbytes <= extra[3] + extra[5]):
        raise ValueError('program table not self-mapped at Bionic fallback address')
    for page in (4096, 16384, 65536):
        if EXTENSION % page or extra[2] % page:
            raise ValueError('new LOAD not Android page aligned')
    return {'parent_autototem_test2_engine_sha256': before, 'flyx_engine_sha256': after,
            'new_this_layer': ['FlyX'], 'retained_new_module': 'AutoTotem test2, payload byte-identical',
            'flyx': {'location': 'Movement (category 0), above existing controls', 'default_enabled': False,
                     'base_speed_values_unchanged': BASE_SPEEDS, 'up_h_factor_default': 1.0,
                     'up_v_factor_default': 1.0, 'factor_range': [0.1, 2.0],
                     'up_factors_apply_only_to_ascending_horizontal_and_lift': True,
                     'analog_yaw_relative_horizontal_with_diagonal_normalization_and_source_smoothing': True,
                     'anti_lagback_envelope_cap_pulse_or_server_correction_hook': False},
            'only_existing_gui_and_alive_tick_call_words_chained': [hex(at.GUI), hex(at.TICK)],
            'autototem_payload_state_and_all_original_module_bodies_unchanged': True,
            'rgb_title_font_palette_window_auth_loader_jni_unchanged': True,
            'native_localplayer_slot23_velocity_setter_rva': '0xc94c3f0',
            'new_game_hook_saved_trampoline_write_privilege_grant_or_packet_injection': False,
            'private_state_in_existing_rw_zero_fill': {'rva': hex(STATE), 'bytes': STATE_BYTES},
            'appended_read_execute_only_load': {'rva': hex(EXTENSION), 'file_offset': hex(EXTENSION),
                                               'bytes': extra[5], 'align': 65536},
            'relocated_program_header_table_self_mapped_for_bionic': True,
            'all_original_load_descriptors_and_elf_sections_unchanged': True,
            'new_import_or_writable_executable_mapping': False,
            'reverses_byte_exactly_to_autototem_test2': True,
            'helper_bytes': len(PAYLOAD), 'helper_sha256': PAYLOAD_SHA256,
            'phone_startup_gui_touch_or_flight_server_acceptance_verified': False,
            'other_modules_parked': ['ChatSpammer', 'PopCounter', 'Kiwi KaX']}


def patch_parent(parent, *, expected_parent_sha256=at.ENGINE_SHA256, expected_candidate_sha256=ENGINE_SHA256):
    _layout(parent, expected_parent_sha256=expected_parent_sha256)
    tail, _ = _tail(parent)
    candidate = bytearray(parent + bytes(EXTENSION - len(parent)) + tail)
    struct.pack_into('<Q', candidate, 32, EXTENSION)
    struct.pack_into('<H', candidate, 56, 9)
    candidate[at.GUI:at.GUI + 4], candidate[at.TICK:at.TICK + 4] = GUI_CALL, TICK_CALL
    candidate = bytes(candidate)
    return candidate, assert_delta(parent, candidate, expected_parent_sha256=expected_parent_sha256,
                                   expected_candidate_sha256=expected_candidate_sha256)


def patch_engine(original):
    parent, previous = at.patch_engine(original)
    candidate, report = patch_parent(parent)
    return candidate, {'preserved_autototem_test2_and_rgb_layers_only': previous, 'flyx_layer': report}


def build(original, output):
    if original.resolve() == output.resolve():
        raise ValueError('refusing to overwrite original APK')
    with original.open('rb') as source:
        fingerprint = sha256(source)
    if fingerprint != at.rgb.BASE_SHA256:
        raise ValueError('unsupported original Minecraft APK')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(original) as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise ValueError('duplicate APK entries')
        with archive.open(at.GAME) as game:
            if sha256(game) != at.GAME_SHA256:
                raise ValueError('unsupported game ABI')
        engine, report = patch_engine(archive.read(ENGINE))
        with zipfile.ZipFile(output, 'w', allowZip64=True) as dest:
            dest.comment = archive.comment
            for info in archive.infolist():
                if is_signature(info.filename):
                    continue
                if info.filename == ENGINE:
                    dest.writestr(copy(info), engine)
                else:
                    with archive.open(info) as source, dest.open(copy(info), 'w') as target:
                        shutil.copyfileobj(source, target, 1024 * 1024)
    return {'purpose': 'Experimental native FlyX; exact AutoTotem test2/RGB retained',
            'app_label': 'Minecraft', 'gui_title': at.rgb.style.GUI_TITLE, 'base_sha256': fingerprint,
            'game_sha256': at.GAME_SHA256, 'changed_payload_entries': [ENGINE], 'native_patch': report,
            'phone_startup_verified': False, 'phone_gui_touch_verified': False, 'flight_server_acceptance_verified': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    report = build(args.base, args.output)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
