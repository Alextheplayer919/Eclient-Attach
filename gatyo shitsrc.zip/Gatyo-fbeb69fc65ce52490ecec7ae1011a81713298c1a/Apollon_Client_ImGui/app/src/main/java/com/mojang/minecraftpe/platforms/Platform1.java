package com.mojang.minecraftpe.platforms;
import android.app.Activity;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.LinearLayout;
import android.view.WindowManager;
import com.mojang.minecraftpe.platforms.Platform2;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import android.view.WindowManager.LayoutParams;
import android.view.Display;
import android.util.TypedValue;
import android.provider.Settings;
import android.widget.Toast;
import android.content.Intent;
import android.Manifest;
import android.net.Uri;
import java.io.IOException;
import java.io.File;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
public class Platform1 extends Activity {
	
    public static WindowManager manager;
    public static  WindowManager.LayoutParams vParams;
	public static  WindowManager.LayoutParams wParams;
    
    public static  View vTouch;
    public static  WindowManager windowManager,xfqManager;
    
    public static int 真实宽;//分辨率x
    public static int 真实高;//分辨率y
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize(this);
    }
    
    public static void initialize(Context context) {
		loadLib(context, "demo.dat");
        manager = ((Activity) context).getWindowManager();
        vParams = getAttributes(context, false);
        wParams = getAttributes(context, true);
        Platform2 display = new Platform2(context);
        vTouch = new View(context);
        manager.addView(vTouch, vParams);
        manager.addView(display, wParams);

        vTouch.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    int action = event.getAction();
                    switch (action) {
                        case MotionEvent.ACTION_MOVE:
                        case MotionEvent.ACTION_DOWN:
                        case MotionEvent.ACTION_UP:
                            Platform2.MotionEventClick(action != MotionEvent.ACTION_UP, event.getRawX(), event.getRawY());
                            break;
                        default:
                            break;
                    }
                   return false;
                }
            });
        startRectUpdater();
        }

    // Ruta usada cuando el cliente va inyectado dentro del APK de Minecraft:
    // el overlay se agrega cuando el juego ya esta resumido.
    public static boolean overlayStarted = false;

    public static Activity hostActivity;

    public static void initializeOverlay(Activity activity) {
        if (overlayStarted) return;
        overlayStarted = true;

        loadLib(activity.getApplicationContext(), "demo.dat");

        hostActivity = activity;
        manager = activity.getWindowManager();
        // va primero para quedar debajo de la ventana del menu
        createBlurWindow(activity);
        vParams = getAttributes(activity, false);
        wParams = getAttributes(activity, true);

        Platform2 display = new Platform2(activity);
        vTouch = new View(activity);

        manager.addView(display, wParams);
        manager.addView(vTouch, vParams);

        vTouch.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    int action = event.getAction();
                    switch (action) {
                        case MotionEvent.ACTION_MOVE:
                        case MotionEvent.ACTION_DOWN:
                        case MotionEvent.ACTION_UP:
                            Platform2.MotionEventClick(action != MotionEvent.ACTION_UP, event.getRawX(), event.getRawY());
                            break;
                        default:
                            break;
                    }
                   return true;
                }
            });
        startRectUpdater();
    }

    private static void startRectUpdater() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        String rect[] = Platform2.getWindowRect().split("\\|");
                        vParams.x = Integer.parseInt(rect[0]);
                        vParams.y = Integer.parseInt(rect[1]);
                        vParams.width = Integer.parseInt(rect[2]);
                        vParams.height = Integer.parseInt(rect[3]);
                        manager.updateViewLayout(vTouch, vParams);
                    } catch (Exception e) {
                    }
                    try {
                        updateBlurWindow();
                        pollTextInput();
                        updateExtraTouch();
                    } catch (Throwable ignored) {
                    }
                    handler.postDelayed(this, 20);
                }
            }, 20);
    }

    // -----------------------------------------------------------------------
    // Botones en pantalla: cada uno necesita su propia zona tactil, porque la
    // vista del menu cubre un solo rectangulo. Se mantiene un grupo de vistas
    // y se esconden las que sobran.
    // -----------------------------------------------------------------------
    private static final java.util.ArrayList<View> extraTouch = new java.util.ArrayList<View>();
    private static final java.util.ArrayList<WindowManager.LayoutParams> extraParams = new java.util.ArrayList<WindowManager.LayoutParams>();

    private static final View.OnTouchListener forwardTouch = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getActionMasked();
            switch (action) {
                case MotionEvent.ACTION_MOVE:
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    boolean down = action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE;
                    Platform2.MotionEventClick(down, event.getRawX(), event.getRawY());
                    break;
                default:
                    break;
            }
            return true;
        }
    };

    private static void updateExtraTouch() {
        if (hostActivity == null) return;
        String data = Platform2.getExtraRects();
        String[] rects = (data == null || data.isEmpty()) ? new String[0] : data.split(";");
        while (extraTouch.size() < rects.length) {
            View view = new View(hostActivity);
            WindowManager.LayoutParams params = getAttributes(hostActivity, false);
            params.width = 1;
            params.height = 1;
            view.setOnTouchListener(forwardTouch);
            view.setVisibility(View.GONE);
            manager.addView(view, params);
            extraTouch.add(view);
            extraParams.add(params);
        }
        for (int i = 0; i < extraTouch.size(); i++) {
            View view = extraTouch.get(i);
            if (i >= rects.length) {
                if (view.getVisibility() != View.GONE) view.setVisibility(View.GONE);
                continue;
            }
            String[] r = rects[i].split("\\|");
            if (r.length != 4) continue;
            WindowManager.LayoutParams params = extraParams.get(i);
            int x = Integer.parseInt(r[0]), y = Integer.parseInt(r[1]);
            int w = Math.max(1, Integer.parseInt(r[2])), h = Math.max(1, Integer.parseInt(r[3]));
            if (params.x != x || params.y != y || params.width != w || params.height != h) {
                params.x = x;
                params.y = y;
                params.width = w;
                params.height = h;
                manager.updateViewLayout(view, params);
            }
            if (view.getVisibility() != View.VISIBLE) view.setVisibility(View.VISIBLE);
        }
    }

    // -----------------------------------------------------------------------
    // Desenfoque real detras del menu: una ventana transparente debajo del
    // menu, del tamaño del menu, con background blur (Android 12+). Es un
    // panel de la ventana del juego (subcapa 1) y el menu va en la subcapa 2.
    // -----------------------------------------------------------------------
    private static Dialog blurDialog;
    private static int appliedBlur = -1;

    private static void createBlurWindow(Activity activity) {
        boolean supported = false;
        try {
            supported = Build.VERSION.SDK_INT >= 31 && activity.getWindowManager().isCrossWindowBlurEnabled();
        } catch (Throwable ignored) {
        }
        try {
            Platform2.setBlurSupported(supported);
        } catch (Throwable ignored) {
        }
        if (!supported) return;
        try {
            Dialog dialog = new Dialog(activity, android.R.style.Theme_Translucent_NoTitleBar);
            dialog.setContentView(new View(activity));
            dialog.setCancelable(false);
            Window window = dialog.getWindow();
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setType(WindowManager.LayoutParams.TYPE_APPLICATION_PANEL);
            window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setWindowAnimations(0);
            window.setGravity(Gravity.TOP | Gravity.LEFT);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.x = 0;
            lp.y = 0;
            lp.width = 1;
            lp.height = 1;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            window.setAttributes(lp);
            dialog.show();
            blurDialog = dialog;
        } catch (Throwable t) {
            blurDialog = null;
            try {
                Platform2.setBlurSupported(false);
            } catch (Throwable ignored) {
            }
        }
    }

    private static void updateBlurWindow() {
        if (blurDialog == null) return;
        int radius = Platform2.getBlurRadius();
        boolean visible = radius > 0 && vParams.width > 1 && vParams.height > 1;
        Window window = blurDialog.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        int x = visible ? vParams.x : 0;
        int y = visible ? vParams.y : 0;
        int width = visible ? vParams.width : 1;
        int height = visible ? vParams.height : 1;
        if (lp.x != x || lp.y != y || lp.width != width || lp.height != height) {
            lp.x = x;
            lp.y = y;
            lp.width = width;
            lp.height = height;
            window.setAttributes(lp);
        }
        int blur = visible ? radius : 0;
        if (blur != appliedBlur && Build.VERSION.SDK_INT >= 31) {
            window.setBackgroundBlurRadius(blur);
            appliedBlur = blur;
        }
    }

    // -----------------------------------------------------------------------
    // Entrada de texto: el overlay no puede tener foco, asi que el buscador y
    // los nombres de perfil abren un dialogo con el teclado de Android. El
    // texto se manda al cliente mientras se escribe (filtro en vivo).
    // -----------------------------------------------------------------------
    private static AlertDialog textDialog;

    private static void pollTextInput() {
        if (hostActivity == null) return;
        if (textDialog != null && textDialog.isShowing()) return;
        String request = Platform2.pollTextRequest();
        if (request == null) return;
        String[] parts = request.split("\u0001", -1);
        if (parts.length < 4) return;
        final String initial = parts[1];

        final EditText input = new EditText(hostActivity);
        input.setSingleLine(true);
        input.setHint(parts[0]);
        input.setText(initial);
        input.setSelection(initial.length());
        input.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                Platform2.submitText(s.toString(), false);
            }
        });

        // Sin titulo ni botones: en horizontal el teclado ocupa casi toda la
        // pantalla. El check del teclado confirma y Atras cancela.
        final AlertDialog dialog = new AlertDialog.Builder(hostActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setView(input)
                .create();
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            public void onCancel(DialogInterface d) {
                Platform2.submitText(initial, true);
            }
        });
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    Platform2.submitText(input.getText().toString(), true);
                    dialog.dismiss();
                    return true;
                }
                return false;
            }
        });

        // dialogo normal de la app: queda encima de la ventana del juego y de
        // sus paneles (el menu)
        Window window = dialog.getWindow();
        if (window != null) {
            window.setGravity(Gravity.TOP);
            // sin oscurecer: el filtro se ve en vivo detras del dialogo
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        textDialog = dialog;
        dialog.show();
        input.requestFocus();
    }

	public static void loadLib(Context context, String libraryName) {
        try {
            System.loadLibrary("ReverseSigma");
            return;
        } catch (Throwable ignored) {
        }
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("assets/icu/" + libraryName);
            File libraryDir = context.getDir("lib", Context.MODE_PRIVATE);
            File outputFile = new File(libraryDir, libraryName);
            OutputStream outputStream = new FileOutputStream(outputFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            System.load(outputFile.getAbsolutePath());
        } catch (IOException e) {
        }
    }
	public static WindowManager.LayoutParams getAttributes(Context context, boolean isWindow) {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        int additionalFlags = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            additionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.CUPCAKE) {
            additionalFlags |= WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
        }

        // ОПРЕДЕЛИТЕ ЗДЕСЬ НУЖНЫЕ РАЗМЕРЫ.  Примеры:
		int width = WindowManager.LayoutParams.WRAP_CONTENT;
        int height = WindowManager.LayoutParams.WRAP_CONTENT;

        if (isWindow) {
            width = WindowManager.LayoutParams.MATCH_PARENT;
            height = WindowManager.LayoutParams.MATCH_PARENT;
        }

        params.width = width;
        params.height = height;

        params.x = 0;
        params.y = 0;

        // Panel colgado de la ventana del juego, no una ventana "sobre otras
        // apps": no necesita el permiso de superposicion y Android no le
        // limita la opacidad. El WindowManager de la activity le pone el token.
        params.type = WindowManager.LayoutParams.TYPE_APPLICATION_SUB_PANEL;

        // **ВНИМАНИЕ:** Флаги определяют поведение окна. Удалите , если окно должно получать ввод.
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			WindowManager.LayoutParams.FLAG_SPLIT_TOUCH |
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |additionalFlags;

        if (isWindow) {
            flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; // Или другие нужные флаги
        }

        params.flags = flags;

        params.format = PixelFormat.RGBA_8888;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        if (!isWindow) params.gravity = Gravity.TOP | Gravity.LEFT;

        return params;
    }
}
