package com.mojang.minecraftpe.platforms;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

// Se ejecuta solo al arrancar el proceso: los providers se instancian antes que
// cualquier activity. Engancha el ciclo de vida y arranca el overlay cuando el
// juego ya esta en pantalla.
public class Bootstrap extends ContentProvider {

    private static boolean started = false;

    @Override
    public boolean onCreate() {
        Application app = (Application) getContext().getApplicationContext();
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            public void onActivityCreated(Activity activity, Bundle bundle) {}
            public void onActivityStarted(Activity activity) {}
            public void onActivityResumed(Activity activity) { tryStart(activity); }
            public void onActivityPaused(Activity activity) {}
            public void onActivityStopped(Activity activity) {}
            public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {}
            public void onActivityDestroyed(Activity activity) {}
        });
        return true;
    }

    private void tryStart(final Activity activity) {
        if (started || activity == null) return;

        // el menu va en paneles de la ventana del juego: no hace falta el
        // permiso de "mostrar sobre otras apps"
        started = true;
        // deja terminar el arranque del juego antes de tocar sus funciones
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    Platform1.initializeOverlay(activity);
                } catch (Throwable t) {
                    started = false;
                }
            }
        }, 2500);
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
