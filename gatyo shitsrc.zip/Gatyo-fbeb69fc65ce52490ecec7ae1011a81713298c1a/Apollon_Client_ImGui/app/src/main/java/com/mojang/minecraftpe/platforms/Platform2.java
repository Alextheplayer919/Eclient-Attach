package com.mojang.minecraftpe.platforms;
import android.opengl.GLSurfaceView;
import android.content.Context;
import android.graphics.PixelFormat;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.EGLConfig;

public class Platform2 extends GLSurfaceView implements GLSurfaceView.Renderer {

    public static byte fontData[];
    private Context context;

    public Platform2(Context context) {
        super(context);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        getHolder().setFormat(-3);
        setEGLContextClientVersion(3);
        setRenderer(this);
        this.context = context;
    }

    public void onDrawFrame(GL10 gl) {
        step();
    }

    public void onSurfaceChanged(GL10 gl, int width, int height) {
        resize(width, height);
    }

    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        init();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        imgui_Shutdown();
    }

    public static native void init();

    public static native void resize(int width, int height);

    public static native void step();

    public static native void imgui_Shutdown();

    public static native void MotionEventClick(boolean down, float PosX, float PosY);

    public static native String getWindowRect();

    // Rectangulos de los botones en pantalla: "x|y|w|h;x|y|w|h;..." (vacio = ninguno).
    public static native String getExtraRects();

    // Pedido de texto pendiente: "titulo\u0001texto\u0001aceptar\u0001cancelar" o null.
    public static native String pollTextRequest();

    public static native void submitText(String text, boolean done);

    // Radio del desenfoque detras del menu en px (0 = sin desenfoque).
    public static native int getBlurRadius();

    public static native void setBlurSupported(boolean supported);
}
