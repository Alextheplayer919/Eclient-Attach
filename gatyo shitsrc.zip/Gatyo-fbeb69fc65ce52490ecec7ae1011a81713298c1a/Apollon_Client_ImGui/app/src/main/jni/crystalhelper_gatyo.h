#pragma once
// CrystalHelper: mientras tienes un cristal en la mano, cualquier toque activa
// una ventana de rastreo corto: si aparece un EndCrystal a 6 bloques o menos,
// lo golpea. Portado del CrystalHelper de GatoClient, con el mismo camino del
// resto de la suite: el hook de useItemOn avisa con la intencion (protegido
// con cooldown para que toques seguidos no reinicien el rastreo para siempre)
// y el golpe real sale del NormalTick.

#if defined(__aarch64__)

static bool g_achWas = false;
static int g_achScanTicks = 0;   // ventana de rastreo activa (ticks)
static int g_achCooldown = 0;    // margen AntiMasilla entre toques

static void AcHelperOnUseItemOn(void* gm, void* stack) {
	if (!crystalHelper || panic || !localPlayer) return;
	// solo toques con cristal en la mano y del propio jugador (el GameMode del
	// servidor de un mundo local no cuenta)
	if (!gm || (void*)gm != (void*)localPlayer->getGameMode()) return;
	if (!AcIsEndCrystalItem(stack)) return;
	if (g_achCooldown > 0) return;
	g_achScanTicks = 19;  // ~1 s de rastreo
	g_achCooldown = 6;
}

static void CrystalHelperOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!crystalHelper) {
		g_achWas = false;
		g_achScanTicks = 0;
		g_achCooldown = 0;
		return;
	}
	g_achWas = true;
	AcAdvanceTick();
	if (g_achCooldown > 0) g_achCooldown--;
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	if (g_achScanTicks <= 0) return;
	g_achScanTicks--;

	GaxV3 eye = GaxPos(lp);
	AcEntity* best = nullptr;
	float bestDist = 6.0f;
	std::vector<AcEntity> crystals = AcCollectCrystals(lp, level, 6.0f);
	for (AcEntity& c : crystals) {
		if (c.dist < bestDist) {
			bestDist = c.dist;
			best = &c;
		}
	}
	if (best) {
		AcAttack(gm, best->actor);
		lp->swing();
		g_achScanTicks = 0;  // golpe dado: se cierra la ventana
	}
}

#else
// Otros ABIs: no-ops con la misma firma.
static void CrystalHelperOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
static void AcHelperOnUseItemOn(void*, void*) {}
#endif
