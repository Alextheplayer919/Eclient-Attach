#pragma once
// AutoAnchor: coloca respawn anchors junto al rival, los carga con glowstone y
// los detona. Portado del AnchorAura de GatoClient (colocar -> cargar ->
// detonar por estado) con las rutas de la suite y estas mejoras:
//
//   - Solo explota fuera del Nether (en el Nether el anchor fija el spawn): la
//     dimension sale de la vtable del Dimension del BlockSource.
//   - Dano propio de la explosion (potencia 5, radio 10) con la exposicion del
//     juego reimplementada y la armadura de cada uno; no actua si el dano al
//     rival queda por debajo del minimo ni si el tuyo pasa el tope o te mataria.
//   - La carga se LEE del bloque (ExAnchorCharge): solo se pone glowstone si el
//     anchor esta en 0, y se detona con un item que no sea bloque. Antes se
//     daba por cargado y se "detonaba" con lo que hubiera en la mano: si la
//     carga no habia llegado y en la mano habia un bloque (otro anchor), el clic
//     lo colocaba encima, y asi se apilaban sin explotar.
//   - Un anchor a medias (puesto o cargado sin explotar) se termina antes de
//     poner otro, y los anchors que ya estan junto al rival (propios o ajenos)
//     son candidatos: se detonan en vez de colocar uno nuevo. Si el servidor no
//     acepta la carga de un anchor, se abandona y no se vuelve a intentar un
//     rato.
//   - Candidatos nuevos: celdas de aire alrededor del rival (Proximity), dentro
//     del alcance, con un vecino macizo donde apoyarlas (nunca un cofre, mesa
//     o cualquier bloque que reaccione al clic) y libres de entidades. Mejor
//     por dano (con el dano propio restando) o por distancia.
//   - Render: la caja del anchor desliza entre posiciones, muestra sus cargas
//     arriba y el dano; al explotar deja una onda.

enum AutoAnchorStatus {
	AA_ST_IDLE, AA_ST_NO_TARGET, AA_ST_NETHER, AA_ST_NO_ANCHOR, AA_ST_NO_GLOWSTONE, AA_ST_NO_SPOT,
	AA_ST_LOW_DAMAGE, AA_ST_SELF_DAMAGE, AA_ST_WORKING, AA_ST_PAUSED, AA_ST_NO_SWITCH, AA_ST_NO_DETONATOR,
	AA_ST_REJECTED,
};
static std::atomic<int> g_aaStatus{AA_ST_IDLE};
static std::atomic<int> g_aaStatLow{0}, g_aaStatSelf{0};

static std::string AutoAnchorStatusText() {
	switch (g_aaStatus.load()) {
		case AA_ST_NO_TARGET: return T(S_AcxStNoTarget);
		case AA_ST_NETHER: return T(S_AaStNether);
		case AA_ST_NO_ANCHOR: return T(S_AaStNoAnchor);
		case AA_ST_NO_GLOWSTONE: return T(S_AaStNoGlowstone);
		case AA_ST_NO_SPOT: return T(S_AaStNoSpot);
		case AA_ST_LOW_DAMAGE: return TF(S_AcxStLowDamage, g_aaStatLow.load(), aaEnemyDamage);
		case AA_ST_SELF_DAMAGE: return TF(S_AaStSelfDamage, g_aaStatSelf.load(), aaSelfDamage);
		case AA_ST_WORKING: return T(S_AaStWorking);
		case AA_ST_PAUSED: return T(S_AcxStPaused);
		case AA_ST_NO_SWITCH: return T(S_AcxStNoSwitch);
		case AA_ST_NO_DETONATOR: return T(S_AaStNoDetonator);
		case AA_ST_REJECTED: return T(S_AaStRejected);
	}
	return T(S_AcxStOff);
}

static ExOverlay g_aaOverlay;

#if defined(__aarch64__)

static const int kAaRetryTicks = 4;     // una colocacion intentada espera al servidor
static const int kAaJobTicks = 80;      // un anchor a medias se abandona tras ~4 s
static const int kAaRejectTicks = 200;  // un anchor que no acepta carga se evita ~10 s
static bool g_aaWas = false;
static uint32_t g_aaLastAct = 0;
static AcRetryRing g_aaRetry;
static ExAnchorJob g_aaJob;
static std::unordered_map<uint64_t, uint32_t> g_aaAvoid;  // celda -> tick hasta el que se evita
// Freno: si los anchors no llegan a explotar (carga rechazada, nada con que
// detonar), no se ponen anchors NUEVOS hasta este tick; los que ya estan se
// siguen usando. Asi nunca se llena el piso de anchors.
static uint32_t g_aaNoNewUntil = 0;
static int g_aaFailures = 0;
static const int kAaBackoffTicks = 60;

static void AaReset() {
	g_aaWas = false;
	g_aaLastAct = 0;
	g_aaRetry.Clear();
	g_aaJob = ExAnchorJob();
	g_aaAvoid.clear();
	g_aaNoNewUntil = 0;
	g_aaFailures = 0;
	ExPublish(g_aaOverlay, {});
}

static void AaFailure() {
	if (++g_aaFailures >= 2) g_aaNoNewUntil = g_acTick + kAaBackoffTicks;
}

static bool AaAvoided(const vec3_ti& c) {
	auto it = g_aaAvoid.find(AcPackCell(c.x, c.y, c.z));
	return it != g_aaAvoid.end() && (int32_t)(it->second - g_acTick) > 0;
}

static void AutoAnchorOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!autoAnchor) {
		if (g_aaWas) AaReset();
		g_aaWas = false;
		g_aaStatus = AA_ST_IDLE;
		return;
	}
	g_aaWas = true;
	AcAdvanceTick();
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	if (!ExAnchorExplodes(ExDimensionOf(region))) {
		g_aaStatus = AA_ST_NETHER;
		ExPublish(g_aaOverlay, {});
		return;
	}

	// el anchor en marcha que desaparecio: si ya se habia detonado, exploto
	if (g_aaJob.valid && !ExIsAnchorBlock(AcBlockAt(region, g_aaJob.cell)) && AcTicksSince(g_aaJob.tick) > 2) {
		if (g_aaJob.detonatedAt) {
			ExBurstAtCell(g_aaJob.cell, blastLineColor, 1.0f);
			g_aaFailures = 0;  // exploto: todo bien
		}
		g_aaJob = ExAnchorJob();
	}
	if (g_aaJob.valid && AcTicksSince(g_aaJob.tick) > kAaJobTicks) {
		g_aaAvoid[g_aaJob.key] = g_acTick + kAaRejectTicks;
		g_aaJob = ExAnchorJob();
		AaFailure();
	}
	const bool allowNew = (int32_t)(g_aaNoNewUntil - g_acTick) <= 0;

	if (aaEatStop && AcEatingActive(lp)) {
		g_aaStatus = AA_ST_PAUSED;
		return;
	}
	if (g_aaLastAct && AcTicksSince(g_aaLastAct) < aaDelay) return;

	AcEntity me = AcSelfEntity(lp);
	bool selfImmune = !lp->isAttackableGamemode();
	const GaxV3 eye = GaxPos(lp);
	std::vector<AcEntity> targets = AcCollectTargets(lp, level, aaTargetRange, false);
	std::sort(targets.begin(), targets.end(), [](const AcEntity& a, const AcEntity& b) { return a.dist < b.dist; });
	if (targets.size() > 4) targets.resize(4);
	if (targets.empty()) {
		g_aaStatus = AA_ST_NO_TARGET;
		ExPublish(g_aaOverlay, {});
		return;
	}

	auto enemyBest = [&](const vec3_ti& cell) {
		float best = 0.0f;
		for (const AcEntity& t : targets) best = ImMax(best, ExDamageTo(t, region, ExCenterOf(cell), nullptr));
		return best;
	};
	auto selfAt = [&](const vec3_ti& cell) { return selfImmune ? 0.0f : ExDamageTo(me, region, ExCenterOf(cell), nullptr); };
	auto selfSafe = [&](float d) { return selfImmune || (d <= aaSelfDamage && d < (float)lp->getHealth()); };

	// ---- el plan: el anchor a medias primero, si no el mejor candidato --------
	vec3_ti planCell{0, 0, 0}, planClicked{0, 0, 0};
	unsigned char planFace = 0;
	bool havePlan = false;
	float planEnemy = 0.0f, planSelf = 0.0f;
	int statLow = 0, statSelf = 0;

	if (g_aaJob.valid && ExIsAnchorBlock(AcBlockAt(region, g_aaJob.cell)) && ExDistToBlock(eye, g_aaJob.cell) <= aaPlaceRange + 0.5f) {
		// se termina aunque el dano haya bajado un poco: dejarlo seria otro anchor apilado
		float enemy = enemyBest(g_aaJob.cell), self = selfAt(g_aaJob.cell);
		if (enemy >= aaEnemyDamage * 0.5f && selfSafe(self)) {
			planCell = g_aaJob.cell;
			planEnemy = enemy;
			planSelf = self;
			havePlan = true;
		}
	}

	if (!havePlan) {
		// una sola pasada de entidades para toda la zona de busqueda
		int span = ImClamp(aaProximity, 1, 5);
		float minX = 1e9f, minY = 1e9f, minZ = 1e9f, maxX = -1e9f, maxY = -1e9f, maxZ = -1e9f;
		for (const AcEntity& t : targets) {
			minX = ImMin(minX, t.box.lower.x); maxX = ImMax(maxX, t.box.upper.x);
			minY = ImMin(minY, t.box.lower.y); maxY = ImMax(maxY, t.box.upper.y);
			minZ = ImMin(minZ, t.box.lower.z); maxZ = ImMax(maxZ, t.box.upper.z);
		}
		StCollectBlockers(level, minX - span - 1, minY - 2, minZ - span - 1, maxX + span + 1, maxY + 4, maxZ + span + 1);

		float bestScore = -1e9f;
		int checked = 0;
		for (const AcEntity& t : targets) {
			ExFootprint f = ExFootprintOf(t.box);
			for (int dx = -span; dx <= span && checked < 240; dx++) {
				for (int dz = -span; dz <= span && checked < 240; dz++) {
					for (int dy = -1; dy <= 2 && checked < 240; dy++) {
						vec3_ti cell{f.x0 + dx, f.feetY + dy, f.z0 + dz};
						if (ExDistToBlock(eye, cell) > aaPlaceRange) continue;
						if (AaAvoided(cell)) continue;
						Block* b = AcBlockAt(region, cell);
						bool existing = ExIsAnchorBlock(b);
						vec3_ti clicked{0, 0, 0};
						unsigned char face = 0;
						if (!existing) {
							if (!allowNew || !AcIsAir(b)) continue;
							if (g_aaRetry.Recent(AcPackCell(cell.x, cell.y, cell.z), kAaRetryTicks)) continue;
							if (!StCellFree(cell.x, cell.y, cell.z)) continue;
							if (!ExAnchor(region, cell, clicked, face)) continue;
						}
						checked++;
						float enemy = enemyBest(cell);
						if (enemy < aaEnemyDamage) { statLow++; continue; }
						float self = selfAt(cell);
						if (!selfSafe(self)) { statSelf++; continue; }
						float score = aaPriority == 0 ? enemy - 0.5f * self
													  : -AcDist3F((float)cell.x + 0.5f, (float)cell.y + 0.5f, (float)cell.z + 0.5f, t.pos.x, t.pos.y, t.pos.z);
						if (existing) score += 3.0f;  // ya esta puesto: un anchor menos gastado
						if (score > bestScore) {
							bestScore = score;
							planCell = cell;
							planClicked = clicked;
							planFace = face;
							planEnemy = enemy;
							planSelf = self;
							havePlan = true;
						}
					}
				}
			}
		}
	}
	g_aaStatLow = statLow;
	g_aaStatSelf = statSelf;

	if (!havePlan) {
		g_aaStatus = statSelf > 0 && statLow == 0 ? AA_ST_SELF_DAMAGE : (statLow > 0 ? AA_ST_LOW_DAMAGE : AA_ST_NO_SPOT);
		ExPublish(g_aaOverlay, {});
		return;
	}

	if (aaRotate) AcAimAt(eye, ExCenterOf(planCell));
	int r = ExRunAnchor(lp, gm, region, planCell, planClicked, planFace, aaSwitch, g_aaJob, g_aaRetry);
	switch (r) {
		case EXR_NO_ITEM: g_aaStatus = AA_ST_NO_ANCHOR; break;
		case EXR_NO_GLOWSTONE: g_aaStatus = AA_ST_NO_GLOWSTONE; break;
		case EXR_NO_SWITCH: g_aaStatus = AA_ST_NO_SWITCH; break;
		case EXR_NO_DETONATOR:
			g_aaStatus = AA_ST_NO_DETONATOR;
			g_aaNoNewUntil = g_acTick + kAaBackoffTicks;
			break;
		case EXR_REJECTED:
			g_aaStatus = AA_ST_REJECTED;
			g_aaAvoid[AcPackCell(planCell.x, planCell.y, planCell.z)] = g_acTick + kAaRejectTicks;
			g_aaJob = ExAnchorJob();
			AaFailure();
			break;
		default: g_aaStatus = AA_ST_WORKING; break;
	}
	g_aaLastAct = g_acTick;

	if (aaRender) {
		ExMark m = ExMarkCell(planCell, EXM_ANCHOR, 1);
		m.enemy = planEnemy;
		m.self = selfImmune ? -1.0f : planSelf;
		m.charge = (int8_t)ExAnchorCharge(AcBlockAt(region, planCell));
		snprintf(m.label, sizeof(m.label), m.charge >= 0 ? "ANCHOR %d/4" : "ANCHOR", (int)m.charge);
		ExPublish(g_aaOverlay, {m});
	} else {
		ExPublish(g_aaOverlay, {});
	}
}

#else
// Otros ABIs: no-op con la misma firma.
static void AutoAnchorOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
#endif

static void RenderAutoAnchor(ImDrawList* dl) {
	ExRenderOverlay(dl, g_aaOverlay, autoAnchor && aaRender, aaFade, blastFillColor, blastLineColor);
}
