#pragma once
// AutoCrystal: coloca cristales sobre los bloques que mas danio van a causar y
// rompe los que tiene cerca. Portado del AutoCrystal de GatoClient con las
// capas de este cliente:
//
//   Romper: busca cristales en el Rango de rotura, elige el que mas danio va a
//   hacer, respeta el Retardo de rotura (o la ventana del KA Sync si esta
//   activa) y guarda una lista negra por celda para no machacar el mismo
//   cristal (Inhibit).
//
//   Colocar: escanea bloques base alrededor de cada objetivo (obsidiana o
//   bedrock con espacio encima), calcula el danio con la exposicion del
//   seenPercent, filtra por Danio al objetivo y Danio propio, ordena y suelta
//   hasta Multi Place colocaciones por tick. El cambio de slot usa la
//   separacion cliente/servidor de crystal_common (Ninguno, Normal,
//   Silencioso, Paquete) y se restaura al final del gesto.
//
//   Fallbacks: el Paquete Place y el Paquete Attack del PC usaban paquetes de
//   transaccion que en 1.21.111 siguen sin estar verificados, asi que las
//   acciones salen por las llamadas del juego (buildBlock / attack). Los
//   controles siguen en la UI con el aviso del fallback.
//
//   Render: las marcas se publican por snapshot (g_acMarks), el overlay las
//   copia, las desliza y las desvanece (Slide, Fade) y dibuja caja y textos
//   de danio. Todo en el hilo de ImGui, sin punteros del juego.

#if defined(__aarch64__)
#include <unordered_set>
#include <cstdio>

// ---------------------------------------------------------------------------
// Estado del modulo
// ---------------------------------------------------------------------------
static bool g_acWas = false;          // estaba encendido el tick anterior
static uint32_t g_acLastBreak = 0;    // tick del ultimo golpe
static uint32_t g_acLastPlace = 0;    // tick de la ultima colocacion
static bool g_acAttackedThisTick = false;

static void AcResetAutoCrystal() {
	g_acWas = false;
	g_acLastBreak = 0;
	g_acLastPlace = 0;
	g_acAttackedThisTick = false;
}

// Lista negra de rompidos: celda base -> tick hasta el que hay que dejarla.
static std::unordered_map<AcCellKey, uint32_t, AcCellHash> g_acInhibit;

// ---------------------------------------------------------------------------
// Escaneo de colocaciones
// ---------------------------------------------------------------------------
struct AcPlaceCand {
	vec3_ti base;
	glm::vec3 explosion;
	float enemy;    // danio al objetivo
	float self;     // danio al propio jugador
	float dist;     // del candidato al objetivo (desempate)
};

// Escanea los bloques base validos alrededor de un tgt. El recorrido se acota
// por el Rango de origen (medido desde el jugador) y Proximity, si vale,
// acota la distancia del objetivo al cristal. Devuelve candidatos validos
// (base material, aire encima, jaula sin entidades, sin cristal ya puesto,
// danio al objetivo > 0). Los usados de este tick vienen en "used".
static void AcScanPlaces(BlockSource* region, LocalPlayer* lp, AcEntity& t,
						 float placeRange, float proximityMin, bool phase,
						 const std::vector<GaxBox>& boxes,
						 const std::vector<AcEntity>& crystals,
						 const std::unordered_set<uint64_t>& used,
						 std::vector<AcPlaceCand>& out) {
	GaxV3 lpPos = GaxPos(lp), tPos = t.pos;
	int span = (int)ceilf(placeRange);
	if (span > 8) span = 8;
	int tx = (int)floorf(tPos.x), tz = (int)floorf(tPos.z);
	int ty = (int)floorf(tPos.y);  // pies del objetivo: origen del rango vertical
	const GaxBox* skip = phase ? &t.box : nullptr;
	for (int dx = -span; dx <= span; dx++) {
		for (int dz = -span; dz <= span; dz++) {
			int x = tx + dx, z = tz + dz;
			// corte temprano: el centro del base debe caber en el Place Range
			float pdx = (float)x + 0.5f - lpPos.x, pdz = (float)z + 0.5f - lpPos.z;
			if (pdx * pdx + pdz * pdz > placeRange * placeRange) continue;
			for (int y = ty - 3; y <= ty + 3; y++) {
				vec3_ti base = {x, y, z};
				glm::vec3 exp = AcExplosionOf(base);
				// Proximity: distancia maxima del objetivo al cristal
				float toTarget = AcDistTo(tPos, GaxV3{exp.x, exp.y, exp.z});
				if (proximityMin > 0.0f && toTarget > proximityMin) continue;
				if (!AcCanPlaceAt(region, base, false)) continue;
				uint64_t key = AcPackCell(base.x, base.y, base.z);
				if (used.count(key)) continue;  // ya en la lista de este tick
				bool occupied = false;          // un cristal ya vive alli
				for (const AcEntity& c : crystals) {
					uint64_t ck = AcPackCell((int)floorf(c.pos.x), (int)(c.pos.y - 1.0f), (int)floorf(c.pos.z));
					if (ck == key) { occupied = true; break; }
				}
				if (occupied) continue;
				// jaula libre de entidades (con fase se deja pasar al objetivo)
				if (!AcCageFree(boxes, base, skip)) continue;
				float exposure = AcSeenPercentCached(t.rid, region, t.box, exp);
				float enemy = AcDamage(t.box, exp, exposure);
				if (enemy <= 0.0f) continue;
				float self = AcDamage(GaxAABB(lp), exp, AcSeenPercentCached(AcRuntimeId(lp), region, GaxAABB(lp), exp));
				AcPlaceCand cand;
				cand.base = base;
				cand.explosion = exp;
				cand.enemy = enemy;
				cand.self = self;
				cand.dist = toTarget;
				out.push_back(cand);
			}
		}
	}
}

// ---------------------------------------------------------------------------
// Tick del modulo: el juego llama desde el NormalTick del jugador local.
// ---------------------------------------------------------------------------
static void AutoCrystalOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!autoCrystal) {
		if (g_acWas) AcResetAutoCrystal();
		return;
	}
	g_acWas = true;
	AcAdvanceTick();
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;

	void* ci = (void*)CI;
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	AcSlotsBegin(lp);
	AcClearExpCache();
	g_acAttackedThisTick = false;

	const float collectRange = ImMax(acBreakRange, acPlaceRange) + 1.0f;
	bool eating = !acWhileEating && AcEatingActive(lp);

	std::vector<AcEntity> targets = AcCollectTargets(lp, level, collectRange + 2.0f, acSelf);
	std::sort(targets.begin(), targets.end(), [](const AcEntity& a, const AcEntity& b) {
		return a.dist < b.dist;
	});
	if (targets.size() > 6) targets.resize(6);
	std::vector<GaxBox> boxes = AcCollectBoxes(level, lp);
	std::vector<AcEntity> crystals = AcCollectCrystals(lp, level, collectRange);
	std::vector<AcMark> marks;

	// Purga de la lista negra: expirada = borrada.
	for (auto it = g_acInhibit.begin(); it != g_acInhibit.end(); ) {
		if ((int32_t)(g_acTick - it->second) >= 0) it = g_acInhibit.erase(it);
		else ++it;
	}

	// --------------------------------------------------------------------------
	// Rompe
	// --------------------------------------------------------------------------
	if (!eating && acBreak) {
		bool window = AcTicksSince(g_acLastBreak) >= acBreakDelay ||
					  (acKASync && AcSyncOpen(acPostDelay));
		if (window) {
			struct BreakPick {
				AcEntity* c;
				uint64_t key;   // celda base del cristal (para Inhibit)
				glm::vec3 exp;
				float dmg;
			};
			std::vector<BreakPick> picks;
			picks.reserve(crystals.size());
			for (AcEntity& c : crystals) {
				if (c.dist > acBreakRange) continue;  // la lista llega un bloque mas lejos
				int cx = (int)floorf(c.pos.x), cy = (int)(c.pos.y - 1.0f), cz = (int)floorf(c.pos.z);
				uint64_t key = AcPackCell(cx, cy, cz);
				auto inh = g_acInhibit.find(AcCellKey(vec3_ti{cx, cy, cz}));
				if (inh != g_acInhibit.end() && (int32_t)(g_acTick - inh->second) < 0) continue;
				glm::vec3 exp(c.pos.x, c.pos.y, c.pos.z);  // explota en su centro
				float selfD = AcDamage(GaxAABB(lp), exp, AcSeenPercentCached(AcRuntimeId(lp), region, GaxAABB(lp), exp));
				if (selfD >= (float)lp->getHealth()) continue;  // no suicidarse
				float best = 0.0f;
				for (AcEntity& t : targets) {
					float d = AcDamage(t.box, exp, AcSeenPercentCached(t.rid, region, t.box, exp));
					if (d > best) best = d;
				}
				if (best <= 0.0f) continue;
				picks.push_back({&c, key, exp, best});
			}
			std::sort(picks.begin(), picks.end(), [](const BreakPick& a, const BreakPick& b) {
				return a.dmg > b.dmg;
			});
			if (!picks.empty()) {
				BreakPick& best = picks.front();
				AcAttack(gm, best.c->actor);
				lp->swing();
				g_acLastBreak = g_acTick;
				g_acAttackedThisTick = true;
				if (acInhibit) {
					uint32_t hold = g_acTick + (uint32_t)ImMax(4, acBreakDelay);
					g_acInhibit.insert_or_assign(AcCellKey(vec3_ti{(int)floorf(best.exp.x), (int)(best.exp.y - 1.0f), (int)floorf(best.exp.z)}), hold);
				}
				if (acRotate) AcAimAt(GaxPos(lp), best.exp);
			}
		}
	}

	// --------------------------------------------------------------------------
	// Coloca (con multitarea: se dejan hacer en el mismo tick, si no, se
	// alternan romper y colocar)
	// --------------------------------------------------------------------------
	if (!eating && acPlace && (acMultitask || !g_acAttackedThisTick) &&
		!(acAlternate && g_acAttackedThisTick) && AcHasItem(lp, Ac::NameEndCrystal)) {
		int multi = acMultiPlace < 1 ? 1 : acMultiPlace;
		if (multi > acBuildSpeed) multi = acBuildSpeed < 1 ? 1 : acBuildSpeed;
		int interval = acPlaceDelay <= 0 ? 0 : ImMax(0, acPlaceDelay / multi);
		bool window = AcTicksSince(g_acLastPlace) >= interval ||
					  (acKASync && AcSyncOpen(acPostDelay));
		if (window) {
			std::unordered_set<uint64_t> used;
			std::vector<AcPlaceCand> cands;
			cands.reserve(48);
			bool stopped = false;
			for (AcEntity& t : targets) {
				if (cands.size() >= 96) break;
				size_t before = cands.size();
				AcScanPlaces(region, lp, t, acPlaceRange, acProximity, false, boxes,
							 crystals, used, cands);
				if (cands.size() == before && targets.size() == 1) stopped = true;
			}
			(void)stopped;
			if (!cands.empty()) {
				for (AcPlaceCand& c : cands) {
					if (c.enemy < acEnemyDamage) { c.enemy = -1.0f; continue; }
					if (acSelfDamage > 0.0f && c.self > acSelfDamage) c.enemy = -1.0f;
				}
				// prioridad: 0 = mas danio; 1 = mas danio con premio a cercania
				std::sort(cands.begin(), cands.end(), [](const AcPlaceCand& a, const AcPlaceCand& b) {
					if (a.enemy < 0.0f || b.enemy < 0.0f) return a.enemy > b.enemy;
					if (acPriority == 1) {
						float aa = a.enemy - a.dist * 0.25f;
						float bb = b.enemy - b.dist * 0.25f;
						if (fabsf(aa - bb) > 0.15f) return aa > bb;
					}
					if (fabsf(a.enemy - b.enemy) > 0.01f) return a.enemy > b.enemy;
					return a.dist < b.dist;
				});
				int flushed = 0;
				for (AcPlaceCand& c : cands) {
					if (c.enemy < 0.0f) continue;
					if (flushed >= multi) break;
					int slot = AcSwitchSlot(lp, ci, acSwitch, Ac::NameEndCrystal);
					if (slot < 0) break;  // sin cristal en el inventario
					if (acRotate) AcAimAt(GaxPos(lp), c.explosion);
					OffhandFn<void (*)(void*, const void*, unsigned char, bool)>(Ac::GameModeBuildBlock)(
						(void*)gm, &c.base, 0, false);
					used.insert(AcPackCell(c.base.x, c.base.y, c.base.z));
					g_acLastPlace = g_acTick;
					flushed++;
					AcMark m;
					m.x = (float)c.base.x + 0.5f;
					m.y = (float)c.base.y + 0.5f;
					m.z = (float)c.base.z + 0.5f;
					m.enemy = c.enemy;
					m.self = c.self;
					m.flat = acFlat;
					marks.push_back(m);
				}
			}
		}
	}

	// Fin del gesto: devuelve el slot (cliente y anuncio) a su estado original.
	AcSlotsEnd(lp, ci);
	AcStoreMarks(g_acMarks, marks);
	AcClearExpCache();
}

// ---------------------------------------------------------------------------
// Render overlay: marcas con deslizamiento y desvanecimiento por celda
// ---------------------------------------------------------------------------
struct AcFadeState {
	float yOffset = 0.5f;
	float alpha = 0.0f;
	double lastSeen = -1000.0;
};

static std::vector<AcMark> g_acOverlay;   // copia del frame
static std::unordered_map<uint64_t, AcFadeState> g_acFade;
static double g_acOverlayLast = 0.0;

// Celda entera del centro de la marca (clave estable de animacion).
static inline uint64_t AcRenderKey(const AcMark& m) {
	int x = (int)floorf(m.x), y = (int)floorf(m.y), z = (int)floorf(m.z);
	return (uint64_t)(uint32_t)(x & 0x1FFFFF) |
		   ((uint64_t)(uint32_t)(z & 0x1FFFFF) << 21) |
		   ((uint64_t)(uint32_t)(y & 0x1FFFFF) << 42);
}

static void RenderAutoCrystal(ImDrawList* dl, vec3_t cameraPos, glm::vec2 axisFov, glm::mat4 viewMatrix) {
	if (!g_viewValid || !autoCrystal || !acRender) {
		if (g_acFade.size() > 256) g_acFade.clear();
		return;
	}
	double now = AcNow();
	float dt = (float)ImMax(0.001, now - g_acOverlayLast);
	g_acOverlayLast = now;
	float fadeDur = ImMax(0.25f, (float)acFadeDuration * 0.05f);

	{  // copia del snapshot del juego
		std::lock_guard<std::mutex> lock(g_acMarks.mutex);
		g_acOverlay = g_acMarks.shared;
	}

	// refresca "visto ahora" y crea entradas nuevas
	for (AcMark& m : g_acOverlay) {
		uint64_t key = AcRenderKey(m);
		auto it = g_acFade.find(key);
		if (it == g_acFade.end()) {
			AcFadeState st;             // entra desde arriba y transparente
			g_acFade[key] = st;
			it = g_acFade.find(key);
		}
		it->second.lastSeen = now;
	}

	// animacion de todas las entradas (las vistas suben el alpha y bajan el
	// deslizamiento; las que salieron se desvanecen y se borran)
	for (auto it = g_acFade.begin(); it != g_acFade.end(); ) {
		AcFadeState& st = it->second;
		bool seen = (st.lastSeen >= now);
		if (seen) {
			st.alpha = acFade ? ImMin(1.0f, st.alpha + dt * (1.0f / ImMax(0.2f, fadeDur * 0.25f))) : 1.0f;
			st.yOffset = acSlide ? AcApproach(st.yOffset, 0.0f, ImMax(1.0f, acSlideSpeed), dt) : 0.0f;
			++it;
		} else if (acFade) {
			st.alpha -= dt / fadeDur;
			if (st.alpha <= 0.0f) it = g_acFade.erase(it);
			else ++it;
		} else {
			it = g_acFade.erase(it);
		}
	}

	// dibujo
	for (AcMark& m : g_acOverlay) {
		auto it = g_acFade.find(AcRenderKey(m));
		if (it == g_acFade.end() || it->second.alpha <= 0.0f) continue;
		float a = it->second.alpha;
		glm::vec3 lo(m.x - 0.5f, m.y + 0.5f + it->second.yOffset, m.z - 0.5f);
		glm::vec3 hi(m.x + 0.5f, lo.y + (m.flat ? 0.08f : 1.0f), m.z + 0.5f);
		ImVec4 fill(acFillColor[0], acFillColor[1], acFillColor[2], acFillColor[3] * a);
		ImVec4 line(acLineColor[0], acLineColor[1], acLineColor[2], acLineColor[3] * a);
		GatyoBox3D(dl, g_view, lo, hi,
				   ImGui::ColorConvertFloat4ToU32(line), ImMax(1.0f, 1.2f * scaleGlobal),
				   ImGui::ColorConvertFloat4ToU32(fill), 0);
		if (acDamageText) {
			char txt[8];
			snprintf(txt, sizeof(txt), "%.0f", m.enemy);
			float fs = 9.0f * ImMax(0.6f, scaleGlobal);
			glm::vec3 top(m.x, hi.y + 0.05f, m.z);
			GatyoText3D(dl, g_view, top, txt,
						ImGui::ColorConvertFloat4ToU32(ImVec4(acTextColor[0], acTextColor[1], acTextColor[2], acTextColor[3] * a)), fs);
			if (m.self > 0.4f) {
				snprintf(txt, sizeof(txt), "-%.0f", m.self);
				glm::vec3 below(m.x, hi.y + 0.5f, m.z);
				GatyoText3D(dl, g_view, below, txt,
							ImGui::ColorConvertFloat4ToU32(ImVec4(1.0f, 0.35f, 0.35f, acTextColor[3] * a)), fs * 0.8f);
			}
		}
	}
}

#else
// Otros ABIs: no-ops con la misma firma.
static void AutoCrystalOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
static void RenderAutoCrystal(ImDrawList*, vec3_t, glm::vec2, glm::mat4) {}
#endif
