#pragma once
// Fondos animados del menu y del ClickGUI. Todos usan la paleta de Gatyo y el
// reloj de animacion (se congelan con las animaciones apagadas). `min`/`max`
// es la zona a cubrir; lo que sale de ella lo recorta la ventana.

enum GatyoBackground {
	BG_NONE, BG_DOTS, BG_AURORA, BG_PARTICLES, BG_GRID, BG_WAVES, BG_STARS, BG_GRADIENT, BG_COUNT
};

static const StrId kBackgroundNames[BG_COUNT] = {
	S_BgNone, S_BgDots, S_BgAurora, S_BgParticles, S_BgGrid, S_BgWaves, S_BgStars, S_BgGradient,
};

static float BgIntensity() {
	return ImClamp(uiBgIntensity, 0.1f, 1.0f);
}

// Paso de simulacion para los fondos con particulas (0 si estan congelados).
static float BgDeltaTime() {
	return uiAnimations ? ImMin(ImGui::GetIO().DeltaTime, 0.05f) * uiAnimSpeed : 0.0f;
}

// Bandas de luz ondulantes que cruzan la zona, con los dos colores del flow.
static void DrawAurora(ImDrawList* dl, ImVec2 min, ImVec2 max) {
	GatyoPalette p = GatyoGetPalette();
	float t = GatyoAnimTime();
	float w = max.x - min.x, h = max.y - min.y;
	const int slices = 48;
	ImVec4 colors[3] = {GatyoRgb(flowColorA), p.accent, GatyoRgb(flowColorB)};
	for (int band = 0; band < 3; band++) {
		float thickness = h * (0.16f + 0.05f * band);
		ImVec4 c = GatyoAlpha(colors[band], 0.26f * BgIntensity());
		ImU32 solid = GatyoU32(c);
		ImU32 clear = GatyoU32(GatyoAlpha(c, 0.0f));
		for (int i = 0; i < slices; i++) {
			float x0 = min.x + w * i / slices;
			float x1 = min.x + w * (i + 1) / slices;
			float xm = (x0 + x1) * 0.5f;
			float center = min.y + h * (0.32f + 0.14f * band)
			             + sinf(xm * 0.0035f + t * (0.45f + 0.12f * band) + band * 2.1f) * h * 0.10f
			             + sinf(xm * 0.0011f - t * 0.25f + band) * h * 0.06f;
			dl->AddRectFilledMultiColor(ImVec2(x0, center - thickness), ImVec2(x1, center), clear, clear, solid, solid);
			dl->AddRectFilledMultiColor(ImVec2(x0, center), ImVec2(x1, center + thickness), solid, solid, clear, clear);
		}
	}
}

// Bokeh: circulos suaves que suben despacio, con halo.
struct BgParticle {
	ImVec2 pos;
	float speed;
	float radius;
	float phase;
	int tone;
};
static std::vector<BgParticle> g_bgParticles;

static void DrawParticles(ImDrawList* dl, ImVec2 min, ImVec2 max) {
	GatyoPalette p = GatyoGetPalette();
	ImVec2 display = ImGui::GetIO().DisplaySize;
	int count = ImClamp(uiBgDotsDensity / 3, 10, 140);
	float s = ImMax(scaleGlobal, 0.5f);
	while ((int)g_bgParticles.size() < count) {
		BgParticle b;
		b.pos = ImVec2(randomFloat(0, display.x), randomFloat(0, display.y));
		b.speed = randomFloat(12.0f, 40.0f) * s;
		b.radius = randomFloat(3.0f, 14.0f) * s;
		b.phase = randomFloat(0.0f, 6.28f);
		b.tone = (int)randomFloat(0.0f, 2.99f);
		g_bgParticles.push_back(b);
	}
	if ((int)g_bgParticles.size() > count) g_bgParticles.resize(count);

	float dt = BgDeltaTime();
	float t = GatyoAnimTime();
	ImVec4 tones[3] = {p.accent, p.secondary, GatyoRgb(flowColorB)};
	for (BgParticle& b : g_bgParticles) {
		b.pos.y -= b.speed * dt;
		b.pos.x += sinf(t * 0.8f + b.phase) * 10.0f * s * dt;
		if (b.pos.y < -b.radius * 3.0f) {
			b.pos.y = display.y + b.radius * 3.0f;
			b.pos.x = randomFloat(0, display.x);
		}
		if (b.pos.x < min.x - 40 || b.pos.x > max.x + 40 || b.pos.y < min.y - 40 || b.pos.y > max.y + 40) continue;
		float twinkle = 0.65f + 0.35f * sinf(t * 1.7f + b.phase);
		ImVec4 c = tones[b.tone];
		for (int ring = 3; ring >= 1; ring--) {
			float a = (ring == 1 ? 0.55f : 0.12f / ring) * twinkle * BgIntensity();
			dl->AddCircleFilled(b.pos, b.radius * (1.0f + (ring - 1) * 0.9f), GatyoU32(GatyoAlpha(c, a)), 20);
		}
	}
}

// Rejilla en perspectiva que avanza hacia la camara, con brillo en el horizonte.
static void DrawGrid(ImDrawList* dl, ImVec2 min, ImVec2 max) {
	GatyoPalette p = GatyoGetPalette();
	float t = GatyoAnimTime();
	float w = max.x - min.x, h = max.y - min.y;
	float horizon = min.y + h * 0.42f;
	float cx = (min.x + max.x) * 0.5f;
	float intensity = BgIntensity();
	float thick = ImMax(1.0f, 1.4f * scaleGlobal);

	ImU32 glow = GatyoU32(GatyoAlpha(p.secondary, 0.30f * intensity));
	ImU32 clear = GatyoU32(GatyoAlpha(p.secondary, 0.0f));
	dl->AddRectFilledMultiColor(ImVec2(min.x, horizon - h * 0.18f), ImVec2(max.x, horizon), clear, clear, glow, glow);
	dl->AddLine(ImVec2(min.x, horizon), ImVec2(max.x, horizon), GatyoU32(GatyoAlpha(p.secondary, 0.7f * intensity)), thick * 1.5f);

	// lineas horizontales: se acercan con el tiempo y se separan con la distancia
	const int rows = 14;
	float scroll = fmodf(t * 0.35f, 1.0f);
	for (int i = 0; i < rows; i++) {
		float z = (i + scroll) / rows;
		float y = horizon + (max.y - horizon) * z * z;
		dl->AddLine(ImVec2(min.x, y), ImVec2(max.x, y), GatyoU32(GatyoAlpha(p.accent, 0.55f * z * intensity)), thick);
	}
	// lineas verticales que convergen en el punto de fuga
	const int columns = 12;
	float spreadBottom = w * 1.6f / columns;
	float spreadTop = w * 0.08f / columns;
	for (int i = -columns; i <= columns; i++) {
		ImVec2 top(cx + i * spreadTop, horizon);
		ImVec2 bottom(cx + i * spreadBottom, max.y);
		dl->AddLine(top, bottom, GatyoU32(GatyoAlpha(p.accent, 0.40f * intensity)), thick);
	}
}

// Capas de ondas senoidales con el degradado de marca y relleno tenue.
static void DrawWaves(ImDrawList* dl, ImVec2 min, ImVec2 max) {
	float t = GatyoAnimTime();
	float w = max.x - min.x, h = max.y - min.y;
	const int layers = 4;
	const int segments = 64;
	float intensity = BgIntensity();
	for (int layer = 0; layer < layers; layer++) {
		float base = min.y + h * (0.45f + 0.12f * layer);
		float amp = h * (0.06f - 0.008f * layer);
		float freq = 0.004f + 0.0015f * layer;
		float speed = 0.6f + 0.25f * layer;
		ImVec2 pts[segments + 1];
		for (int i = 0; i <= segments; i++) {
			float x = min.x + w * i / segments;
			float y = base + sinf(x * freq + t * speed + layer * 1.3f) * amp + sinf(x * freq * 2.3f - t * 0.4f) * amp * 0.35f;
			pts[i] = ImVec2(x, y);
		}
		int start = dl->VtxBuffer.Size;
		ImU32 fill = GatyoU32(ImVec4(1, 1, 1, 0.07f * intensity));
		for (int i = 0; i < segments; i++) {
			dl->AddQuadFilled(pts[i], pts[i + 1], ImVec2(pts[i + 1].x, max.y), ImVec2(pts[i].x, max.y), fill);
		}
		dl->AddPolyline(pts, segments + 1, GatyoU32(ImVec4(1, 1, 1, 0.75f * intensity)), 0, ImMax(1.0f, 2.0f * scaleGlobal));
		GatyoShadeVerts(dl, start, dl->VtxBuffer.Size, false);
	}
}

// Campo de estrellas en hiperespacio: salen del centro dejando estela.
struct BgStar {
	float x, y, z;
};
static std::vector<BgStar> g_bgStars;

static void ResetStar(BgStar& star, bool randomDepth) {
	star.x = randomFloat(-1.0f, 1.0f);
	star.y = randomFloat(-1.0f, 1.0f);
	star.z = randomDepth ? randomFloat(0.05f, 1.0f) : 1.0f;
}

static void DrawStars(ImDrawList* dl, ImVec2 min, ImVec2 max) {
	GatyoPalette p = GatyoGetPalette();
	int count = ImClamp(uiBgDotsDensity, 40, 400);
	while ((int)g_bgStars.size() < count) {
		BgStar star;
		ResetStar(star, true);
		g_bgStars.push_back(star);
	}
	if ((int)g_bgStars.size() > count) g_bgStars.resize(count);

	ImVec2 center((min.x + max.x) * 0.5f, (min.y + max.y) * 0.5f);
	float spread = ImMax(max.x - min.x, max.y - min.y) * 0.5f;
	float dt = BgDeltaTime();
	float intensity = BgIntensity();
	for (BgStar& star : g_bgStars) {
		float prevZ = star.z;
		star.z -= dt * 0.25f;
		if (star.z <= 0.02f) {
			ResetStar(star, false);
			continue;
		}
		ImVec2 pos(center.x + star.x / star.z * spread * 0.25f, center.y + star.y / star.z * spread * 0.25f);
		ImVec2 prev(center.x + star.x / prevZ * spread * 0.25f, center.y + star.y / prevZ * spread * 0.25f);
		if (pos.x < min.x || pos.x > max.x || pos.y < min.y || pos.y > max.y) {
			ResetStar(star, false);
			continue;
		}
		float nearness = 1.0f - star.z;
		ImVec4 c = GatyoMix(p.muted, p.secondary, nearness);
		float size = ImMax(1.0f, nearness * 3.0f * scaleGlobal);
		dl->AddLine(prev, pos, GatyoU32(GatyoAlpha(c, nearness * 0.8f * intensity)), size);
		dl->AddCircleFilled(pos, size * 0.6f, GatyoU32(GatyoAlpha(c, (0.3f + nearness * 0.7f) * intensity)), 8);
	}
}

// Degradado diagonal que va rotando entre los colores del flow, con vineta.
static void DrawGradient(ImDrawList* dl, ImVec2 min, ImVec2 max) {
	float a = 0.32f * BgIntensity();
	ImU32 tl = GatyoU32(GatyoFlowAt(min.x, min.y, a));
	ImU32 tr = GatyoU32(GatyoFlowAt(max.x, min.y, a));
	ImU32 br = GatyoU32(GatyoFlowAt(max.x + 300.0f, max.y, a));
	ImU32 bl = GatyoU32(GatyoFlowAt(min.x + 300.0f, max.y, a));
	dl->AddRectFilledMultiColor(min, max, tl, tr, br, bl);

	GatyoPalette p = GatyoGetPalette();
	float edge = (max.y - min.y) * 0.25f;
	ImU32 dark = GatyoU32(GatyoAlpha(p.bg, 0.45f * BgIntensity()));
	ImU32 clear = GatyoU32(GatyoAlpha(p.bg, 0.0f));
	dl->AddRectFilledMultiColor(min, ImVec2(max.x, min.y + edge), dark, dark, clear, clear);
	dl->AddRectFilledMultiColor(ImVec2(min.x, max.y - edge), max, clear, clear, dark, dark);
}

// Dibuja el fondo elegido en la ventana actual.
void DrawBackgroundEffect(ImVec2 min, ImVec2 max) {
	ImDrawList* dl = ImGui::GetWindowDrawList();
	switch (uiBgStyle) {
		case BG_DOTS: {
			float pointSize = calculateResolutionScale(screenWidth, screenHeight, 2480, 1116);
			BackGroundDots(ImClamp(uiBgDotsDensity, 20, 400), 2 * pointSize, 5 * pointSize, 100 * pointSize);
			break;
		}
		case BG_AURORA:    DrawAurora(dl, min, max); break;
		case BG_PARTICLES: DrawParticles(dl, min, max); break;
		case BG_GRID:      DrawGrid(dl, min, max); break;
		case BG_WAVES:     DrawWaves(dl, min, max); break;
		case BG_STARS:     DrawStars(dl, min, max); break;
		case BG_GRADIENT:  DrawGradient(dl, min, max); break;
		default: break;
	}
}
