#pragma once
// Dibujo 3D sobre el overlay. ImGui no dibuja dentro del render del juego, asi
// que cada punto se pasa al espacio de la camara, se recorta contra el plano
// cercano y se proyecta a la pantalla. No hay oclusion: todo se ve a traves de
// las paredes, igual que el ESP.
//
// OWorldToScreen descarta un punto detras de la camara, y por eso una caja con
// una esquina detras desaparecia entera. Aca las lineas y las caras se cortan
// en el plano cercano y se dibuja la parte visible.

struct GatyoView {
	glm::vec3 cam;
	glm::vec2 fov;
	glm::vec2 display;
	glm::mat4 view;
};

// Vista del frame actual. Solo es valida dentro del bloque de overlays del
// mundo de BeginDraw (menu.h), que la arma antes de llamar a los modulos.
static GatyoView g_view;
static bool g_viewValid = false;  // ya hubo una vista con un mundo cargado
static const float kGatyoNear = 0.1f;

// Mismo calculo que OWorldToScreen: z negativo es delante de la camara.
static glm::vec3 GatyoToView(const GatyoView& v, glm::vec3 p) {
	glm::vec4 h(p - v.cam, 1.0f);
	return glm::vec3(glm::dot(v.view[0], h), glm::dot(v.view[1], h), glm::dot(v.view[2], h));
}

static ImVec2 GatyoProjectView(const GatyoView& v, glm::vec3 c) {
	float mX = v.display.x * 0.5f, mY = v.display.y * 0.5f;
	float depth = ImMax(-c.z, kGatyoNear);
	return ImVec2(mX + mX * c.x / depth * v.fov.x, mY - mY * c.y / depth * v.fov.y);
}

// Punto del mundo a pantalla. Falla detras de la camara o muy fuera de ella
// (los textos y los iconos no se dibujan a medias).
static bool GatyoWorldToScreen(const GatyoView& v, glm::vec3 p, ImVec2& out) {
	glm::vec3 c = GatyoToView(v, p);
	if (-c.z < kGatyoNear) return false;
	out = GatyoProjectView(v, c);
	return out.x > -v.display.x && out.x < v.display.x * 2.0f && out.y > -v.display.y && out.y < v.display.y * 2.0f;
}

// Recorta el segmento a la parte delante del plano cercano.
static bool GatyoClipSegment(glm::vec3& a, glm::vec3& b) {
	float da = -a.z - kGatyoNear, db = -b.z - kGatyoNear;
	if (da < 0 && db < 0) return false;
	if (da < 0) a = a + (b - a) * (da / (da - db));
	else if (db < 0) b = b + (a - b) * (db / (db - da));
	return true;
}

static void GatyoLine3D(ImDrawList* dl, const GatyoView& v, glm::vec3 a, glm::vec3 b, ImU32 color, float thickness) {
	glm::vec3 ca = GatyoToView(v, a), cb = GatyoToView(v, b);
	if (!GatyoClipSegment(ca, cb)) return;
	dl->AddLine(GatyoProjectView(v, ca), GatyoProjectView(v, cb), color, thickness);
}

// Linea con un borde oscuro debajo, como las cajas del ESP.
static void GatyoLine3DOutlined(ImDrawList* dl, const GatyoView& v, glm::vec3 a, glm::vec3 b, ImU32 color, ImU32 outline, float thickness) {
	glm::vec3 ca = GatyoToView(v, a), cb = GatyoToView(v, b);
	if (!GatyoClipSegment(ca, cb)) return;
	ImVec2 pa = GatyoProjectView(v, ca), pb = GatyoProjectView(v, cb);
	if (outline) dl->AddLine(pa, pb, outline, thickness + 2.0f * ImMax(scaleGlobal, 0.5f));
	dl->AddLine(pa, pb, color, thickness);
}

static const int kGatyoBoxEdges[12][2] = {
	{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7},
};
static const int kGatyoBoxFaces[6][4] = {
	{0, 1, 2, 3}, {4, 7, 6, 5}, {0, 4, 5, 1}, {1, 5, 6, 2}, {2, 6, 7, 3}, {3, 7, 4, 0},
};

static void GatyoBoxCorners(glm::vec3 lo, glm::vec3 hi, glm::vec3 out[8]) {
	out[0] = {lo.x, lo.y, lo.z}; out[1] = {hi.x, lo.y, lo.z}; out[2] = {hi.x, lo.y, hi.z}; out[3] = {lo.x, lo.y, hi.z};
	out[4] = {lo.x, hi.y, lo.z}; out[5] = {hi.x, hi.y, lo.z}; out[6] = {hi.x, hi.y, hi.z}; out[7] = {lo.x, hi.y, hi.z};
}

// Cara convexa: se recorta contra el plano cercano (Sutherland-Hodgman con un
// solo plano) y se rellena. ImGui necesita el orden horario para el borde
// suavizado, asi que se invierte si hace falta.
static void GatyoFillPolygon3D(ImDrawList* dl, const GatyoView& v, const glm::vec3* worldPts, int count, ImU32 color) {
	glm::vec3 in[8], clipped[12];
	for (int i = 0; i < count; i++) in[i] = GatyoToView(v, worldPts[i]);
	int n = 0;
	for (int i = 0; i < count; i++) {
		glm::vec3 a = in[i], b = in[(i + 1) % count];
		float da = -a.z - kGatyoNear, db = -b.z - kGatyoNear;
		if (da >= 0) clipped[n++] = a;
		if ((da >= 0) != (db >= 0)) clipped[n++] = a + (b - a) * (da / (da - db));
	}
	if (n < 3) return;
	ImVec2 pts[12];
	float area = 0.0f;
	for (int i = 0; i < n; i++) pts[i] = GatyoProjectView(v, clipped[i]);
	for (int i = 0; i < n; i++) {
		const ImVec2& a = pts[i];
		const ImVec2& b = pts[(i + 1) % n];
		area += a.x * b.y - b.x * a.y;
	}
	if (area < 0.0f) std::reverse(pts, pts + n);
	dl->AddConvexPolyFilled(pts, n, color);
}

// Como GatyoFillPolygon3D pero con un color por vertice (degradados). El
// recorte interpola tambien el color; sin suavizado de bordes.
static void GatyoFillPolygon3DColors(ImDrawList* dl, const GatyoView& v, const glm::vec3* worldPts, const ImVec4* colors, int count) {
	glm::vec3 in[8], clipped[12];
	ImVec4 clippedColor[12];
	for (int i = 0; i < count; i++) in[i] = GatyoToView(v, worldPts[i]);
	int n = 0;
	for (int i = 0; i < count; i++) {
		int j = (i + 1) % count;
		float da = -in[i].z - kGatyoNear, db = -in[j].z - kGatyoNear;
		if (da >= 0) {
			clipped[n] = in[i];
			clippedColor[n++] = colors[i];
		}
		if ((da >= 0) != (db >= 0)) {
			float t = da / (da - db);
			clipped[n] = in[i] + (in[j] - in[i]) * t;
			const ImVec4 &a = colors[i], &b = colors[j];
			clippedColor[n++] = ImVec4(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t);
		}
	}
	if (n < 3) return;
	ImVec2 uv = dl->_Data->TexUvWhitePixel;
	dl->PrimReserve((n - 2) * 3, n);
	ImDrawIdx base = (ImDrawIdx)dl->_VtxCurrentIdx;
	for (int i = 0; i < n; i++) dl->PrimWriteVtx(GatyoProjectView(v, clipped[i]), uv, GatyoU32(clippedColor[i]));
	for (int i = 2; i < n; i++) {
		dl->PrimWriteIdx(base);
		dl->PrimWriteIdx((ImDrawIdx)(base + i - 1));
		dl->PrimWriteIdx((ImDrawIdx)(base + i));
	}
}

// Caja alineada a los ejes. `fill` en 0 no rellena; `outline` en 0 no dibuja
// el borde oscuro.
static void GatyoBox3D(ImDrawList* dl, const GatyoView& v, glm::vec3 lo, glm::vec3 hi, ImU32 color, float thickness, ImU32 fill = 0, ImU32 outline = 0) {
	glm::vec3 c[8];
	GatyoBoxCorners(lo, hi, c);
	if (fill) {
		for (const auto& f : kGatyoBoxFaces) {
			glm::vec3 face[4] = {c[f[0]], c[f[1]], c[f[2]], c[f[3]]};
			GatyoFillPolygon3D(dl, v, face, 4, fill);
		}
	}
	if (outline) {
		for (const auto& e : kGatyoBoxEdges) GatyoLine3D(dl, v, c[e[0]], c[e[1]], outline, thickness + 2.0f * ImMax(scaleGlobal, 0.5f));
	}
	for (const auto& e : kGatyoBoxEdges) GatyoLine3D(dl, v, c[e[0]], c[e[1]], color, thickness);
}

// Caja solida a partir de sus 8 esquinas (en el orden de GatyoBoxCorners, ya
// rotadas si hace falta). Sin buffer de profundidad, solo se rellenan las
// caras que miran a la camara; entre cajas distintas el orden lo pone quien
// llama (de la mas lejana a la mas cercana).
static void GatyoSolidBox3D(ImDrawList* dl, const GatyoView& v, const glm::vec3 c[8], ImVec4 color, ImU32 edge, float thickness) {
	glm::vec3 center(0.0f);
	for (int i = 0; i < 8; i++) center += c[i];
	center /= 8.0f;
	for (const auto& f : kGatyoBoxFaces) {
		glm::vec3 face[4] = {c[f[0]], c[f[1]], c[f[2]], c[f[3]]};
		glm::vec3 faceCenter = (face[0] + face[1] + face[2] + face[3]) * 0.25f;
		glm::vec3 outward = faceCenter - center;
		if (glm::dot(outward, v.cam - faceCenter) <= 0.0f) continue;
		// luz fija: arriba claro, costados medios, abajo oscuro
		float up = outward.y / ImMax(glm::length(outward), 1e-4f);
		float light = up > 0.5f ? 1.0f : (up < -0.5f ? 0.55f : (fabsf(outward.x) > fabsf(outward.z) ? 0.8f : 0.68f));
		ImVec4 shaded(color.x * light, color.y * light, color.z * light, color.w);
		GatyoFillPolygon3D(dl, v, face, 4, GatyoU32(shaded));
		if (edge) {
			for (int i = 0; i < 4; i++) GatyoLine3D(dl, v, face[i], face[(i + 1) % 4], edge, thickness);
		}
	}
}

// Texto centrado sobre un punto del mundo, con contorno. Devuelve donde quedo.
static bool GatyoText3D(ImDrawList* dl, const GatyoView& v, glm::vec3 p, const char* text, ImU32 color, float fontSize, ImVec2* outPos = nullptr) {
	ImVec2 s;
	if (!GatyoWorldToScreen(v, p, s)) return false;
	ImVec2 size = ImGui::CalcTextSize(text);
	size.x *= fontSize / ImGui::GetFontSize();
	size.y *= fontSize / ImGui::GetFontSize();
	ImVec2 pos(s.x - size.x * 0.5f, s.y - size.y);
	ImU32 outline = GatyoU32(GatyoAlpha(GatyoState::Shadow, 0.9f * ((color >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f));
	dl->AddText(nullptr, fontSize, ImVec2(pos.x - 1, pos.y - 1), outline, text);
	dl->AddText(nullptr, fontSize, ImVec2(pos.x + 1, pos.y + 1), outline, text);
	dl->AddText(nullptr, fontSize, ImVec2(pos.x - 1, pos.y + 1), outline, text);
	dl->AddText(nullptr, fontSize, ImVec2(pos.x + 1, pos.y - 1), outline, text);
	dl->AddText(nullptr, fontSize, pos, color, text);
	if (outPos) *outPos = pos;
	return true;
}
