#pragma once
// AutoTrap: encierra a los otros jugadores con obsidiana (o netherite). Es el
// SelfTrap aplicado al objetivo, portado del AutoTrap de GatoClient con las
// rutas de la suite: AcSwitchSlot + buildBlock apoyado en un bloque vecino, y
// las celdas intentadas esperan al servidor antes de repetirse.
//
//   - Objetivos: los mismos filtros del KillAura (amigos, bots, antibot,
//     jugador falso), los N mas cercanos dentro del Rango.
//   - Forma, como el original: un anillo alrededor de la huella del AABB del
//     objetivo (1 o 2 celdas por eje, asi sirve en el borde de un bloque),
//     Altura capas de pared desde sus pies, esquinas opcionales, y la tapa: una
//     capa mas arriba que cubre la huella y el anillo. Piso opcional.
//   - Colocacion virtual: las celdas elegidas en el tick cuentan como bloques
//     para apoyar a las siguientes, asi varias capas entran en el mismo tick
//     (los paquetes llegan en orden). Abajo hacia arriba para que cada celda
//     tenga donde apoyarse.
//   - Soporte: si una pared no tiene vecino, primero va el bloque de abajo.
//   - Nunca dentro de una entidad (ni de ti), y nunca apoyada en cofres, mesas
//     u otros bloques que reaccionan al clic.
//   - Un jugador que sube o cae rapido se salta ese tick: la jaula quedaria a
//     la altura equivocada.
//   - Render: los huecos que faltan laten suave, los que se ponen en este tick
//     laten fuerte y, al taparse, se encogen y desaparecen.

enum AutoTrapStatus { AT_ST_IDLE, AT_ST_NO_TARGET, AT_ST_DONE, AT_ST_PLACING, AT_ST_NO_BLOCKS, AT_ST_BLOCKED, AT_ST_PAUSED };
static std::atomic<int> g_atStatus{AT_ST_IDLE};

static const char* AutoTrapStatusText() {
	switch (g_atStatus.load()) {
		case AT_ST_NO_TARGET: return T(S_AtStNoTarget);
		case AT_ST_DONE: return T(S_SurroundStDone);
		case AT_ST_PLACING: return T(S_SurroundStPlacing);
		case AT_ST_NO_BLOCKS: return T(S_SurroundStNoBlocks);
		case AT_ST_BLOCKED: return T(S_SurroundStBlocked);
		case AT_ST_PAUSED: return T(S_SurroundStPaused);
	}
	return T(S_SurroundStIdle);
}

static ExOverlay g_atOverlay;

#if defined(__aarch64__)

static const int kAtMaxBpt = 10;
static const int kAtRetryTicks = 3;
static const float kAtReach = 6.0f;  // mas alla el servidor rechaza la colocacion
static bool g_atWas = false;
static uint32_t g_atLastPlace = 0;
static AcRetryRing g_atRetry;

static void AtReset() {
	g_atWas = false;
	g_atLastPlace = 0;
	g_atRetry.Clear();
	ExPublish(g_atOverlay, {});
}

struct AtCand {
	vec3_ti cell, clicked;
	unsigned char face;
	uint64_t key;
};

// Apoyo para una celda: un bloque real (sin liquidos ni interactivos) o una de
// las celdas que este mismo tick va a poner.
static bool AtAnchor(BlockSource* region, const vec3_ti& cell, const AtCand* virt, int virtCount, vec3_ti& clicked, unsigned char& face) {
	static const int kDirs[6][4] = {{0, -1, 0, 1}, {1, 0, 0, 4}, {-1, 0, 0, 5}, {0, 0, 1, 2}, {0, 0, -1, 3}, {0, 1, 0, 0}};
	for (const auto& d : kDirs) {
		vec3_ti n{cell.x + d[0], cell.y + d[1], cell.z + d[2]};
		Block* b = AcBlockAt(region, n);
		bool solid = !AcIsAir(b) && !ExIsLiquid(b) && !ExIsInteractive(b);
		if (!solid && AcIsAir(b)) {
			for (int i = 0; i < virtCount; i++) {
				if (ExSameCell(virt[i].cell, n)) {
					solid = true;
					break;
				}
			}
		}
		if (!solid) continue;
		clicked = n;
		face = (unsigned char)d[3];
		return true;
	}
	return false;
}

static void AutoTrapOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!autoTrap) {
		if (g_atWas) AtReset();
		g_atWas = false;
		g_atStatus = AT_ST_IDLE;
		return;
	}
	g_atWas = true;
	AcAdvanceTick();
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	if (autoTrapEatStop && AcEatingActive(lp)) {  // cambiar de slot cortaria la manzana
		g_atStatus = AT_ST_PAUSED;
		return;
	}
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	std::vector<AcEntity> targets = AcCollectTargets(lp, level, autoTrapRange, false);
	std::sort(targets.begin(), targets.end(), [](const AcEntity& a, const AcEntity& b) { return a.dist < b.dist; });
	if ((int)targets.size() > autoTrapTargets) targets.resize(autoTrapTargets);
	if (targets.empty()) {
		g_atStatus = AT_ST_NO_TARGET;
		ExPublish(g_atOverlay, {});
		return;
	}
	if (g_atLastPlace && AcTicksSince(g_atLastPlace) < autoTrapDelay) return;

	const int budget = ImClamp(autoTrapBlocksPerTick, 1, kAtMaxBpt);
	const int height = ImClamp(autoTrapHeight, 1, 4);
	const GaxV3 eye = GaxPos(lp);
	AtCand cand[kAtMaxBpt];
	int n = 0;
	std::vector<ExMark> pending;
	bool blocked = false;

	for (const AcEntity& t : targets) {
		GaxV3 vel = GaxVel(t.actor);
		if (fabsf(vel.y) > 0.15f) continue;  // subiendo o cayendo: la jaula quedaria mal
		ExFootprint f = ExFootprintOf(t.box);
		bool blockersReady = false;

		auto consider = [&](int x, int y, int z, bool allowSupport, auto&& self) -> void {
			if (!AcIsAir(AcBlockAt(region, x, y, z))) return;
			vec3_ti cell{x, y, z};
			if (ExDistToBlock(eye, cell) > kAtReach) return;
			for (int i = 0; i < n; i++) {
				if (ExSameCell(cand[i].cell, cell)) return;  // soporte compartido por dos paredes
			}
			if ((int)pending.size() < 96) pending.push_back(ExMarkCell(cell, EXM_TRAP));
			if (n >= budget) return;
			uint64_t key = AcPackCell(x, y, z);
			if (g_atRetry.Recent(key, kAtRetryTicks)) return;
			vec3_ti clicked{0, 0, 0};
			unsigned char face = 0;
			if (!AtAnchor(region, cell, cand, n, clicked, face)) {
				// sin vecino donde apoyarla: primero el bloque de abajo
				if (allowSupport && autoTrapSupport) self(x, y - 1, z, false, self);
				return;
			}
			if (!blockersReady) {
				StCollectBlockers(level, (float)(f.x0 - 2), (float)(f.feetY - 2), (float)(f.z0 - 2),
					(float)(f.x1 + 3), (float)(f.feetY + height + 3), (float)(f.z1 + 3));
				blockersReady = true;
			}
			if (!StCellFree(x, y, z)) {
				blocked = true;
				return;
			}
			cand[n++] = AtCand{cell, clicked, face, key};
		};
		auto wallLayer = [&](int y) {
			for (int x = f.x0 - 1; x <= f.x1 + 1; x++) {
				for (int z = f.z0 - 1; z <= f.z1 + 1; z++) {
					bool insideX = x >= f.x0 && x <= f.x1, insideZ = z >= f.z0 && z <= f.z1;
					if (insideX && insideZ) continue;                          // la huella misma
					if (!insideX && !insideZ && !autoTrapCorners) continue;    // esquinas
					consider(x, y, z, true, consider);
				}
			}
		};

		if (autoTrapFloor) {
			for (int x = f.x0; x <= f.x1; x++) {
				for (int z = f.z0; z <= f.z1; z++) consider(x, f.feetY - 1, z, false, consider);
			}
		}
		for (int layer = 0; layer < height; layer++) wallLayer(f.feetY + layer);
		if (autoTrapRoof) {
			// la tapa: el anillo de arriba sostiene a las celdas sobre la cabeza
			wallLayer(f.feetY + height);
			for (int x = f.x0; x <= f.x1; x++) {
				for (int z = f.z0; z <= f.z1; z++) consider(x, f.feetY + height, z, false, consider);
			}
		}
	}
	// los que se colocan en este tick laten mas fuerte
	for (ExMark& m : pending) {
		for (int i = 0; i < n; i++) {
			if ((int)m.x0 == cand[i].cell.x && (int)m.y0 == cand[i].cell.y && (int)m.z0 == cand[i].cell.z) m.style = EXM_TRAP_HOT;
		}
	}
	ExPublish(g_atOverlay, autoTrapRender ? pending : std::vector<ExMark>());

	if (pending.empty()) {
		g_atStatus = AT_ST_DONE;
		return;
	}
	if (n == 0) {
		g_atStatus = blocked ? AT_ST_BLOCKED : AT_ST_PLACING;
		return;
	}

	// Un solo cambio de slot para toda la tanda. Con Netherite se prefiere ese
	// bloque; sin obsidiana se usa netherite.
	void* ci = (void*)CI;
	AcSlotsBegin(lp);
	int slot = -1;
	if (autoTrapNetherite) slot = AcSwitchSlot(lp, ci, autoTrapSwitch, Ac::NameNetheriteBlock);
	if (slot < 0) slot = AcSwitchSlot(lp, ci, autoTrapSwitch, Ac::NameObsidian);
	if (slot < 0 && !autoTrapNetherite) slot = AcSwitchSlot(lp, ci, autoTrapSwitch, Ac::NameNetheriteBlock);
	if (slot >= 0) {
		for (int i = 0; i < n; i++) {
			if (autoTrapRotate && i == 0) AcAimAt(eye, ExCenterOf(cand[i].cell));
			OffhandFn<void (*)(void*, const void*, unsigned char, bool)>(Ac::GameModeBuildBlock)(
				(void*)gm, &cand[i].clicked, cand[i].face, false);
			g_atRetry.Note(cand[i].key);
		}
		lp->swing();
		g_atLastPlace = g_acTick;
		g_atStatus = AT_ST_PLACING;
	} else {
		g_atStatus = AT_ST_NO_BLOCKS;
	}
	AcSlotsEnd(lp, ci);
}

#else
// Otros ABIs: no-op con la misma firma.
static void AutoTrapOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
#endif

static void RenderAutoTrap(ImDrawList* dl) {
	if (!autoTrap) {
		ExRenderOverlay(dl, g_atOverlay, false, false, autoTrapFillColor, autoTrapLineColor);
		return;
	}
	ExRenderOverlay(dl, g_atOverlay, autoTrapRender, autoTrapFade, autoTrapFillColor, autoTrapLineColor);
}
