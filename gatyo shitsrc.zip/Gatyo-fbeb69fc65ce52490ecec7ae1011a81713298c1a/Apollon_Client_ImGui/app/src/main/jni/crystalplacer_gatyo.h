#pragma once
// CrystalPlacer: al tocar obsidiana con obsidiana en la mano, deja preparada
// la celda de encima para que el cristal salga justo despues. Portado del
// CrystalPlacer de GatoClient con el camino de este cliente:
//
//   El hook de GameMode::useItemOn (FastBridge en ARM64) avisa con la
//   intencion: si llevas obsidiana, queda guardada la celda donde va a caer
//   (bloque tocado + cara) y, de respaldo, el bloque tocado. El original mira
//   el bloque apuntado en el tick siguiente, que es esa misma obsidiana nueva.
//   (El Block* del hook no sirve: buildBlock llama a useItemOn con nullptr.)
//   Dentro del hook no se coloca nada (nunca se vuelve a entrar); el
//   NormalTick hace el trabajo real cuando la obsidiana ya esta puesta, con
//   el cristal de la mano: cambia el slot, hace buildBlock en la celda y
//   devuelve el slot a su estado original.
//
//   El paquete de transaccion real del original sigue sin verificar, asi que
//   la colocacion sale por buildBlock (misma ruta de fallback que AutoCrystal).

#if defined(__aarch64__)
#include <cstdio>

static bool g_acpWas = false;       // estaba encendido el tick anterior
static bool g_acpPendingValid = false;
static vec3_ti g_acpPending = {0, 0, 0};  // donde cae la obsidiana nueva
static vec3_ti g_acpClicked = {0, 0, 0};  // bloque tocado (respaldo)
static int g_acpWait = 0;           // ticks de gracia hasta hacer el trabajo
static int g_acpTries = 0;          // ticks esperando que el servidor confirme
static int g_acpCooldown = 0;       // margen corto para no repetirse

static void AcPlacerOnUseItemOn(void* gm, void* stack, const vec3_ti* bpos, int face) {
	if (!crystalPlacer || panic || !localPlayer) return;
	// solo cuenta el toque del propio jugador: en un mundo local tambien hay
	// un modo servidor en el mismo proceso, asi que comparamos GameMode
	if (!gm || (void*)gm != (void*)localPlayer->getGameMode()) return;
	if (!stack || !AcIsObsidianItem(stack)) return;
	if (!bpos || g_acpCooldown > 0) return;
	// FacingID: 0 abajo, 1 arriba, 2 norte (-z), 3 sur (+z), 4 oeste (-x), 5 este (+x)
	static const int kFace[6][3] = {{0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};
	const int* d = kFace[(face >= 0 && face < 6) ? face : 1];
	g_acpClicked = *bpos;
	g_acpPending = {bpos->x + d[0], bpos->y + d[1], bpos->z + d[2]};
	g_acpPendingValid = true;
	g_acpWait = 2;   // deja respirar al servidor para que confirme la obsidiana
	g_acpTries = 6;  // y si tarda, unos ticks mas antes de rendirse
}

static void CrystalPlacerOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!crystalPlacer) {
		// apagado: devuelve el slot si queda a medio gesto
		if (g_acpWas && lp && GaxValid(lp)) AcSlotsForceRestore(lp, (void*)CI);
		g_acpWas = false;
		g_acpPendingValid = false;
		g_acpWait = 0;
		g_acpCooldown = 0;
		return;
	}
	g_acpWas = true;
	AcAdvanceTick();
	if (g_acpCooldown > 0) g_acpCooldown--;
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	if (g_acpWait > 0) {
		g_acpWait--;
		return;
	}
	if (!g_acpPendingValid) return;

	void* ci = (void*)CI;
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	// la celda tiene que servir: base de obsidiana/bedrock con aire encima y
	// sin cristal ya puesto. Mientras el servidor no confirma la obsidiana
	// nueva se reintenta unos ticks; al agotarse queda de respaldo el bloque
	// tocado (bloque reemplazable como la hierba alta, o un toque sobre
	// obsidiana que no llego a poner nada).
	if (!AcCanPlaceAt(region, g_acpPending, false)) {
		if (--g_acpTries > 0) return;
		g_acpPendingValid = false;
		if (!AcCanPlaceAt(region, g_acpClicked, false)) return;
		g_acpPending = g_acpClicked;
	}
	std::vector<AcEntity> crystals = AcCollectCrystals(lp, level, 8.0f);
	uint64_t key = AcPackCell(g_acpPending.x, g_acpPending.y, g_acpPending.z);
	for (const AcEntity& c : crystals) {
		if (AcPackCell((int)floorf(c.pos.x), (int)(c.pos.y - 1.0f), (int)floorf(c.pos.z)) == key) {
			g_acpPendingValid = false;
			return;
		}
	}

	AcSlotsBegin(lp);
	if (AcHasItem(lp, Ac::NameEndCrystal)) {
		// CrystalPlacer no tiene ajustes: cambio de slot normal (cliente +
		// anuncio), como el gesto manual del original.
		int slot = AcSwitchSlot(lp, ci, AC_SW_NORMAL, Ac::NameEndCrystal);
		if (slot >= 0) {
			OffhandFn<void (*)(void*, const void*, unsigned char, bool)>(Ac::GameModeBuildBlock)(
				(void*)gm, &g_acpPending, 0, false);
		}
	} else {
		g_acpPendingValid = false;
		AcSlotsEnd(lp, ci);
		return;
	}
	AcSlotsEnd(lp, ci);
	g_acpPendingValid = false;
	g_acpCooldown = 2;  // dos ticks hasta aceptar otro toque
}

#else
// Otros ABIs: no-ops con la misma firma.
static void CrystalPlacerOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
static void AcPlacerOnUseItemOn(void*, void*, const vec3_ti*, int) {}
#endif
