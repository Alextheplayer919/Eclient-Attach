#pragma once
// Piezas de interfaz de Gatyo: widgets, buscador, favoritos, reset por
// seccion, perfiles, fondo del menu, editor de HUD y las paginas nuevas.
// menu.h arma la ventana principal con esto.

#include <mutex>
#include <dirent.h>
#include <sys/stat.h>
#include "build_info.h"

// Unidad de layout: el ancho de referencia del cliente escalado por la escala
// del menu.
static inline float UiUnit() {
	return calcResX * uiScale;
}

#if defined(__aarch64__)
static const char* kArchName = "arm64";
#elif defined(__ARM_ARCH_7A__)
static const char* kArchName = "armv7";
#else
static const char* kArchName = "x86_64";
#endif

// ---------------------------------------------------------------------------
// Puente de texto con Java. La ventana del overlay no puede tener foco, asi
// que para escribir se abre un dialogo nativo de Android (Platform1.java) que
// devuelve el texto mientras se escribe.
// ---------------------------------------------------------------------------
struct TextRequest {
	bool pending = false;
	bool hasIncoming = false;
	bool finished = false;
	std::string title;
	std::string initial;
	std::string incoming;
	std::string* target = nullptr;
};
static TextRequest g_textRequest;  // con g_textMutex (variables.h)

void RequestTextInput(const char* title, std::string* target) {
	std::lock_guard<std::mutex> lock(g_textMutex);
	g_textRequest.pending = true;
	g_textRequest.hasIncoming = false;
	g_textRequest.finished = false;
	g_textRequest.title = title;
	g_textRequest.initial = *target;
	g_textRequest.target = target;
}

// Con g_textMutex tomado: suelta el pedido si escribe dentro de [begin, end),
// antes de borrar o mover esos textos (listas editables).
void ForgetTextTargetIn(const void* begin, const void* end) {
	const char* target = (const char*)g_textRequest.target;
	if (target >= (const char*)begin && target < (const char*)end) g_textRequest.target = nullptr;
}

// Se llama una vez por frame desde el hilo de render.
void ProcessTextInput() {
	std::lock_guard<std::mutex> lock(g_textMutex);
	if (g_textRequest.hasIncoming && g_textRequest.target) {
		*g_textRequest.target = g_textRequest.incoming;
		g_textRequest.hasIncoming = false;
	}
	if (g_textRequest.finished) {
		g_textRequest.target = nullptr;
		g_textRequest.finished = false;
	}
}

static bool g_blurSupported = true;
static bool g_hudEditor = false;

// Desplazamiento tactil compartido por el panel y el ClickGUI: si el toque
// actual ya se uso para desplazar, los interruptores no se activan al soltar.
static bool g_touchScrolled = false;
static ImGuiID g_touchKeepItem = 0;
static const float kTouchDragThreshold = 10.0f;  // px de referencia antes de que un toque sea arrastre  // slider que ya decidio seguir al dedo en horizontal
static ImGuiID g_touchPressedItem = 0;

void BeginTouchFrame() {
	if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
		g_touchScrolled = false;
		g_touchPressedItem = 0;
		g_touchKeepItem = 0;
	}
}

// Llamar al final de una ventana o child desplazable. Arrastrar en vertical
// desplaza; no interfiere con sliders ni drags (solo actua sin item activo o
// si el activo es un interruptor/fila). Un toque que se arrastra ya no cuenta
// como click al soltarlo. Con `stealActive`, el arrastre le quita el toque a
// cualquier item de esta ventana (botones, combos): solo para ventanas cuyos
// sliders deciden solos si siguen al dedo (CgGuardSlider).
void TouchScroll(bool stealActive = false) {
	// tocar un espacio vacio deja activo el "mover ventana" de ImGui, aunque
	// la ventana no se pueda mover desde ahi: eso tambien cuenta como libre
	ImGuiContext& g = *GImGui;
	bool windowMove = g.ActiveIdWindow && g.ActiveId == g.ActiveIdWindow->MoveId;
	bool ownActive = stealActive && g.ActiveIdWindow == g.CurrentWindow && g.ActiveId != g_touchKeepItem;
	bool canScroll = !ImGui::IsAnyItemActive() || windowMove || ownActive || ImGui::GetActiveID() == g_touchPressedItem;
	if (!canScroll || !ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem | ImGuiHoveredFlags_ChildWindows)) return;
	if (!ImGui::IsMouseDragging(ImGuiMouseButton_Left, kTouchDragThreshold * scaleGlobal)) return;
	g_touchScrolled = true;
	if (ownActive && !windowMove && ImGui::GetActiveID() != g_touchPressedItem) ImGui::ClearActiveID();
	ImVec2 drag = ImGui::GetMouseDragDelta(ImGuiMouseButton_Left);
	if (fabsf(drag.y) <= fabsf(drag.x)) return;
	ImGui::SetScrollY(ImGui::GetScrollY() - ImGui::GetIO().MouseDelta.y);
}

extern "C" {
	// Devuelve "titulo\x01texto\x01aceptar\x01cancelar" si hay un pedido nuevo.
	JNIEXPORT jstring JNICALL Java_com_mojang_minecraftpe_platforms_Platform2_pollTextRequest(JNIEnv* env, jclass) {
		std::lock_guard<std::mutex> lock(g_textMutex);
		if (!g_textRequest.pending) return nullptr;
		g_textRequest.pending = false;
		std::string payload = g_textRequest.title + "\x01" + g_textRequest.initial + "\x01" + T(S_Accept) + "\x01" + T(S_Cancel);
		return env->NewStringUTF(payload.c_str());
	}

	JNIEXPORT void JNICALL Java_com_mojang_minecraftpe_platforms_Platform2_submitText(JNIEnv* env, jclass, jstring text, jboolean done) {
		const char* chars = env->GetStringUTFChars(text, nullptr);
		std::lock_guard<std::mutex> lock(g_textMutex);
		g_textRequest.incoming = chars ? chars : "";
		g_textRequest.hasIncoming = true;
		if (done) g_textRequest.finished = true;
		if (chars) env->ReleaseStringUTFChars(text, chars);
	}

	// Radio del desenfoque detras del menu, en px de pantalla (0 = ninguno).
	JNIEXPORT jint JNICALL Java_com_mojang_minecraftpe_platforms_Platform2_getBlurRadius(JNIEnv*, jclass) {
		if (!g_Initialized || panic || g_hudEditor || !g_window) return 0;
		return (jint)(uiGlassBlur * ImMax(scaleGlobal, 0.5f));
	}

	JNIEXPORT void JNICALL Java_com_mojang_minecraftpe_platforms_Platform2_setBlurSupported(JNIEnv*, jclass, jboolean supported) {
		g_blurSupported = supported;
	}
}

// ---------------------------------------------------------------------------
// Widgets
// ---------------------------------------------------------------------------
void Tip(const char* text) {
	if (!uiTooltips || !text || !*text) return;
	if (ImGui::IsItemHovered(ImGuiHoveredFlags_ForTooltip | ImGuiHoveredFlags_AllowWhenDisabled)) {
		ImGui::BeginTooltip();
		ImGui::PushTextWrapPos(ImGui::GetFontSize() * 22.0f);
		ImGui::TextUnformatted(text);
		ImGui::PopTextWrapPos();
		ImGui::EndTooltip();
	}
}

inline void Tip(StrId id) { Tip(T(id)); }

// Interruptor rectangular con la perilla deslizandose (reemplaza al checkbox
// en los modulos).
bool GatyoSwitch(const char* label, bool* value) {
	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems) return false;

	ImGuiContext& g = *GImGui;
	const ImGuiStyle& style = g.Style;
	const ImGuiID id = window->GetID(label);
	const ImVec2 labelSize = ImGui::CalcTextSize(label, NULL, true);
	const float height = ImGui::GetFrameHeight();
	const float width = height * 1.8f;

	ImVec2 pos = window->DC.CursorPos;
	ImRect totalBb(pos, ImVec2(pos.x + width + (labelSize.x > 0 ? style.ItemInnerSpacing.x + labelSize.x : 0.0f), pos.y + height));
	ImGui::ItemSize(totalBb, style.FramePadding.y);
	if (!ImGui::ItemAdd(totalBb, id)) return false;

	bool hovered, held;
	bool pressed = ImGui::ButtonBehavior(totalBb, id, &hovered, &held);
	if (held) g_touchPressedItem = id;
	if (pressed && g_touchScrolled) pressed = false;
	if (pressed) {
		*value = !*value;
		ImGui::MarkItemEdited(id);
	}

	float* anim = window->StateStorage.GetFloatRef(id, *value ? 1.0f : 0.0f);
	float target = *value ? 1.0f : 0.0f;
	if (uiAnimations) *anim += (target - *anim) * ImMin(1.0f, g.IO.DeltaTime * 14.0f * uiAnimSpeed);
	else *anim = target;

	GatyoPalette p = GatyoGetPalette();
	ImDrawList* dl = window->DrawList;
	ImVec2 trackMax(pos.x + width, pos.y + height);
	ImVec4 track = GatyoMix(GatyoAlpha(p.off, 0.95f), GatyoAlpha(p.accent, 0.9f), *anim);
	dl->AddRectFilled(pos, trackMax, GatyoU32(track));
	if (hovered) dl->AddRectFilled(pos, trackMax, GatyoU32(GatyoAlpha(p.hover, 0.35f)));
	dl->AddRect(pos, trackMax, GatyoU32(GatyoAlpha(p.border, 0.9f)));

	float inset = ImMax(2.0f, height * 0.16f);
	float knob = height - inset * 2.0f;
	float knobX = pos.x + inset + (width - inset * 2.0f - knob) * *anim;
	ImVec4 knobColor = p.light ? GatyoMix(p.bg, p.text, 0.08f) : p.text;
	if (*anim < 0.5f) knobColor = GatyoMix(knobColor, p.muted, 0.5f);
	dl->AddRectFilled(ImVec2(knobX, pos.y + inset), ImVec2(knobX + knob, pos.y + inset + knob), GatyoU32(knobColor));

	if (labelSize.x > 0) {
		ImGui::RenderText(ImVec2(trackMax.x + style.ItemInnerSpacing.x, pos.y + style.FramePadding.y), label);
	}
	return pressed;
}

bool ModToggle(int mod) {
	const ModuleInfo& m = kModules[mod];
	char label[192];
	snprintf(label, sizeof(label), "%s###mod_%s", ModName(mod), m.key);
	bool changed = GatyoSwitch(label, m.value);
	if (changed && (m.flags & MF_XRAY)) rebuildChunkGeometry = true;
	Tip(ModDesc(mod));
	return changed;
}

bool ComboT(const char* label, int* value, const StrId* items, int count) {
	const char* names[16];
	count = ImMin(count, 16);
	for (int i = 0; i < count; i++) names[i] = T(items[i]);
	*value = ImClamp(*value, 0, count - 1);
	return ImGui::Combo(label, value, names, count);
}

// Titulo de seccion: texto de acento y una linea fina hasta el borde.
void SectionTitle(StrId id) {
	GatyoPalette p = GatyoGetPalette();
	ImGui::Dummy(ImVec2(0.0f, 4.0f * scaleGlobal));
	ImGui::PushStyleColor(ImGuiCol_Text, p.accent);
	ImGui::TextUnformatted(T(id));
	ImGui::PopStyleColor();
	ImVec2 min = ImGui::GetItemRectMin();
	ImVec2 max = ImGui::GetItemRectMax();
	float y = (min.y + max.y) * 0.5f;
	float right = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
	if (right > max.x + 10.0f) {
		ImGui::GetWindowDrawList()->AddLine(ImVec2(max.x + 10.0f * scaleGlobal, y), ImVec2(right, y), GatyoU32(GatyoAlpha(p.border, 0.7f)), 1.0f);
	}
}

void MutedText(const char* text) {
	ImGui::PushStyleColor(ImGuiCol_Text, GatyoGetPalette().muted);
	ImGui::TextWrapped("%s", text);
	ImGui::PopStyleColor();
}

// Estrella de 5 puntas dibujada a mano (la fuente no trae el glifo).
void DrawStar(ImDrawList* dl, ImVec2 center, float radius, ImU32 color, bool filled) {
	ImVec2 pts[10];
	for (int i = 0; i < 10; i++) {
		float r = (i % 2 == 0) ? radius : radius * 0.45f;
		float a = -IM_PI / 2.0f + i * IM_PI / 5.0f;
		pts[i] = ImVec2(center.x + cosf(a) * r, center.y + sinf(a) * r);
	}
	if (filled) {
		for (int i = 0; i < 10; i++) dl->AddTriangleFilled(center, pts[i], pts[(i + 1) % 10], color);
	} else {
		dl->AddPolyline(pts, 10, color, ImDrawFlags_Closed, ImMax(1.0f, 1.5f * scaleGlobal));
	}
}

bool StarButton(const char* id, bool filled) {
	float size = ImGui::GetFrameHeight();
	bool pressed = ImGui::InvisibleButton(id, ImVec2(size, size));
	GatyoPalette p = GatyoGetPalette();
	ImVec2 min = ImGui::GetItemRectMin();
	ImU32 color = GatyoU32(filled ? p.secondary : (ImGui::IsItemHovered() ? p.accent : p.muted));
	DrawStar(ImGui::GetWindowDrawList(), ImVec2(min.x + size * 0.5f, min.y + size * 0.5f), size * 0.38f, color, filled);
	return pressed;
}

// Boton de acento (accion principal).
bool AccentButton(const char* label, ImVec2 size = ImVec2(0, 0)) {
	GatyoPalette p = GatyoGetPalette();
	ImGui::PushStyleColor(ImGuiCol_Button, GatyoAlpha(p.accent, 0.75f));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, GatyoAlpha(p.accent, 0.9f));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, p.secondary);
	bool pressed = ImGui::Button(label, size);
	ImGui::PopStyleColor(3);
	return pressed;
}

// ---------------------------------------------------------------------------
// Favoritos
// ---------------------------------------------------------------------------
bool IsFavorite(int mod) {
	return std::find(uiFavorites.begin(), uiFavorites.end(), kModules[mod].key) != uiFavorites.end();
}

void ToggleFavorite(int mod) {
	auto it = std::find(uiFavorites.begin(), uiFavorites.end(), kModules[mod].key);
	if (it != uiFavorites.end()) uiFavorites.erase(it);
	else uiFavorites.push_back(kModules[mod].key);
}

static bool ModuleBlocked(int mod) {
	return (kModules[mod].flags & MF_NOLAN) && isLANGame;
}

// Cambia un modulo desde el buscador o los favoritos, respetando el bloqueo
// por anti-cheat y la reconstruccion de chunks del Xray.
static void ToggleModuleFromShortcut(int mod) {
	if (ModuleBlocked(mod)) return;
	*kModules[mod].value = !*kModules[mod].value;
	if (kModules[mod].flags & MF_XRAY) rebuildChunkGeometry = true;
}

// Fila de favoritos fijada arriba del contenido de cada pagina.
void DrawFavoritesStrip() {
	if (uiFavorites.empty()) return;
	static bool editing = false;
	GatyoPalette p = GatyoGetPalette();

	float starSize = ImGui::GetFontSize();
	ImVec2 cursor = ImGui::GetCursorScreenPos();
	DrawStar(ImGui::GetWindowDrawList(), ImVec2(cursor.x + starSize * 0.5f, cursor.y + ImGui::GetFrameHeight() * 0.5f), starSize * 0.4f, GatyoU32(p.secondary), true);
	ImGui::Dummy(ImVec2(starSize, ImGui::GetFrameHeight()));
	ImGui::SameLine();
	ImGui::AlignTextToFramePadding();
	ImGui::PushStyleColor(ImGuiCol_Text, p.muted);
	ImGui::TextUnformatted(T(S_Favorites));
	ImGui::PopStyleColor();

	float right = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
	int removeIndex = -1;
	for (size_t i = 0; i < uiFavorites.size(); i++) {
		int mod = FindModuleByKey(uiFavorites[i]);
		if (mod < 0) continue;
		const char* name = ModName(mod);
		char label[192];
		snprintf(label, sizeof(label), editing ? "%s  x###fav_%s" : "%s###fav_%s", name, kModules[mod].key);
		float width = ImGui::CalcTextSize(label, NULL, true).x + ImGui::GetStyle().FramePadding.x * 2.0f;
		ImGui::SameLine();
		if (ImGui::GetCursorScreenPos().x + width > right) ImGui::NewLine();

		bool on = *kModules[mod].value;
		bool blocked = ModuleBlocked(mod);
		ImGui::PushStyleColor(ImGuiCol_Button, on ? GatyoAlpha(p.accent, 0.7f) : GatyoAlpha(p.off, 0.8f));
		ImGui::PushStyleColor(ImGuiCol_Text, on ? p.text : p.muted);
		ImGui::BeginDisabled(blocked && !editing);
		if (ImGui::Button(label)) {
			if (editing) removeIndex = (int)i;
			else ToggleModuleFromShortcut(mod);
		}
		ImGui::EndDisabled();
		ImGui::PopStyleColor(2);
		Tip(blocked ? T(S_BlockedByAntiCheat) : ModDesc(mod));
	}
	if (removeIndex >= 0) uiFavorites.erase(uiFavorites.begin() + removeIndex);

	const char* editLabel = editing ? TL(S_Done) : TL(S_FavoritesEdit);
	float editWidth = ImGui::CalcTextSize(editLabel, NULL, true).x + ImGui::GetStyle().FramePadding.x * 2.0f;
	ImGui::SameLine();
	if (ImGui::GetCursorScreenPos().x + editWidth > right) ImGui::NewLine();
	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
	ImGui::PushStyleColor(ImGuiCol_Text, p.muted);
	if (ImGui::Button(editLabel)) editing = !editing;
	ImGui::PopStyleColor(2);
	ImGui::Separator();
}

// ---------------------------------------------------------------------------
// Buscador
// ---------------------------------------------------------------------------
static std::string g_searchQuery;

// Minusculas sin tildes, para que "camara" encuentre "Cámara".
static std::string FoldForSearch(const char* text) {
	std::string out;
	for (const unsigned char* c = (const unsigned char*)text; *c; c++) {
		if (*c == 0xC3 && c[1]) {
			unsigned char n = c[1];
			char folded = 0;
			if ((n >= 0xA0 && n <= 0xA5) || (n >= 0x80 && n <= 0x85)) folded = 'a';
			else if ((n >= 0xA8 && n <= 0xAB) || (n >= 0x88 && n <= 0x8B)) folded = 'e';
			else if ((n >= 0xAC && n <= 0xAF) || (n >= 0x8C && n <= 0x8F)) folded = 'i';
			else if ((n >= 0xB2 && n <= 0xB6) || (n >= 0x92 && n <= 0x96)) folded = 'o';
			else if ((n >= 0xB9 && n <= 0xBC) || (n >= 0x99 && n <= 0x9C)) folded = 'u';
			else if (n == 0xB1 || n == 0x91) folded = 'n';
			if (folded) {
				out += folded;
				c++;
				continue;
			}
		}
		out += (char)tolower(*c);
	}
	return out;
}

static bool ModuleMatches(int mod, const std::string& query) {
	const ModuleInfo& m = kModules[mod];
	const char* fields[] = {m.name[0], m.name[1], ModDesc(mod), m.key};
	for (const char* field : fields) {
		if (FoldForSearch(field).find(query) != std::string::npos) return true;
	}
	return false;
}

// Campo de busqueda del panel lateral: al tocarlo abre el teclado de Android
// y filtra mientras se escribe.
void DrawSearchField(float width) {
	GatyoPalette p = GatyoGetPalette();
	float height = ImGui::GetFrameHeight();
	ImVec2 pos = ImGui::GetCursorScreenPos();
	bool hasQuery = !g_searchQuery.empty();
	float clearWidth = hasQuery ? height : 0.0f;

	if (ImGui::InvisibleButton("##gatyo_search", ImVec2(width - clearWidth, height))) {
		RequestTextInput(T(S_SearchTitle), &g_searchQuery);
	}
	bool hovered = ImGui::IsItemHovered();
	ImDrawList* dl = ImGui::GetWindowDrawList();
	ImVec2 max(pos.x + width, pos.y + height);
	dl->AddRectFilled(pos, max, GatyoU32(hovered ? p.hover : GatyoAlpha(p.panel, 0.85f)));
	dl->AddRect(pos, max, GatyoU32(GatyoAlpha(hasQuery ? p.accent : p.border, 0.9f)));

	// lupa
	float r = height * 0.2f;
	ImVec2 c(pos.x + height * 0.45f, pos.y + height * 0.45f);
	ImU32 iconColor = GatyoU32(p.muted);
	dl->AddCircle(c, r, iconColor, 12, ImMax(1.0f, 1.6f * scaleGlobal));
	dl->AddLine(ImVec2(c.x + r * 0.7f, c.y + r * 0.7f), ImVec2(c.x + r * 1.7f, c.y + r * 1.7f), iconColor, ImMax(1.0f, 1.8f * scaleGlobal));

	const char* text = hasQuery ? g_searchQuery.c_str() : T(S_Search);
	ImVec2 textPos(pos.x + height * 0.9f, pos.y + ImGui::GetStyle().FramePadding.y);
	dl->PushClipRect(pos, ImVec2(max.x - clearWidth, max.y), true);
	dl->AddText(textPos, GatyoU32(hasQuery ? p.text : p.muted), text);
	dl->PopClipRect();

	if (hasQuery) {
		ImGui::SameLine(0, 0);
		if (ImGui::InvisibleButton("##gatyo_search_clear", ImVec2(clearWidth, height))) g_searchQuery.clear();
		ImVec2 cm = ImGui::GetItemRectMin();
		float k = height * 0.22f;
		ImVec2 cc(cm.x + height * 0.5f, cm.y + height * 0.5f);
		ImU32 xColor = GatyoU32(ImGui::IsItemHovered() ? p.accent : p.muted);
		dl->AddLine(ImVec2(cc.x - k, cc.y - k), ImVec2(cc.x + k, cc.y + k), xColor, ImMax(1.0f, 2.0f * scaleGlobal));
		dl->AddLine(ImVec2(cc.x + k, cc.y - k), ImVec2(cc.x - k, cc.y + k), xColor, ImMax(1.0f, 2.0f * scaleGlobal));
		Tip(S_ClearSearch);
	}
}

bool SearchActive() {
	return !g_searchQuery.empty();
}

void DrawSearchResults() {
	GatyoPalette p = GatyoGetPalette();
	std::string query = FoldForSearch(g_searchQuery.c_str());
	std::vector<int> results;
	for (int i = 0; i < MOD_COUNT; i++) {
		if (ModuleMatches(i, query)) results.push_back(i);
	}

	ImGui::PushStyleColor(ImGuiCol_Text, p.muted);
	ImGui::Text(T(S_SearchResults), g_searchQuery.c_str());
	ImGui::PopStyleColor();
	ImGui::Separator();
	if (results.empty()) {
		MutedText(T(S_NoResults));
		return;
	}

	ImGui::BeginChild("##gatyo_results", ImVec2(0, 0), false);
	for (int mod : results) {
		ImGui::PushID(mod);
		bool favorite = IsFavorite(mod);
		if (StarButton("##fav", favorite)) ToggleFavorite(mod);
		Tip(favorite ? S_FavoriteRemove : S_FavoriteAdd);
		ImGui::SameLine();
		bool blocked = ModuleBlocked(mod);
		ImGui::BeginDisabled(blocked);
		ModToggle(mod);
		ImGui::EndDisabled();
		if (blocked) Tip(S_BlockedByAntiCheat);

		const char* pageName = T(kPageNames[kModules[mod].page]);
		char goLabel[96];
		snprintf(goLabel, sizeof(goLabel), "%s##go", pageName);
		float goWidth = ImGui::CalcTextSize(pageName).x + ImGui::GetStyle().FramePadding.x * 2.0f;
		ImGui::SameLine(ImMax(ImGui::GetCursorPosX(), ImGui::GetWindowContentRegionMax().x - goWidth));
		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
		ImGui::PushStyleColor(ImGuiCol_Text, p.muted);
		if (ImGui::Button(goLabel)) {
			pageId = kModules[mod].page;
			g_searchQuery.clear();
		}
		ImGui::PopStyleColor(2);
		Tip(TF(S_GoToPage, pageName).c_str());

		MutedText(ModDesc(mod));
		ImGui::Separator();
		ImGui::PopID();
	}
	TouchScroll();
	ImGui::EndChild();
}

// ---------------------------------------------------------------------------
// Reset por seccion y general
// ---------------------------------------------------------------------------
static const char* const kKeysMovement[] = {
	"speedValue", "waterSpeedValue", "lavaSpeedValue", "alwaysSprinting", "noSlowDown", "offSlowdownTrigger",
	"noJumpDelay", "jumpValue", "gravityValue", "fastFall", "step", "ladderFly", "noclip", "creativeFly",
	"forceCreativeFly", "offWaterTrigger", "strafe", "offDrown", "damageFly",
	"gatoFly", "bypassFly", "flyDynamic", "flyAntiKick", "flyHSpeed", "flyVSpeed", "flyGlide", "flyHDynamic",
	"flyVDynamic", "flyKickInterval", "flyKickAmount", "bfInitialH", "bfInitialV", "bfInitBypH", "bfInitBypV",
	"bfFinalH", "bfFinalV", "bfFinalBypH", "bfFinalBypV", "bfGlide", "bfReleaseDelay", "bfDescentSpeed",
	"bfDescentHorizontal", "bfOnlyShift", "flyLookControl",
};
static const char* const kKeysCombat[] = {
	"gatoAuraX", "gaxHurttime", "gaxAttackMobs", "gaxRandomizeHit", "gaxTargetVisualize", "gaxNoSwing",
	"gaxMoveCamera", "gaxTargetMode", "gaxInterval", "gaxMultiplier", "gaxRotationMode", "gaxHitChance",
	"gaxRange", "gaxVertOffset", "gaxEclipseLead", "gaxTvColor", "gaxSwitchMode", "gaxAutoTrident", "gaxRainMode",
	"plus999Aura", "p9Hurttime", "p9TargetVisualize", "p9NoSwing", "p9AutoTrident", "p9RainMode", "p9MoveCamera",
	"p9TargetMode", "p9Interval", "p9Multiplier", "p9RotationMode", "p9SwitchMode", "p9Range", "p9VertOffset", "p9TvColor",
	"autoHotbar", "autoHotbarDelay", "autoHotbarItems", "autoHotbarSlots",
	"offhand", "offhandSmart",
	"offhandSurroundOnly", "offhandItem", "offhandDelay", "offhandSwapTotem", "offhandSwapShield",
	"popCounter", "popCountSelf", "popCountFriends", "popSendPop", "popSendDeath", "popRandomMessage",
	"popMessages", "popDeathMessages",
	"killAura", "killRange", "rotationsRange", "maxKillTick", "useGeyserCooldown", "hitBox", "hitBoxValue",
	"auraType", "swing", "rotations", "targetLock", "hurtCheck", "emulateNativeAttack", "mobAura",
	"mobAuraRange", "maxMobAuraTick", "killItems", "antiFireball", "autoClicker", "maxAutoClickTick",
	"antiKnockback", "noHorses", "noVillagers", "noSnowMan", "noIronGolem", "noDonkeys", "noAllays",
	"noArmadillos", "noAxolotls", "noBats", "noBees", "noCamels", "noCats", "noChickens", "noCods",
	"noCopperGolems", "noCows", "noDolphins", "noFoxes", "noFrogs", "noGlowSquids", "noGoats",
	"noHappyGhasts", "noLlamas", "noOcelots", "noPandas", "noParrots", "noPigs", "noPiglins",
	"noPufferfishes", "noRabbits", "noSalmons", "noSheeps", "noSniffers", "noSquids", "noStriders",
	"noTadpoles", "noTropicalfishes", "noTurtles", "noWanderingtraders", "noWolfs", "noZombiepiglins",
	"noZombievillagers",
	// Suite de cristales: AutoCrystal
	"autoCrystal", "acPriority", "acWhileEating", "acBreak", "acInhibit", "acBreakDelay", "acBreakRange",
	"acMultitask", "acBuildSpeed", "acPlace", "acPlaceDelay", "acPlaceRange", "acPacketPlace", "acPacketAttack",
	"acProximity", "acEnemyDamage", "acSelfDamage", "acSwitch", "acAlternate", "acMultiPlace", "acIDPredict",
	"acIDDelay", "acKASync", "acPostDelay", "acRotate", "acSelf", "acRender", "acSlide", "acSlideSpeed",
	"acDamageText", "acFade", "acFadeDuration", "acFlat", "acFillColor", "acLineColor", "acTextColor",
	// AutoCrystalX
	"autoCrystalX", "acxPlace", "acxPacketPlace", "acxBreak", "acxPlaceDelay", "acxBreakDelay", "acxEatStop",
	"acxSync", "acxSyncDelay", "acxTargetRange", "acxPlaceRange", "acxBreakRange", "acxProximity",
	"acxEnemyDamage", "acxSelfDamage", "acxMinDamage", "acxPriority", "acxPhase", "acxMultitask", "acxJava",
	"acxRotate", "acxTerrain", "acxPacketTerrain", "acxAirPlace", "acxBlocksPerTick", "acxTerrainProx",
	"acxTerrainDelay", "acxSwitch", "acxAlternate", "acxPlaceCount", "acxSpread", "acxWasteAmount", "acxSelf", "acxIDPredict", "acxIDDelay", "acxIDPackets", "acxIDDamage",
	"acxDynamic", "acxPredictTicks", "acxVelWeight", "acxIntercept", "acxRender", "acxLerp", "acxSpeed",
	"acxDamageText", "acxFade", "acxFadeDuration", "acxFlat", "acxFillColor", "acxLineColor", "acxTextColor",
	// Placer, Helper y AntiCrystal
	"crystalPlacer", "crystalHelper",
	"antiCrystal", "antiCrystalReduceY", "antiCrystalReduceXZ", "antiCrystalHorizontal", "antiCrystalMotionSpoof",
	"antiCrystalFeetOnly",
	// SelfTrap
	"selfTrap", "selfTrapHeight", "selfTrapThickness", "selfTrapNetherite", "selfTrapRoof", "selfTrapCorners",
	"selfTrapBlocksPerTick", "selfTrapSwitch",
	// Surround
	"surround", "surroundBlocksPerTick", "surroundDelay", "surroundFloor", "surroundSupport", "surroundCorners",
	"surroundNetherite", "surroundEatStop", "surroundJumpDisable", "surroundCenter", "surroundBreakCrystals",
	"surroundRotate", "surroundSwitch", "surroundRender", "surroundFade", "surroundFillColor", "surroundLineColor",
	// AutoTrap
	"autoTrap", "autoTrapRange", "autoTrapTargets", "autoTrapBlocksPerTick", "autoTrapDelay", "autoTrapHeight",
	"autoTrapRoof", "autoTrapFloor", "autoTrapCorners", "autoTrapSupport", "autoTrapNetherite", "autoTrapEatStop",
	"autoTrapRotate", "autoTrapSwitch", "autoTrapRender", "autoTrapFade", "autoTrapFillColor", "autoTrapLineColor",
	// AutoAnchor, AutoBed y AutoCity
	"autoAnchor", "aaTargetRange", "aaPlaceRange", "aaProximity", "aaEnemyDamage", "aaSelfDamage", "aaPriority",
	"aaDelay", "aaSwitch", "aaEatStop", "aaRotate", "aaRender", "aaFade",
	"autoBed", "abTargetRange", "abPlaceRange", "abProximity", "abEnemyDamage", "abSelfDamage", "abPriority",
	"abDelay", "abSwitch", "abEatStop", "abRotate", "abRender", "abFade",
	"autoCity", "ctRange", "ctReach", "ctMode", "ctEnclosed", "ctBurrow", "ctEnemyDamage", "ctSelfDamage",
	"ctPlaceAt", "ctHit", "ctSwitch", "ctEatStop", "ctRender", "blastFillColor", "blastLineColor",
	"fxSlide", "fxSlideSpeed", "fxText", "fxPulse", "fxShaded", "fxShockwave", "fxTextColor",
};
static const char* const kKeysBuilding[] = {
	"clickAutoMine", "fastBridge", "blockReach",
	"platform", "platformRadius", "platformBlocksPerTick", "platformDelay", "platformSupport", "platformProximity",
	"packetMine", "pmType", "pmSpeed", "pmRange", "pmSwitch", "pmDelay", "pmContinueReset", "pmContinueDelay",
	"pmRetryDelay", "pmMultitask", "pmRender", "pmStartColor", "pmEndColor",
};
static const char* const kKeysPlayers[] = {"antiBot"};
static const char* const kKeysVisuals[] = {
	"xrayDefault", "xrayCaves", "xrayCam", "xrayDiamond", "xrayIron", "xrayGold", "xrayCoal", "xrayCopper",
	"xrayLapis", "xrayEmerald", "xrayRedstone", "xrayAmethyst", "xrayNetherite", "xrayQuartz",
	"xrayObsidian", "xrayBarrel", "fogState", "chamsint", "visibleColor.x", "visibleColor.y",
	"visibleColor.z", "inWallColor.x", "inWallColor.y", "inWallColor.z", "enableRainbow",
	"enableRainbowWall", "enableFov", "fov", "fullBright", "osmtBoost", "look360", "noHurtCam", "noCamDist",
	"noBoatRotation", "noCamSleep", "placeCam", "antiInvis", "derp", "noBlur", "antiBlind", "fontSize",
	"showPaperdoll", "noCaveVignette", "deathPosition", "esp", "espBox", "espLine", "espDistance",
	"espNametag", "espHealth", "espPlatform", "espHealthBar", "espHealthColor", "espLineMode",
	"espBoxStyle", "espThickness", "espOpacity", "espDistanceScale", "espHealthGradient", "espPaletteColor",
	"tracerThickness", "tracerGradient", "damageIndicators", "dmgSize", "dmgDuration", "dmgColorMode",
	"dmgColor", "visualColorMode", "flowColorA", "flowColorB", "flowSpeed", "customFov", "customFovValue",
	"espPops", "pearlTracker", "pearlPredict", "pearlOwner", "pearlColor", "logSpot", "logSpotNotify",
	"logSpotMinutes", "logSpotColor", "waypoints", "waypointDistance", "chunkBorders", "screenTint", "screenTintColor",
	// CrystalChams
	"crystalChams", "crystalChamsRotateSpeed", "crystalChamsBobSpeed", "crystalChamsBobAmount", "crystalChamsScale",
	"crystalChamsFancy", "crystalChamsFade", "crystalChamsFadeDuration", "crystalChamsFillColor",
	"crystalChamsLineColor",
	// ViewModel y SwingSpeed
	"viewModel", "swingSpeed", "swingDuration", "vmMainPos", "vmMainRot", "vmMainScale", "vmOffPos", "vmOffRot", "vmOffScale",
	// Nametags
	"nametags", "ntArmor", "ntSelf", "ntDynamic", "ntHealth", "ntColoredNames", "ntMode", "ntOpacity", "ntTextSize",
	"ntRectColor",
	// Charms
	"charms", "charmsPop", "charmsDeath", "charmsHit", "charmsSelf", "charmsFriends", "charmsRainbow",
	"charmsPopDuration", "charmsPopRise", "charmsPopExpand", "charmsPopGlow", "charmsPopFill", "charmsPopLine",
	"charmsDeathMode", "charmsDeathDuration", "charmsDeathSize", "charmsDeathColor",
	"charmsHitMode", "charmsHitCount", "charmsHitSize", "charmsHitSpeed", "charmsHitDuration",
	"charmsHitDamageOnly", "charmsHitMobs", "charmsHitColor",
	// HoleESP y AllESP
	"holeEsp", "holeEspFill", "holeEspOutline", "holeEspRadiusH", "holeEspRadiusV", "holeEspDistance",
	"holeEspHeight", "holeEspOpacity", "holeBedrockColor", "holeObsidianColor", "holeMixedColor",
	"allEsp", "allEspPlayers", "allEspMobs", "allEspItems", "allEspXp", "allEspCrystals", "allEspTnt",
	"allEspBoats", "allEspMinecarts", "allEspMode", "allEspRadius", "allEspYRange", "allEspBudget",
	"allEspMaxBoxes", "allEspOpacity", "allEspSelected", "allEspCustom",
	"noRender", "noRenderEntities", "noRenderBlockEntities", "noRenderParticles", "noRenderWeather",
};
static const char* const kKeysHud[] = {
	"watermark", "watermarkStyle", "watermarkFps", "watermarkTps", "watermarkCoords", "watermarkVersion",
	"hudWatermarkX", "hudWatermarkY", "showPosition", "offsetTextPosX", "offsetTextPosY", "hudCoordsDecimals",
	"playerNear", "offsetTextPlayerNearPosX", "offsetTextPlayerNearPosY", "hudFpsGraph", "hudFpsGraphX",
	"hudFpsGraphY", "hudFpsGraphSeconds", "hudArrayList", "hudArrayListX", "hudArrayListY",
	"targetHud", "targetHudCompare", "targetHudTotems", "targetHudFollow", "targetHudRange", "hudTargetX", "hudTargetY",
	"itemCounter", "itemCounterVertical", "itemCounterHideZero", "hudItemsX", "hudItemsY", "hudInfo",
	"hudInfoDirection", "hudInfoBps", "hudInfoX", "hudInfoY", "sessionHud", "hudSessionX", "hudSessionY",
	"customText", "customTextValue", "customTextSize", "hudTextX", "hudTextY", "hudImage", "hudImageScale",
	"hudImageOpacity", "hudImageX", "hudImageY",
};
static const char* const kKeysAppearance[] = {
	"uiTheme", "uiAccent", "uiManualBg", "uiManualPanel", "uiManualBorder", "uiManualText", "uiManualMuted",
	"uiManualSecondary", "uiManualOff", "uiGlassOpacity", "uiGlassBlur", "uiScale", "uiAnimations",
	"uiAnimSpeed", "uiBgStyle", "uiBgDotsDensity", "uiBgIntensity", "uiBgImage", "uiBgImageOpacity",
	"uiTooltips", "notifEnabled", "notifDuration", "notifPosition", "uiLayout", "cgWidthScale",
	"cgBubbleX", "cgBubbleY", "cgWindows", "cgTextScale", "cgRowScale", "cgHeaderStyle", "cgBackdropDim",
};
static const char* const kKeysKeybinds[] = {
	"hotkeyVolumeUp", "hotkeyVolumeDown", "hotkeyBack", "hotkey_A", "hotkey_B", "hotkey_C", "hotkey_D",
	"hotkey_E", "hotkey_F", "hotkey_G", "hotkey_H", "hotkey_I", "hotkey_J", "hotkey_K", "hotkey_L",
	"hotkey_M", "hotkey_N", "hotkey_O", "hotkey_P", "hotkey_Q", "hotkey_R", "hotkey_S", "hotkey_T",
	"hotkey_U", "hotkey_V", "hotkey_W", "hotkey_X", "hotkey_Y", "hotkey_Z", "hotkey_numpad_0",
	"hotkey_numpad_1", "hotkey_numpad_2", "hotkey_numpad_3", "hotkey_numpad_4", "hotkey_numpad_5",
	"hotkey_numpad_6", "hotkey_numpad_7", "hotkey_numpad_8", "hotkey_numpad_9",
	"screenButtons", "screenButtonScale", "screenButtonOpacity", "screenButtonsLocked",
};
static const char* const kKeysOther[] = {
	"unlockMarket", "fastDrop", "noEmoteCooldown", "myMaxPlayers", "chatModule", "chatGreenText", "chatClientSuffix",
	"chatFancy", "chatFakeName", "chatPrefixTag", "chatPrefixUpper", "chatPrefixLower", "chatPrefixNums",
	"chatSuffixTag", "chatSuffixUpper", "chatSuffixLower", "chatSuffixNums", "chatPrefixLength",
	"chatSuffixLength", "chatFakeNameValue", "chatClientName", "quickCommands",
	"chatCustomBefore", "chatCustomAfter", "chatCustomRandom", "chatBeforePhrases", "chatAfterPhrases",
};

// Claves que el reset general no toca.
static const char* const kKeysPreserved[] = {
	"friendList", "botList", "uiLang", "uiFavorites", "uiSkipIntro", "playerDeathPosX", "playerDeathPosY",
	"playerDeathPosZ", "panic", "cfgVersion", "waypointList",
};

struct SectionKeys {
	const char* const* keys;
	int count;
};

SectionKeys GetSectionKeys(int page) {
	switch (page) {
		case PAGE_MOVEMENT:   return {kKeysMovement, IM_ARRAYSIZE(kKeysMovement)};
		case PAGE_COMBAT:     return {kKeysCombat, IM_ARRAYSIZE(kKeysCombat)};
		case PAGE_BUILDING:   return {kKeysBuilding, IM_ARRAYSIZE(kKeysBuilding)};
		case PAGE_PLAYERS:    return {kKeysPlayers, IM_ARRAYSIZE(kKeysPlayers)};
		case PAGE_VISUALS:    return {kKeysVisuals, IM_ARRAYSIZE(kKeysVisuals)};
		case PAGE_HUD:        return {kKeysHud, IM_ARRAYSIZE(kKeysHud)};
		case PAGE_APPEARANCE: return {kKeysAppearance, IM_ARRAYSIZE(kKeysAppearance)};
		case PAGE_KEYBINDS:   return {kKeysKeybinds, IM_ARRAYSIZE(kKeysKeybinds)};
		case PAGE_OTHER:      return {kKeysOther, IM_ARRAYSIZE(kKeysOther)};
	}
	return {nullptr, 0};
}

void ResetSection(int page) {
	SectionKeys section = GetSectionKeys(page);
	if (!section.keys) return;
	applyDefaults(section.keys, section.count);
	if (page == PAGE_VISUALS) rebuildChunkGeometry = true;
	onFunctionSound = true;
	Notify(TF(S_NotifySectionReset, T(kPageNames[page])), NOTIFY_INFO);
}

void ResetAll() {
	std::vector<std::string> keys;
	for (auto it = g_defaultCfg.begin(); it != g_defaultCfg.end(); ++it) {
		bool preserved = false;
		for (const char* key : kKeysPreserved) {
			if (it.key() == key) preserved = true;
		}
		if (!preserved) keys.push_back(it.key());
	}
	std::vector<const char*> ptrs;
	for (const std::string& key : keys) ptrs.push_back(key.c_str());
	applyDefaults(ptrs.data(), (int)ptrs.size());
	rebuildChunkGeometry = true;
	onFunctionSound = true;
	Notify(T(S_NotifyAllReset), NOTIFY_INFO);
}

// Modal de confirmacion compartido. `ConfirmRequest` lo abre en el proximo
// frame y `DrawConfirmModal` ejecuta la accion si el usuario confirma.
enum ConfirmAction { CONFIRM_NONE, CONFIRM_RESET_SECTION, CONFIRM_RESET_ALL, CONFIRM_DELETE_PROFILE };
static int g_confirmAction = CONFIRM_NONE;
static int g_confirmPage = 0;
static std::string g_confirmText;
static std::string g_confirmProfile;
static bool g_confirmOpenPending = false;

void ConfirmRequest(int action, const std::string& text) {
	g_confirmAction = action;
	g_confirmText = text;
	g_confirmOpenPending = true;
}

void DeleteProfile(const std::string& name);

void DrawConfirmModal() {
	if (g_confirmOpenPending) {
		ImGui::OpenPopup("##gatyo_confirm");
		g_confirmOpenPending = false;
	}
	ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
	if (ImGui::BeginPopupModal("##gatyo_confirm", NULL, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove)) {
		ImGui::PushTextWrapPos(ImGui::GetFontSize() * 24.0f);
		ImGui::TextUnformatted(g_confirmText.c_str());
		ImGui::PopTextWrapPos();
		ImGui::Dummy(ImVec2(0, 6.0f * scaleGlobal));
		if (AccentButton(TL(S_Confirm))) {
			if (g_confirmAction == CONFIRM_RESET_SECTION) ResetSection(g_confirmPage);
			if (g_confirmAction == CONFIRM_RESET_ALL) ResetAll();
			if (g_confirmAction == CONFIRM_DELETE_PROFILE) DeleteProfile(g_confirmProfile);
			g_confirmAction = CONFIRM_NONE;
			ImGui::CloseCurrentPopup();
		}
		ImGui::SameLine();
		if (ImGui::Button(TL(S_Cancel))) {
			g_confirmAction = CONFIRM_NONE;
			ImGui::CloseCurrentPopup();
		}
		ImGui::EndPopup();
	}
}

void RequestResetSection(int page) {
	g_confirmPage = page;
	ConfirmRequest(CONFIRM_RESET_SECTION, TF(S_ResetConfirmSection, T(kPageNames[page])));
}

// ---------------------------------------------------------------------------
// Carpeta de Gatyo, perfiles y exportacion
// ---------------------------------------------------------------------------
std::string GatyoDir() {
	return std::string("/sdcard/Android/data/") + GameName + "/files/gatyo";
}

std::string ProfilesDir() {
	return GatyoDir() + "/profiles";
}

static void EnsureDir(const std::string& path) {
	mkdir(path.c_str(), 0775);
}

static void EnsureGatyoDirs() {
	EnsureDir(std::string("/sdcard/Android/data/") + GameName + "/files");
	EnsureDir(GatyoDir());
	EnsureDir(ProfilesDir());
}

static std::string SanitizeProfileName(const std::string& name) {
	std::string out;
	for (unsigned char c : name) {
		if (c >= 0x80 || isalnum(c) || c == ' ' || c == '-' || c == '_') out += (char)c;
		if (out.size() >= 32) break;
	}
	while (!out.empty() && out.back() == ' ') out.pop_back();
	while (!out.empty() && out.front() == ' ') out.erase(out.begin());
	return out;
}

static std::vector<std::string> g_profiles;
static bool g_profilesDirty = true;

void RefreshProfiles() {
	g_profiles.clear();
	DIR* dir = opendir(ProfilesDir().c_str());
	if (dir) {
		while (dirent* entry = readdir(dir)) {
			std::string name = entry->d_name;
			if (name.size() > 5 && name.compare(name.size() - 5, 5, ".json") == 0) {
				g_profiles.push_back(name.substr(0, name.size() - 5));
			}
		}
		closedir(dir);
	}
	std::sort(g_profiles.begin(), g_profiles.end());
	g_profilesDirty = false;
}

static bool FileExists(const std::string& path) {
	struct stat st;
	return stat(path.c_str(), &st) == 0;
}

void SaveProfile(const std::string& rawName) {
	std::string name = SanitizeProfileName(rawName);
	if (name.empty()) {
		errorFunctionSound = true;
		Notify(T(S_NotifyNameRequired), NOTIFY_ERROR);
		return;
	}
	EnsureGatyoDirs();
	std::string path = ProfilesDir() + "/" + name + ".json";
	saveConfig(path);
	g_profilesDirty = true;
	if (FileExists(path)) {
		onFunctionSound = true;
		Notify(TF(S_NotifyProfileSaved, name.c_str()), NOTIFY_ON);
	} else {
		errorFunctionSound = true;
		Notify(T(S_NotifyProfileError), NOTIFY_ERROR);
	}
}

// El idioma es una preferencia del dispositivo: cargar un perfil no lo cambia.
static bool LoadConfigKeepingLanguage(const std::string& path) {
	int lang = uiLang;
	bool ok = loadConfig(path);
	uiLang = lang;
	if (ok) rebuildChunkGeometry = true;
	return ok;
}

void LoadProfile(const std::string& name) {
	if (LoadConfigKeepingLanguage(ProfilesDir() + "/" + name + ".json")) {
		onFunctionSound = true;
		Notify(TF(S_NotifyProfileLoaded, name.c_str()), NOTIFY_ON);
	} else {
		errorFunctionSound = true;
		Notify(T(S_NotifyProfileError), NOTIFY_ERROR);
	}
}

void DeleteProfile(const std::string& name) {
	if (remove((ProfilesDir() + "/" + name + ".json").c_str()) == 0) {
		offFunctionSound = true;
		Notify(TF(S_NotifyProfileDeleted, name.c_str()), NOTIFY_OFF);
	} else {
		errorFunctionSound = true;
		Notify(T(S_NotifyProfileError), NOTIFY_ERROR);
	}
	g_profilesDirty = true;
}

// ---------------------------------------------------------------------------
// Fondo del menu: imagen propia y/o puntos animados
// ---------------------------------------------------------------------------
static GLuint g_bgTexture = 0;
static int g_bgWidth = 0, g_bgHeight = 0;
static bool g_bgTried = false;

std::string BackgroundImagePath() {
	const char* names[] = {"fondo.png", "fondo.jpg", "background.png", "background.jpg"};
	for (const char* name : names) {
		std::string path = GatyoDir() + "/" + name;
		if (FileExists(path)) return path;
	}
	return GatyoDir() + "/fondo.png";
}

void LoadBackgroundImage() {
	g_bgTried = true;
	if (g_bgTexture) {
		glDeleteTextures(1, &g_bgTexture);
		g_bgTexture = 0;
	}
	EnsureGatyoDirs();
	std::string data = readFile(BackgroundImagePath());
	if (data.empty()) return;
	int w, h, channels;
	if (!stbi_info_from_memory((const stbi_uc*)data.data(), (int)data.size(), &w, &h, &channels)) return;
	g_bgTexture = CreateTextureFromMemoryPNG((const unsigned char*)data.data(), (int)data.size());
	if (g_bgTexture) {
		g_bgWidth = w;
		g_bgHeight = h;
	}
}

void DrawMenuBackground() {
	ImDrawList* dl = ImGui::GetWindowDrawList();
	ImVec2 min = ImGui::GetWindowPos();
	ImVec2 size = ImGui::GetWindowSize();
	if (uiBgImage) {
		if (!g_bgTried) LoadBackgroundImage();
		if (g_bgTexture && g_bgWidth > 0 && g_bgHeight > 0) {
			// recorte tipo "cover": llena la ventana sin deformar la imagen
			float windowAspect = size.x / ImMax(size.y, 1.0f);
			float imageAspect = (float)g_bgWidth / g_bgHeight;
			ImVec2 uv0(0, 0), uv1(1, 1);
			if (imageAspect > windowAspect) {
				float crop = (1.0f - windowAspect / imageAspect) * 0.5f;
				uv0.x = crop;
				uv1.x = 1.0f - crop;
			} else {
				float crop = (1.0f - imageAspect / windowAspect) * 0.5f;
				uv0.y = crop;
				uv1.y = 1.0f - crop;
			}
			dl->AddImage((ImTextureID)(intptr_t)g_bgTexture, min, ImVec2(min.x + size.x, min.y + size.y), uv0, uv1,
			             GatyoU32(ImVec4(1, 1, 1, ImClamp(uiBgImageOpacity, 0.0f, 1.0f))));
		}
	}
	DrawBackgroundEffect(min, ImVec2(min.x + size.x, min.y + size.y));
}

// ---------------------------------------------------------------------------
// Editor de HUD: ventana transparente a pantalla completa (asi la ventana
// tactil de Java cubre toda la pantalla) donde cada elemento se arrastra.
// ---------------------------------------------------------------------------
static const int kHudNames[HUD_COUNT] = {
	MOD_watermark, MOD_showPosition, MOD_playerNear, MOD_hudFpsGraph, MOD_hudArrayList,
	MOD_targetHud, MOD_itemCounter, MOD_hudInfo, MOD_sessionHud, MOD_customText, MOD_hudImage,
};

void DrawHudEditor() {
	ImGuiIO& io = ImGui::GetIO();
	GatyoPalette p = GatyoGetPalette();
	ImGui::SetNextWindowPos(ImVec2(0, 0));
	ImGui::SetNextWindowSize(io.DisplaySize);
	ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove |
	                         ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollWithMouse;
	if (!ImGui::Begin("##GatyoHudEditor", NULL, flags)) {
		ImGui::End();
		return;
	}
	g_window = ImGui::GetCurrentWindow();
	ImDrawList* dl = ImGui::GetWindowDrawList();

	// cuadricula tenue y ejes centrales para alinear
	dl->AddRectFilled(ImVec2(0, 0), io.DisplaySize, GatyoU32(GatyoAlpha(p.bg, 0.30f)));
	float step = 48.0f * scaleGlobal;
	ImU32 grid = GatyoU32(GatyoAlpha(p.border, 0.35f));
	for (float x = step; x < io.DisplaySize.x; x += step) dl->AddLine(ImVec2(x, 0), ImVec2(x, io.DisplaySize.y), grid);
	for (float y = step; y < io.DisplaySize.y; y += step) dl->AddLine(ImVec2(0, y), ImVec2(io.DisplaySize.x, y), grid);
	ImU32 axis = GatyoU32(GatyoAlpha(p.accent, 0.35f));
	dl->AddLine(ImVec2(io.DisplaySize.x * 0.5f, 0), ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y), axis);
	dl->AddLine(ImVec2(0, io.DisplaySize.y * 0.5f), ImVec2(io.DisplaySize.x, io.DisplaySize.y * 0.5f), axis);

	// La barra se envia antes que los elementos: en ImGui, entre items que se
	// superponen gana el primero, y asi un elemento nunca le roba el toque a
	// "Listo". Se dibuja en el canal superior para quedar encima.
	dl->ChannelsSplit(2);
	dl->ChannelsSetCurrent(1);
	const char* hint = T(S_HudEditorHint);
	ImGuiStyle& style = ImGui::GetStyle();
	float buttonsWidth = ImGui::CalcTextSize(T(S_ResetPositions)).x + ImGui::CalcTextSize(T(S_Done)).x + style.FramePadding.x * 4.0f + style.ItemSpacing.x;
	float barWidth = ImMax(ImGui::CalcTextSize(hint).x, buttonsWidth) + style.WindowPadding.x * 2.0f;
	float barHeight = ImGui::GetTextLineHeight() + ImGui::GetFrameHeight() + style.ItemSpacing.y + style.WindowPadding.y * 2.0f;
	ImVec2 barMin((io.DisplaySize.x - barWidth) * 0.5f, io.DisplaySize.y - barHeight - 24.0f * scaleGlobal);
	GatyoGlassPanel(dl, barMin, ImVec2(barMin.x + barWidth, barMin.y + barHeight));
	ImGui::SetCursorScreenPos(ImVec2(barMin.x + style.WindowPadding.x, barMin.y + style.WindowPadding.y));
	ImGui::BeginGroup();
	ImGui::TextUnformatted(hint);
	if (ImGui::Button(TL(S_ResetPositions))) {
		HudResetPositions();
		Notify(T(S_NotifyPositionsReset), NOTIFY_INFO);
	}
	ImGui::SameLine();
	if (AccentButton(TL(S_Done))) {
		g_hudEditor = false;
		onFunctionSound = true;
		Notify(T(S_NotifyConfigSaved), NOTIFY_ON);
	}
	ImGui::EndGroup();
	dl->ChannelsSetCurrent(0);

	for (int e = 0; e < HUD_COUNT; e++) {
		HudRect& r = g_hudRects[e];
		if (!r.visible) continue;
		ImVec2 size(ImMax(r.max.x - r.min.x, 8.0f), ImMax(r.max.y - r.min.y, 8.0f));
		ImGui::SetCursorScreenPos(r.min);
		ImGui::PushID(e);
		ImGui::InvisibleButton("##hud_element", size);
		bool active = ImGui::IsItemActive();
		// el primer frame del toque trae el salto desde la posicion anterior del dedo
		if (active && !ImGui::IsMouseClicked(ImGuiMouseButton_Left) && ImGui::IsMouseDragging(ImGuiMouseButton_Left, 0.0f)) HudMove(e, io.MouseDelta);
		ImGui::PopID();

		ImVec4 outline = active ? p.secondary : (ImGui::IsItemHovered() ? p.accent : GatyoAlpha(p.accent, 0.6f));
		float pad = 4.0f * scaleGlobal;
		dl->AddRect(ImVec2(r.min.x - pad, r.min.y - pad), ImVec2(r.max.x + pad, r.max.y + pad), GatyoU32(outline), 0.0f, 0, ImMax(1.0f, 2.0f * scaleGlobal));
		const char* name = ModName(kHudNames[e]);
		float tagSize = 18.0f * scaleGlobal;
		ImVec2 tagPos(r.min.x - pad, r.min.y - pad - tagSize - 6.0f * scaleGlobal);
		if (tagPos.y < 0) tagPos.y = r.max.y + pad + 4.0f * scaleGlobal;
		float tagWidth = ImGui::CalcTextSize(name).x * (tagSize / ImGui::GetFontSize());
		dl->AddRectFilled(tagPos, ImVec2(tagPos.x + tagWidth + 10.0f * scaleGlobal, tagPos.y + tagSize + 6.0f * scaleGlobal), GatyoU32(GatyoAlpha(outline, 0.9f)));
		dl->AddText(nullptr, tagSize, ImVec2(tagPos.x + 5.0f * scaleGlobal, tagPos.y + 3.0f * scaleGlobal), GatyoU32(p.light ? p.bg : p.text), name);
	}
	dl->ChannelsMerge();
	ImGui::End();
}

// ---------------------------------------------------------------------------
// Panel lateral
// ---------------------------------------------------------------------------
static double g_pageSwitchTime = -10.0;
static int g_lastPage = -1;

void DrawSidebar(float width) {
	GatyoPalette p = GatyoGetPalette();
	ImGuiStyle& style = ImGui::GetStyle();
	ImGui::BeginChild("##gatyo_sidebar", ImVec2(width, 0), false, ImGuiWindowFlags_NoScrollbar);
	DrawSearchField(ImGui::GetContentRegionAvail().x);
	ImGui::Dummy(ImVec2(0, 4.0f * scaleGlobal));

	static float indicatorY = -1.0f;
	float targetY = indicatorY;
	float itemHeight = ImGui::GetFrameHeight() + 6.0f * scaleGlobal * uiScale;
	ImDrawList* dl = ImGui::GetWindowDrawList();
	float rowWidth = ImGui::GetContentRegionAvail().x;
	bool searching = SearchActive();

	ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(style.ItemSpacing.x, 2.0f * scaleGlobal));
	for (int page = 0; page < PAGE_COUNT; page++) {
		ImGui::PushID(page);
		ImVec2 pos = ImGui::GetCursorScreenPos();
		if (ImGui::InvisibleButton("##page", ImVec2(rowWidth, itemHeight))) {
			pageId = page;
			g_searchQuery.clear();
		}
		bool selected = pageId == page && !searching;
		bool hovered = ImGui::IsItemHovered();
		ImVec2 max(pos.x + rowWidth, pos.y + itemHeight);
		if (selected) {
			dl->AddRectFilled(pos, max, GatyoU32(GatyoAlpha(p.accent, 0.20f)));
			targetY = pos.y - ImGui::GetWindowPos().y;
		} else if (hovered) {
			dl->AddRectFilled(pos, max, GatyoU32(GatyoAlpha(p.hover, 0.30f)));
		}
		float textX = pos.x + 14.0f * scaleGlobal * uiScale;
		dl->AddText(ImVec2(textX, pos.y + (itemHeight - ImGui::GetFontSize()) * 0.5f), GatyoU32(selected ? p.text : p.muted), T(kPageNames[page]));
		ImGui::PopID();
	}
	ImGui::PopStyleVar();

	// barra de seleccion animada
	if (!searching) {
		if (indicatorY < 0.0f || !uiAnimations) indicatorY = targetY;
		else indicatorY += (targetY - indicatorY) * ImMin(1.0f, ImGui::GetIO().DeltaTime * 16.0f * uiAnimSpeed);
		ImVec2 barMin(ImGui::GetWindowPos().x, ImGui::GetWindowPos().y + indicatorY);
		int start = dl->VtxBuffer.Size;
		dl->AddRectFilled(barMin, ImVec2(barMin.x + 4.0f * scaleGlobal, barMin.y + itemHeight), GatyoU32(ImVec4(1, 1, 1, 1)));
		GatyoShadeVerts(dl, start, dl->VtxBuffer.Size, false);
	}
	ImGui::EndChild();
}

// Encabezado de pagina: titulo grande con degradado y boton de reset.
void DrawPageHeader(int page) {
	GatyoPalette p = GatyoGetPalette();
	ImDrawList* dl = ImGui::GetWindowDrawList();
	float titleSize = ImGui::GetFontSize() * 1.35f;
	ImVec2 pos = ImGui::GetCursorScreenPos();
	GatyoFlowText(dl, pos, T(kPageNames[page]), titleSize, 1.0f, false);

	// derecha: acceso al ClickGUI y, si la pagina tiene ajustes, el reset
	SectionKeys keys = GetSectionKeys(page);
	ImGuiStyle& style = ImGui::GetStyle();
	const char* resetLabel = TL(S_Reset);
	const char* cgLabel = TL(S_LayoutClickGui);
	float resetWidth = keys.keys ? ImGui::CalcTextSize(resetLabel, NULL, true).x + style.FramePadding.x * 2.0f + style.ItemSpacing.x : 0.0f;
	float cgWidth = ImGui::CalcTextSize(cgLabel, NULL, true).x + style.FramePadding.x * 2.0f;
	float right = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
	ImGui::SetCursorScreenPos(ImVec2(right - resetWidth - cgWidth, pos.y));
	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
	ImGui::PushStyleColor(ImGuiCol_Text, p.muted);
	if (ImGui::Button(cgLabel)) uiLayout = 1;
	Tip(S_TipLayout);
	if (keys.keys) {
		ImGui::SameLine();
		if (ImGui::Button(resetLabel)) RequestResetSection(page);
		Tip(S_ResetSection);
	}
	ImGui::PopStyleColor(2);
	ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + titleSize + 6.0f * scaleGlobal));
	ImGui::Dummy(ImVec2(0, 0));
}

// ---------------------------------------------------------------------------
// Paginas nuevas
// ---------------------------------------------------------------------------
void ColorEditT(StrId id, float* color) {
	ImGui::ColorEdit3(TL(id), color, ImGuiColorEditFlags_NoInputs);
}

void DrawLanguageButtons() {
	GatyoPalette p = GatyoGetPalette();
	const char* names[] = {"Español", "English"};
	for (int i = 0; i < 2; i++) {
		if (i > 0) ImGui::SameLine();
		bool selected = uiLang == i;
		ImGui::PushStyleColor(ImGuiCol_Button, selected ? GatyoAlpha(p.accent, 0.8f) : GatyoAlpha(p.panel, 0.85f));
		if (ImGui::Button(names[i])) uiLang = i;
		ImGui::PopStyleColor();
	}
}

void DrawAppearancePage() {
	float u = UiUnit();

	SectionTitle(S_SectionLanguage);
	DrawLanguageButtons();

	SectionTitle(S_SectionLayout);
	{
		static const StrId layouts[] = {S_LayoutPanel, S_LayoutClickGui};
		ImGui::PushItemWidth(u * 300);
		ComboT("##layout", &uiLayout, layouts, IM_ARRAYSIZE(layouts));
		Tip(S_TipLayout);
		if (uiLayout == 1) ImGui::SliderFloat(TL(S_CgWindowWidth), &cgWidthScale, 0.6f, 1.6f, "%.2fx");
		ImGui::PopItemWidth();
	}

	SectionTitle(S_SectionTheme);
	ImGui::PushItemWidth(u * 300);
	static const StrId themes[] = {S_ThemeGatyo, S_ThemeDark, S_ThemeLight, S_ThemeManual};
	ComboT("##theme", &uiTheme, themes, IM_ARRAYSIZE(themes));
	ImGui::PopItemWidth();
	if (uiTheme == 3) {
		ColorEditT(S_ManualBg, uiManualBg); ImGui::SameLine();
		ColorEditT(S_ManualPanel, uiManualPanel); ImGui::SameLine();
		ColorEditT(S_ManualBorder, uiManualBorder);
		ColorEditT(S_ManualText, uiManualText); ImGui::SameLine();
		ColorEditT(S_ManualMuted, uiManualMuted);
		ColorEditT(S_ManualSecondary, uiManualSecondary); ImGui::SameLine();
		ColorEditT(S_ManualOff, uiManualOff);
	}

	SectionTitle(S_SectionAccent);
	ImGui::ColorEdit3("##accent", uiAccent, ImGuiColorEditFlags_NoInputs);
	static const StrId presetNames[] = {S_AccentViolet, S_AccentPink, S_AccentLavender, S_AccentCyan, S_AccentMint, S_AccentAmber, S_AccentCoral};
	for (int i = 0; i < IM_ARRAYSIZE(kAccentPresets); i++) {
		ImGui::SameLine();
		const GatyoAccentPreset& preset = kAccentPresets[i];
		ImGui::PushID(i);
		if (ImGui::ColorButton("##preset", GatyoRgb(preset.r, preset.g, preset.b), ImGuiColorEditFlags_NoTooltip, ImVec2(ImGui::GetFrameHeight(), ImGui::GetFrameHeight()))) {
			uiAccent[0] = preset.r / 255.0f;
			uiAccent[1] = preset.g / 255.0f;
			uiAccent[2] = preset.b / 255.0f;
		}
		Tip(presetNames[i]);
		ImGui::PopID();
	}

	SectionTitle(S_SectionGlass);
	ImGui::PushItemWidth(u * 300);
	ImGui::SliderFloat(TL(S_GlassOpacity), &uiGlassOpacity, 0.3f, 1.0f, "%.2f");
	ImGui::SliderInt(TL(S_GlassBlur), &uiGlassBlur, 0, 60, "%d px");
	Tip(S_TipGlassBlur);
	ImGui::PopItemWidth();
	if (!g_blurSupported) MutedText(T(S_BlurUnsupported));

	SectionTitle(S_SectionMenu);
	ImGui::PushItemWidth(u * 300);
	static float pendingScale = 1.0f;
	ImGui::SliderFloat(TL(S_MenuScale), &pendingScale, 0.8f, 1.4f, "%.2fx");
	if (ImGui::IsItemDeactivatedAfterEdit()) uiScale = pendingScale;
	if (!ImGui::IsItemActive()) pendingScale = uiScale;
	Tip(S_TipMenuScale);
	ModToggle(MOD_uiAnimations);
	ImGui::SameLine();
	ModToggle(MOD_uiTooltips);
	ImGui::BeginDisabled(!uiAnimations);
	ImGui::SliderFloat(TL(S_AnimSpeed), &uiAnimSpeed, 0.25f, 3.0f, "%.2fx");
	ImGui::EndDisabled();
	ImGui::PopItemWidth();

	SectionTitle(S_SectionBackground);
	ImGui::PushItemWidth(u * 300);
	ComboT(TL(S_BgStyle), &uiBgStyle, kBackgroundNames, BG_COUNT);
	Tip(S_TipBgStyle);
	if (uiBgStyle != BG_NONE) {
		ImGui::SliderFloat(TL(S_BgIntensity), &uiBgIntensity, 0.1f, 1.0f, "%.2f");
		if (uiBgStyle == BG_DOTS || uiBgStyle == BG_PARTICLES || uiBgStyle == BG_STARS) {
			ImGui::SliderInt(TL(S_DotsDensity), &uiBgDotsDensity, 20, 400);
		}
	}
	if (ModToggle(MOD_uiBgImage) && uiBgImage) LoadBackgroundImage();
	if (uiBgImage) {
		ImGui::SliderFloat(TL(S_ImageOpacity), &uiBgImageOpacity, 0.05f, 1.0f, "%.2f");
		MutedText(T(S_ImagePath));
		MutedText(BackgroundImagePath().c_str());
		if (ImGui::Button(TL(S_ReloadImage))) LoadBackgroundImage();
		ImGui::SameLine();
		if (g_bgTexture) {
			ImGui::AlignTextToFramePadding();
			ImGui::TextUnformatted(TF(S_ImageLoaded, g_bgWidth, g_bgHeight).c_str());
		} else {
			ImGui::AlignTextToFramePadding();
			ImGui::TextColored(GatyoState::Danger, "%s", T(S_ImageMissing));
		}
	}
	ImGui::PopItemWidth();

	SectionTitle(S_SectionNotifications);
	ImGui::PushItemWidth(u * 300);
	ModToggle(MOD_notifEnabled);
	ImGui::BeginDisabled(!notifEnabled);
	ImGui::SliderFloat(TL(S_NotifDuration), &notifDuration, 1.5f, 10.0f, "%.1f");
	static const StrId positions[] = {S_PosBottomRight, S_PosTopRight};
	ComboT(TL(S_NotifPosition), &notifPosition, positions, IM_ARRAYSIZE(positions));
	ImGui::EndDisabled();
	ImGui::PopItemWidth();
}

// Combo de los modos de rotacion de GatoAuraX: "Ninguna" se traduce, el resto
// son nombres propios de GatoClient.
bool GatoAuraXRotationCombo(const char* label) {
	const char* names[GAX_ROT_COUNT];
	for (int i = 0; i < GAX_ROT_COUNT; i++) names[i] = i == GAX_ROT_NONE ? T(S_GaxRotNone) : kGaxRotNames[i];
	return ImGui::Combo(label, &gaxRotationMode, names, GAX_ROT_COUNT);
}

void DrawAuraWeaponSettings(int* switchMode, bool* rainMode, bool* autoTrident, float width);

// Pestaña "GatoAuraX" de Combate.
void DrawGatoAuraXTab() {
	float u = UiUnit();
	ModToggle(MOD_gatoAuraX);
	ImGui::PushItemWidth(u * 300);
	static const StrId targetModes[] = {S_GaxSingle, S_GaxMulti};
	ComboT(TL(S_GaxTargetMode), &gaxTargetMode, targetModes, IM_ARRAYSIZE(targetModes));
	ImGui::SliderFloat(TL(S_GaxRange), &gaxRange, 2.0f, 150.0f, "%.1f");
	ImGui::SliderInt(TL(S_GaxInterval), &gaxInterval, 0, 20);
	ImGui::SliderInt(TL(S_GaxMultiplier), &gaxMultiplier, 1, 10);
	GatoAuraXRotationCombo(TL(S_GaxRotation));
	Tip(S_TipGaxRotation);
	if (gaxRotationMode == GAX_ROT_ECLIPSE) {
		ImGui::SliderFloat(TL(S_GaxEclipseLead), &gaxEclipseLead, 0.0f, 4.0f, "%.1f");
		Tip(S_TipGaxEclipse);
	}
	ImGui::SliderFloat(TL(S_GaxVertOffset), &gaxVertOffset, -1.0f, 1.0f, "%.2f");
	ImGui::PopItemWidth();
	MutedText(T(S_TipGaxKeys));

	ModToggle(MOD_gaxMoveCamera);
	ImGui::SameLine();
	ModToggle(MOD_gaxHurttime);
	ModToggle(MOD_gaxAttackMobs);
	ImGui::SameLine();
	ModToggle(MOD_gaxNoSwing);
	ModToggle(MOD_gaxRandomizeHit);
	if (gaxRandomizeHit) {
		ImGui::SameLine();
		ImGui::PushItemWidth(u * 260);
		ImGui::SliderInt(TL(S_GaxHitChance), &gaxHitChance, 1, 100);
		ImGui::PopItemWidth();
	}
	ModToggle(MOD_gaxTargetVisualize);
	if (gaxTargetVisualize) {
		ImGui::SameLine();
		ImGui::ColorEdit4(TL(S_GaxTvColor), gaxTvColor, ImGuiColorEditFlags_NoInputs);
	}
	DrawAuraWeaponSettings(&gaxSwitchMode, &gaxRainMode, &gaxAutoTrident, u * 300);
}

// Cambio de arma, Modo lluvia y Tridente en el agua: los comparten GatoAuraX y
// el +999 Aura. Ancho negativo = fila del ClickGUI.
void DrawAuraWeaponSettings(int* switchMode, bool* rainMode, bool* autoTrident, float width) {
	static const StrId switchModes[] = {S_Off, S_AuraSwitchFull, S_AuraSwitchSilent};
	ImGui::PushID(switchMode);
	ImGui::PushItemWidth(width);
	ComboT(TL(S_AuraSwitch), switchMode, switchModes, IM_ARRAYSIZE(switchModes));
	Tip(S_TipAuraSwitch);
	ImGui::Checkbox(TL(S_AuraRainMode), rainMode);
	Tip(S_TipAuraRainMode);
	ImGui::Checkbox(TL(S_AuraAutoTrident), autoTrident);
	Tip(S_TipAuraAutoTrident);
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Ajustes del +999 Aura (pestaña de Combate y fila del ClickGUI).
void DrawPlus999AuraSettings(float width) {
	static const StrId targetModes[] = {S_GaxSingle, S_GaxMulti};
	ImGui::PushID("p9");
	ImGui::PushItemWidth(width);
	const char* rotNames[P9_ROT_COUNT];
	for (int i = 0; i < P9_ROT_COUNT; i++) rotNames[i] = i == P9_ROT_NONE ? T(S_GaxRotNone) : kP9RotNames[i];
	ImGui::Combo(TL(S_GaxRotation), &p9RotationMode, rotNames, P9_ROT_COUNT);
	Tip(S_TipP9Rotation);
	ComboT(TL(S_GaxTargetMode), &p9TargetMode, targetModes, IM_ARRAYSIZE(targetModes));
	ImGui::SliderFloat(TL(S_GaxRange), &p9Range, 2.0f, 150.0f, "%.1f");
	ImGui::SliderInt(TL(S_GaxInterval), &p9Interval, 0, 20);
	ImGui::SliderInt(TL(S_GaxMultiplier), &p9Multiplier, 1, 10);
	if (p9RotationMode == P9_ROT_AIRHVH) {
		ImGui::SliderFloat(TL(S_GaxVertOffset), &p9VertOffset, -1.0f, 1.0f, "%.2f");
		Tip(S_TipP9VertOffset);
	}
	ImGui::Checkbox(TL(S_AuraMoveCamera), &p9MoveCamera);
	ImGui::Checkbox(TL(S_AuraHurttime), &p9Hurttime);
	ImGui::Checkbox(TL(S_AuraNoSwing), &p9NoSwing);
	ImGui::Checkbox(TL(S_AuraTargetVisualize), &p9TargetVisualize);
	Tip(S_TipP9TargetVisualize);
	if (p9TargetVisualize) ImGui::ColorEdit4(TL(S_GaxTvColor), p9TvColor, ImGuiColorEditFlags_NoInputs);
	ImGui::PopItemWidth();
	DrawAuraWeaponSettings(&p9SwitchMode, &p9RainMode, &p9AutoTrident, width);
	ImGui::PopID();
}

// Pestaña "+999 Aura" de Combate.
void DrawPlus999AuraTab() {
	ModToggle(MOD_plus999Aura);
	DrawPlus999AuraSettings(UiUnit() * 300);
	MutedText(T(S_TipGaxKeys));
}

// Ajustes de AutoHotbar: cada item con su casilla y su slot.
void DrawAutoHotbarSettings(float width) {
	ImGui::PushID("autohotbar");
	MutedText(T(S_TipAutoHotbar));
	ImGui::PushItemWidth(width);
	ImGui::SliderInt(TL(S_AhDelay), &autoHotbarDelay, 0, 20);
	ImGui::PopItemWidth();
	bool narrow = width < 0.0f;
	float slider = narrow ? -1.0f : UiUnit() * 160;
	for (int i = 0; i < AH_COUNT; i++) {
		ImGui::PushID(i);
		ImGui::Checkbox(T(kAutoHotbarEntries[i].label), &autoHotbarItems[i]);
		if (autoHotbarItems[i]) {
			if (!narrow) ImGui::SameLine(UiUnit() * 360);
			ImGui::PushItemWidth(slider);
			ImGui::SliderInt("##slot", &autoHotbarSlots[i], 1, 9, (std::string(T(S_AhSlot)) + " %d").c_str());
			ImGui::PopItemWidth();
		}
		ImGui::PopID();
	}
	ImGui::PopID();
}

// Ajustes de ViewModel: posicion, giro y tamaño de cada mano.
void DrawViewModelSettings(float width) {
	ImGui::PushID("viewmodel");
	ImGui::PushItemWidth(width);
	auto hand = [&](StrId title, float* pos, float* rot, float* scale, const char* id) {
		ImGui::PushID(id);
		SectionTitle(title);
		ImGui::SliderFloat3(TL(S_VmPosition), pos, -2.0f, 2.0f, "%.2f");
		Tip(S_TipVmPosition);
		ImGui::SliderFloat3(TL(S_VmRotation), rot, -180.0f, 180.0f, "%.0f");
		ImGui::SliderFloat3(TL(S_VmScale), scale, -1.0f, 2.0f, "%.2f");
		Tip(S_TipVmScale);
		if (ImGui::Button(TL(S_VmReset))) {
			for (int i = 0; i < 3; i++) {
				pos[i] = rot[i] = 0.0f;
				scale[i] = 1.0f;
			}
		}
		ImGui::PopID();
	};
	hand(S_VmMainHand, vmMainPos, vmMainRot, vmMainScale, "main");
	ImGui::SameLine();
	if (ImGui::Button(TL(S_VmCopyToOff))) {
		// la segunda mano esta del otro lado: X y los giros en Y/Z van espejados
		for (int i = 0; i < 3; i++) {
			vmOffPos[i] = i == 0 ? -vmMainPos[i] : vmMainPos[i];
			vmOffRot[i] = i == 0 ? vmMainRot[i] : -vmMainRot[i];
			vmOffScale[i] = vmMainScale[i];
		}
	}
	hand(S_VmOffHand, vmOffPos, vmOffRot, vmOffScale, "off");
	ImGui::PopItemWidth();
	ImGui::PopID();
}

void DrawSwingSpeedSettings(float width) {
	ImGui::PushItemWidth(width);
	ImGui::SliderInt(TL(S_SwingTicks), &swingDuration, 1, 70);
	Tip(S_TipSwingTicks);
	ImGui::PopItemWidth();
}

// Ajustes de Nametags (pestaña Render de Visuales y fila del ClickGUI).
void DrawNametagsSettings(float width) {
	static const StrId modes[] = {S_NtModeNone, S_NtModeUnderline, S_NtModeOutline};
	ImGui::PushID("nametags");
	ImGui::PushItemWidth(width);
	ComboT(TL(S_NtMode), &ntMode, modes, IM_ARRAYSIZE(modes));
	ImGui::SliderInt(TL(S_NtOpacity), &ntOpacity, 0, 255);
	ImGui::SliderFloat(TL(S_NtTextSize), &ntTextSize, 0.5f, 2.0f, "%.2f");
	if (ntMode > 0) ImGui::ColorEdit4(TL(S_NtRectColor), ntRectColor, ImGuiColorEditFlags_NoInputs);
	ImGui::Checkbox(TL(S_NtArmor), &ntArmor);
	Tip(S_TipNtArmor);
	ImGui::Checkbox(TL(S_NtSelf), &ntSelf);
	Tip(S_TipNtSelf);
	ImGui::Checkbox(TL(S_NtDynamic), &ntDynamic);
	Tip(S_TipNtDynamic);
	ImGui::Checkbox(TL(S_NtHealth), &ntHealth);
	ImGui::Checkbox(TL(S_NtColoredNames), &ntColoredNames);
	Tip(S_TipNtColoredNames);
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// ---------------------------------------------------------------------------
// Suite de cristales. Las mismas funciones pintan la pestaña del panel y la
// fila del ClickGUI; los bools de sub-ajustes son ajustes normales (con
// Checkbox), solo los 6 modulos entran en ModToggle.
// ---------------------------------------------------------------------------

// Ajustes de AutoCrystal (pestaña propia de Combate y panel del ClickGUI).
void DrawAutoCrystalSettings(float width) {
	ImGui::PushItemWidth(width);
	static const StrId prioridades[] = {S_AcPrioDamage, S_AcPrioDistance};
	SectionTitle(S_acSectBreak);
	ImGui::Checkbox(TL(S_AcBreak), &acBreak);
	if (acBreak) {
		ImGui::SliderInt(TL(S_AcBreakDelay), &acBreakDelay, 0, 20);
		ImGui::SliderFloat(TL(S_AcBreakRange), &acBreakRange, 0.5f, 12.0f, "%.1f");
		ImGui::Checkbox(TL(S_AcInhibit), &acInhibit);
		ImGui::Checkbox(TL(S_AcWhileEating), &acWhileEating);
	}
	SectionTitle(S_acSectPlace);
	ImGui::Checkbox(TL(S_AcPlace), &acPlace);
	if (acPlace) {
		ImGui::SliderInt(TL(S_AcPlaceDelay), &acPlaceDelay, 0, 20);
		ImGui::SliderFloat(TL(S_AcPlaceRange), &acPlaceRange, 0.5f, 12.0f, "%.1f");
		ImGui::SliderInt(TL(S_AcMultiPlace), &acMultiPlace, 1, 5);
		ImGui::SliderInt(TL(S_AcBuildSpeed), &acBuildSpeed, 1, 3);
		ImGui::Checkbox(TL(S_AcMultitask), &acMultitask);
		ImGui::Checkbox(TL(S_AcAlternate), &acAlternate);
	}
	ComboT(TL(S_AcPriority), &acPriority, prioridades, IM_ARRAYSIZE(prioridades));
	ImGui::SliderFloat(TL(S_AcEnemyDamage), &acEnemyDamage, 0.0f, 20.0f, "%.1f");
	ImGui::SliderFloat(TL(S_AcSelfDamage), &acSelfDamage, 0.0f, 20.0f, "%.1f");
	ImGui::SliderFloat(TL(S_AcProximity), &acProximity, 0.0f, 12.0f, "%.1f");
	ImGui::Checkbox(TL(S_AcSelf), &acSelf);
	SectionTitle(S_acSectOther);
	static const StrId slots[] = {S_AcSwNone, S_AcSwNormal, S_AcSwSilent, S_AcSwPacket};
	ComboT(TL(S_AcSwitch), &acSwitch, slots, IM_ARRAYSIZE(slots));
	ImGui::Checkbox(TL(S_AcRotate), &acRotate);
	ImGui::Checkbox(TL(S_AcKASync), &acKASync);
	if (acKASync) ImGui::SliderInt(TL(S_AcPostDelay), &acPostDelay, 0, 20);
	ImGui::Checkbox(TL(S_AcIDPredict), &acIDPredict);
	if (acIDPredict) {
		ImGui::SliderInt(TL(S_AcIDDelay), &acIDDelay, 0, 20);
		MutedText(T(S_NoteIDPredict));
	}
	if (acPacketPlace || acPacketAttack) MutedText(T(S_NotePacketFallback));
	ImGui::Checkbox(TL(S_AcPacketPlace), &acPacketPlace);
	ImGui::Checkbox(TL(S_AcPacketAttack), &acPacketAttack);
	SectionTitle(S_acSectRender);
	ImGui::Checkbox(TL(S_AcRender), &acRender);
	if (acRender) {
		ImGui::Checkbox(TL(S_AcDamageText), &acDamageText);
		ImGui::Checkbox(TL(S_AcFade), &acFade);
		if (acFade) ImGui::SliderInt(TL(S_AcFadeDuration), &acFadeDuration, 1, 40);
		ImGui::Checkbox(TL(S_AcSlide), &acSlide);
		if (acSlide) ImGui::SliderFloat(TL(S_AcSlideSpeed), &acSlideSpeed, 1.0f, 8.0f, "%.1f");
		ImGui::Checkbox(TL(S_AcFlat), &acFlat);
		ImGui::ColorEdit4(TL(S_AcFillColor), acFillColor, ImGuiColorEditFlags_NoInputs);
		ImGui::ColorEdit4(TL(S_AcLineColor), acLineColor, ImGuiColorEditFlags_NoInputs);
		if (acDamageText) ImGui::ColorEdit4(TL(S_AcTextColor), acTextColor, ImGuiColorEditFlags_NoInputs);
	}
	ImGui::PopItemWidth();
}

// Ajustes de AutoCrystalX (pestaña propia de Combate y panel del ClickGUI).
void DrawAutoCrystalXSettings(float width) {
	ImGui::PushItemWidth(width);
	static const StrId prioridades[] = {S_AcxPrioDamage, S_AcxPrioDistance};
	SectionTitle(S_acxSectTargets);
	ImGui::SliderFloat(TL(S_AcxTargetRange), &acxTargetRange, 1.0f, 48.0f, "%.1f");
	ImGui::SliderFloat(TL(S_AcxProximity), &acxProximity, 0.0f, 48.0f, "%.1f");
	ComboT(TL(S_AcxPriority), &acxPriority, prioridades, IM_ARRAYSIZE(prioridades));
	ImGui::SliderFloat(TL(S_AcxMinDamage), &acxMinDamage, 0.0f, 20.0f, "%.1f");
	ImGui::SliderFloat(TL(S_AcxEnemyDamage), &acxEnemyDamage, 0.0f, 20.0f, "%.1f");
	ImGui::SliderFloat(TL(S_AcxSelfDamage), &acxSelfDamage, 0.0f, 20.0f, "%.1f");
	ImGui::SliderFloat(TL(S_AcxWasteAmount), &acxWasteAmount, 0.0f, 10.0f, "%.1f");
	ImGui::Checkbox(TL(S_AcxSelf), &acxSelf);
	ImGui::Checkbox(TL(S_AcxJava), &acxJava);
	ImGui::Checkbox(TL(S_AcxPhase), &acxPhase);
	SectionTitle(S_acxSectBreak);
	ImGui::Checkbox(TL(S_AcxBreak), &acxBreak);
	if (acxBreak) {
		ImGui::SliderInt(TL(S_AcxBreakDelay), &acxBreakDelay, 0, 20);
		ImGui::SliderFloat(TL(S_AcxBreakRange), &acxBreakRange, 0.5f, 12.0f, "%.1f");
	}
	ImGui::Checkbox(TL(S_AcxEatStop), &acxEatStop);
	if (!acxEatStop) {
		ImGui::Checkbox(TL(S_AcxMultitask), &acxMultitask);
		Tip(S_TipAcxMultitask);
	}
	ImGui::Checkbox(TL(S_AcxSync), &acxSync);
	if (acxSync) ImGui::SliderInt(TL(S_AcxSyncDelay), &acxSyncDelay, 0, 20);
	ImGui::Checkbox(TL(S_AcxIDPredict), &acxIDPredict);
	Tip(S_TipAcxIDPredict);
	if (acxIDPredict) {
		ImGui::SliderInt(TL(S_AcxIDDelay), &acxIDDelay, 0, 20);
		ImGui::SliderInt(TL(S_AcxIDPackets), &acxIDPackets, 1, 20);
		ImGui::SliderFloat(TL(S_AcxIDDamage), &acxIDDamage, 0.0f, 20.0f, "%.1f");
		MutedText(T(S_NoteAcxIDPredict));
	}
	SectionTitle(S_acxSectPlace);
	ImGui::Checkbox(TL(S_AcxPlace), &acxPlace);
	if (autoCrystalX) MutedText(TF(S_AcxStatus, AcxStatusText().c_str()).c_str());
	if (acxPlace) {
		ImGui::SliderInt(TL(S_AcxPlaceDelay), &acxPlaceDelay, 0, 20);
		ImGui::SliderFloat(TL(S_AcxPlaceRange), &acxPlaceRange, 0.5f, 12.0f, "%.1f");
		ImGui::SliderInt(TL(S_AcxPlaceCount), &acxPlaceCount, 1, 6);
		Tip(S_TipAcxPlaceCount);
		if (acxPlaceCount > 1) {
			ImGui::Checkbox(TL(S_AcxSpread), &acxSpread);
			Tip(S_TipAcxSpread);
		}
		ImGui::Checkbox(TL(S_AcxAlternate), &acxAlternate);
		Tip(S_TipAcxAlternate);
	}
	ImGui::Checkbox(TL(S_AcxPacketPlace), &acxPacketPlace);
	SectionTitle(S_acxSectTerrain);
	ImGui::Checkbox(TL(S_AcxTerrain), &acxTerrain);
	if (acxTerrain) {
		ImGui::Checkbox(TL(S_AcxAirPlace), &acxAirPlace);
		if (acxAirPlace) MutedText(T(S_NoteAirPlace));
		ImGui::Checkbox(TL(S_AcxPacketTerrain), &acxPacketTerrain);
		ImGui::SliderInt(TL(S_AcxBlocksPerTick), &acxBlocksPerTick, 1, 4);
		ImGui::SliderFloat(TL(S_AcxTerrainProx), &acxTerrainProx, 0.5f, 10.0f, "%.1f");
		ImGui::SliderInt(TL(S_AcxTerrainDelay), &acxTerrainDelay, 0, 10);
		MutedText(T(S_NoteTerrain));
	}
	SectionTitle(S_acxSectDynamic);
	ImGui::Checkbox(TL(S_AcxDynamic), &acxDynamic);
	if (acxDynamic) {
		ImGui::SliderInt(TL(S_AcxPredictTicks), &acxPredictTicks, 0, 10);
		ImGui::SliderFloat(TL(S_AcxVelWeight), &acxVelWeight, 0.01f, 1.0f, "%.2f");
		ImGui::SliderFloat(TL(S_AcxIntercept), &acxIntercept, 0.0f, 2.0f, "%.2f");
	}
	SectionTitle(S_acxSectRender);
	ImGui::Checkbox(TL(S_AcxRender), &acxRender);
	if (acxRender) {
		ImGui::Checkbox(TL(S_AcxDamageText), &acxDamageText);
		ImGui::Checkbox(TL(S_AcxFade), &acxFade);
		if (acxFade) ImGui::SliderInt(TL(S_AcxFadeDuration), &acxFadeDuration, 1, 40);
		ImGui::Checkbox(TL(S_AcxFlat), &acxFlat);
		ImGui::Checkbox(TL(S_AcxLerp), &acxLerp);
		if (acxLerp) ImGui::SliderFloat(TL(S_AcxSpeed), &acxSpeed, 1.0f, 30.0f, "%.1f");
		ImGui::ColorEdit4(TL(S_AcxFillColor), acxFillColor, ImGuiColorEditFlags_NoInputs);
		ImGui::ColorEdit4(TL(S_AcxLineColor), acxLineColor, ImGuiColorEditFlags_NoInputs);
		if (acxDamageText) ImGui::ColorEdit4(TL(S_AcxTextColor), acxTextColor, ImGuiColorEditFlags_NoInputs);
	}
	ImGui::PopItemWidth();
}

// Ajustes de AntiCrystal (seccion Otros de Combate y panel del ClickGUI).
void DrawAntiCrystalSettings(float width) {
	ImGui::PushItemWidth(width);
	ImGui::SliderFloat(TL(S_AntiReduceY), &antiCrystalReduceY, -1.0f, 1.0f, "%.2f");
	ImGui::SliderFloat(TL(S_AntiReduceXZ), &antiCrystalReduceXZ, 0.0f, 2.0f, "%.2f");
	static const StrId modos[] = {S_AntiHorVelocity, S_AntiHorLook};
	ComboT(TL(S_AntiHorizontal), &antiCrystalHorizontal, modos, IM_ARRAYSIZE(modos));
	ImGui::Checkbox(TL(S_AntiMotionSpoof), &antiCrystalMotionSpoof);
	ImGui::Checkbox(TL(S_AntiFeetOnly), &antiCrystalFeetOnly);
	ImGui::PopItemWidth();
}

// Ajustes de SelfTrap (seccion Otros de Combate y panel del ClickGUI).
void DrawSelfTrapSettings(float width) {
	ImGui::PushItemWidth(width);
	ImGui::SliderInt(TL(S_SelfTrapHeight), &selfTrapHeight, 1, 6);
	Tip(S_TipSelfTrapHeight);
	ImGui::SliderInt(TL(S_SelfTrapThickness), &selfTrapThickness, 1, 3);
	Tip(S_TipSelfTrapThickness);
	ImGui::SliderInt(TL(S_SelfTrapBpt), &selfTrapBlocksPerTick, 1, 10);
	Tip(S_TipSelfTrapBpt);
	ImGui::Checkbox(TL(S_SelfTrapNetherite), &selfTrapNetherite);
	Tip(S_TipSelfTrapNetherite);
	ImGui::Checkbox(TL(S_SelfTrapRoof), &selfTrapRoof);
	Tip(S_TipSelfTrapRoof);
	ImGui::Checkbox(TL(S_SelfTrapCorners), &selfTrapCorners);
	Tip(S_TipSelfTrapCorners);
	static const StrId slots[] = {S_AcSwNone, S_AcSwNormal, S_AcSwSilent, S_AcSwPacket};
	ComboT(TL(S_AcSwitch), &selfTrapSwitch, slots, IM_ARRAYSIZE(slots));
	ImGui::PopItemWidth();
}

// Ajustes de Surround (seccion Otros de Combate y panel del ClickGUI).
void DrawSurroundSettings(float width) {
	ImGui::PushID("surround");  // comparte etiquetas con SelfTrap en la misma pestaña
	ImGui::PushItemWidth(width);
	if (surround) MutedText(TF(S_SurroundStatus, SurroundStatusText()).c_str());
	ImGui::SliderInt(TL(S_SelfTrapBpt), &surroundBlocksPerTick, 1, 10);
	Tip(S_TipSelfTrapBpt);
	ImGui::SliderInt(TL(S_SurroundDelay), &surroundDelay, 0, 10);
	ImGui::Checkbox(TL(S_SurroundFloor), &surroundFloor);
	Tip(S_TipSurroundFloor);
	ImGui::Checkbox(TL(S_SurroundSupport), &surroundSupport);
	Tip(S_TipSurroundSupport);
	ImGui::Checkbox(TL(S_SurroundCorners), &surroundCorners);
	Tip(S_TipSurroundCorners);
	ImGui::Checkbox(TL(S_SurroundNetherite), &surroundNetherite);
	ImGui::Checkbox(TL(S_SurroundEatStop), &surroundEatStop);
	Tip(S_TipSurroundEatStop);
	ImGui::Checkbox(TL(S_SurroundJump), &surroundJumpDisable);
	ImGui::Checkbox(TL(S_SurroundCenter), &surroundCenter);
	Tip(S_TipSurroundCenter);
	ImGui::Checkbox(TL(S_SurroundCrystals), &surroundBreakCrystals);
	Tip(S_TipSurroundCrystals);
	ImGui::Checkbox(TL(S_AcRotate), &surroundRotate);
	static const StrId slots[] = {S_AcSwNone, S_AcSwNormal, S_AcSwSilent, S_AcSwPacket};
	ComboT(TL(S_AcSwitch), &surroundSwitch, slots, IM_ARRAYSIZE(slots));
	ImGui::Checkbox(TL(S_SurroundRender), &surroundRender);
	if (surroundRender) {
		ImGui::Checkbox(TL(S_SurroundFade), &surroundFade);
		ImGui::ColorEdit4(TL(S_SurroundFill), surroundFillColor, ImGuiColorEditFlags_NoInputs);
		ImGui::ColorEdit4(TL(S_SurroundLine), surroundLineColor, ImGuiColorEditFlags_NoInputs);
	}
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Ajustes de Platform (pagina Construccion y panel del ClickGUI).
void DrawPlatformSettings(float width) {
	ImGui::PushID("platform");
	ImGui::PushItemWidth(width);
	if (platform) MutedText(TF(S_SurroundStatus, PlatformStatusText()).c_str());
	ImGui::SliderInt(TL(S_PlatformRadius), &platformRadius, 0, 4);
	Tip(S_TipPlatformRadius);
	ImGui::SliderInt(TL(S_SelfTrapBpt), &platformBlocksPerTick, 1, 25);
	Tip(S_TipSelfTrapBpt);
	ImGui::SliderInt(TL(S_SurroundDelay), &platformDelay, 0, 20);
	ImGui::Checkbox(TL(S_PlatformSupport), &platformSupport);
	Tip(S_TipPlatformSupport);
	if (platformSupport) ImGui::SliderInt(TL(S_PlatformProximity), &platformProximity, 1, 6);
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Estilo del render compartido por PacketMine, AutoTrap, AutoAnchor, AutoBed y AutoCity.
static void DrawFxStyle() {
	ImGui::Checkbox(TL(S_FxSlide), &fxSlide);
	Tip(S_TipFxSlide);
	if (fxSlide) ImGui::SliderFloat(TL(S_FxSlideSpeed), &fxSlideSpeed, 1.0f, 30.0f, "%.0f");
	ImGui::Checkbox(TL(S_FxPulse), &fxPulse);
	Tip(S_TipFxPulse);
	ImGui::Checkbox(TL(S_FxShaded), &fxShaded);
	Tip(S_TipFxShaded);
	ImGui::Checkbox(TL(S_FxShockwave), &fxShockwave);
	Tip(S_TipFxShockwave);
	ImGui::Checkbox(TL(S_FxText), &fxText);
	Tip(S_TipFxText);
	if (fxText) ImGui::ColorEdit4(TL(S_FxTextColor), fxTextColor, ImGuiColorEditFlags_NoInputs);
}

// El mismo estilo plegado dentro de los ajustes de cada modulo.
static void DrawFxStyleNode() {
	if (ImGui::TreeNode(TL(S_FxStyle))) {
		DrawFxStyle();
		ImGui::TreePop();
	}
}

// Cambio de slot compartido por los modulos nuevos.
static void DrawSwitchCombo(int* value) {
	static const StrId slots[] = {S_AcSwNone, S_AcSwNormal, S_AcSwSilent, S_AcSwPacket};
	ComboT(TL(S_AcSwitch), value, slots, IM_ARRAYSIZE(slots));
}

// Ajustes de PacketMine (pagina Construccion y panel del ClickGUI).
void DrawPacketMineSettings(float width) {
	ImGui::PushID("packetmine");
	ImGui::PushItemWidth(width);
	if (packetMine) MutedText(TF(S_SurroundStatus, PacketMineStatusText()).c_str());
	static const StrId types[] = {S_PmTypeNormal, S_PmTypeContinue, S_PmTypeInstant, S_PmTypeRetry};
	ComboT(TL(S_PmType), &pmType, types, IM_ARRAYSIZE(types));
	Tip(S_TipPmType);
	ImGui::SliderFloat(TL(S_PmSpeed), &pmSpeed, 0.1f, 2.0f, "%.2f");
	Tip(S_TipPmSpeed);
	ImGui::SliderFloat(TL(S_PmRange), &pmRange, 1.0f, 12.0f, "%.1f");
	Tip(S_TipPmRange);
	ImGui::SliderInt(TL(S_PmDelay), &pmDelay, 0, 15);
	Tip(S_TipPmDelay);
	if (pmType == 1 || pmType == 3) {
		ImGui::SliderFloat(TL(S_PmContinueReset), &pmContinueReset, 0.0f, 1.0f, "%.2f");
		Tip(S_TipPmContinueReset);
	}
	if (pmType == 1) ImGui::SliderInt(TL(S_PmContinueDelay), &pmContinueDelay, 0, 10);
	ImGui::SliderInt(TL(S_PmRetryDelay), &pmRetryDelay, 1, 10);
	Tip(S_TipPmRetryDelay);
	static const StrId multitask[] = {S_PmMtNormal, S_PmMtStrict, S_PmMtNone};
	ComboT(TL(S_PmMultitask), &pmMultitask, multitask, IM_ARRAYSIZE(multitask));
	Tip(S_TipPmMultitask);
	DrawSwitchCombo(&pmSwitch);
	ImGui::Checkbox(TL(S_SurroundRender), &pmRender);
	if (pmRender) {
		ImGui::ColorEdit4(TL(S_PmColorStart), pmStartColor, ImGuiColorEditFlags_NoInputs);
		ImGui::SameLine();
		ImGui::ColorEdit4(TL(S_PmColorEnd), pmEndColor, ImGuiColorEditFlags_NoInputs);
		DrawFxStyleNode();
	}
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Ajustes de AutoTrap (seccion Otros de Combate y panel del ClickGUI).
void DrawAutoTrapSettings(float width) {
	ImGui::PushID("autotrap");
	ImGui::PushItemWidth(width);
	if (autoTrap) MutedText(TF(S_SurroundStatus, AutoTrapStatusText()).c_str());
	ImGui::SliderFloat(TL(S_AutoTrapRange), &autoTrapRange, 1.0f, 12.0f, "%.1f");
	ImGui::SliderInt(TL(S_AutoTrapTargets), &autoTrapTargets, 1, 5);
	Tip(S_TipAutoTrapTargets);
	ImGui::SliderInt(TL(S_SelfTrapHeight), &autoTrapHeight, 1, 4);
	Tip(S_TipAutoTrapHeight);
	ImGui::SliderInt(TL(S_SelfTrapBpt), &autoTrapBlocksPerTick, 1, 10);
	Tip(S_TipSelfTrapBpt);
	ImGui::SliderInt(TL(S_SurroundDelay), &autoTrapDelay, 0, 10);
	ImGui::Checkbox(TL(S_SelfTrapRoof), &autoTrapRoof);
	Tip(S_TipAutoTrapRoof);
	ImGui::Checkbox(TL(S_SurroundFloor), &autoTrapFloor);
	Tip(S_TipAutoTrapFloor);
	ImGui::Checkbox(TL(S_SelfTrapCorners), &autoTrapCorners);
	Tip(S_TipAutoTrapCorners);
	ImGui::Checkbox(TL(S_SurroundSupport), &autoTrapSupport);
	Tip(S_TipAutoTrapSupport);
	ImGui::Checkbox(TL(S_SelfTrapNetherite), &autoTrapNetherite);
	Tip(S_TipSelfTrapNetherite);
	ImGui::Checkbox(TL(S_SurroundEatStop), &autoTrapEatStop);
	Tip(S_TipSurroundEatStop);
	ImGui::Checkbox(TL(S_AcRotate), &autoTrapRotate);
	DrawSwitchCombo(&autoTrapSwitch);
	ImGui::Checkbox(TL(S_SurroundRender), &autoTrapRender);
	if (autoTrapRender) {
		ImGui::Checkbox(TL(S_SurroundFade), &autoTrapFade);
		ImGui::ColorEdit4(TL(S_SurroundFill), autoTrapFillColor, ImGuiColorEditFlags_NoInputs);
		ImGui::ColorEdit4(TL(S_SurroundLine), autoTrapLineColor, ImGuiColorEditFlags_NoInputs);
		DrawFxStyleNode();
	}
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Color compartido de AutoAnchor, AutoBed y AutoCity.
static void DrawBlastColors() {
	ImGui::ColorEdit4(TL(S_SurroundFill), blastFillColor, ImGuiColorEditFlags_NoInputs);
	ImGui::SameLine();
	ImGui::ColorEdit4(TL(S_SurroundLine), blastLineColor, ImGuiColorEditFlags_NoInputs);
}

// Lo que AutoAnchor y AutoBed comparten: rangos, danos, prioridad y retardo.
static void DrawBlastCommon(float* targetRange, float* placeRange, int* proximity, float* enemyDamage, float* selfDamage,
							int* priority, int* delay, int* switchMode, bool* eatStop) {
	ImGui::SliderFloat(TL(S_BlastTargetRange), targetRange, 1.0f, 24.0f, "%.1f");
	ImGui::SliderFloat(TL(S_BlastPlaceRange), placeRange, 1.0f, 8.0f, "%.1f");
	ImGui::SliderInt(TL(S_BlastProximity), proximity, 1, 5);
	Tip(S_TipBlastProximity);
	ImGui::SliderFloat(TL(S_BlastEnemyDamage), enemyDamage, 0.0f, 100.0f, "%.0f");
	Tip(S_TipBlastEnemyDamage);
	ImGui::SliderFloat(TL(S_BlastSelfDamage), selfDamage, 0.0f, 100.0f, "%.0f");
	Tip(S_TipBlastSelfDamage);
	static const StrId priorities[] = {S_BlastPriDamage, S_BlastPriDistance};
	ComboT(TL(S_BlastPriority), priority, priorities, IM_ARRAYSIZE(priorities));
	ImGui::SliderInt(TL(S_SurroundDelay), delay, 0, 10);
	DrawSwitchCombo(switchMode);
	ImGui::Checkbox(TL(S_SurroundEatStop), eatStop);
	Tip(S_TipSurroundEatStop);
}

// Ajustes de AutoAnchor (pestaña Explosivos de Combate y panel del ClickGUI).
void DrawAutoAnchorSettings(float width) {
	ImGui::PushID("autoanchor");
	ImGui::PushItemWidth(width);
	if (autoAnchor) MutedText(TF(S_SurroundStatus, AutoAnchorStatusText().c_str()).c_str());
	MutedText(T(S_TipAutoAnchor));
	DrawBlastCommon(&aaTargetRange, &aaPlaceRange, &aaProximity, &aaEnemyDamage, &aaSelfDamage, &aaPriority, &aaDelay, &aaSwitch, &aaEatStop);
	ImGui::Checkbox(TL(S_AcRotate), &aaRotate);
	ImGui::Checkbox(TL(S_SurroundRender), &aaRender);
	if (aaRender) {
		ImGui::Checkbox(TL(S_SurroundFade), &aaFade);
		DrawFxStyleNode();
	}
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Ajustes de AutoBed (pestaña Explosivos de Combate y panel del ClickGUI).
void DrawAutoBedSettings(float width) {
	ImGui::PushID("autobed");
	ImGui::PushItemWidth(width);
	if (autoBed) MutedText(TF(S_SurroundStatus, AutoBedStatusText().c_str()).c_str());
	MutedText(T(S_TipAutoBed));
	DrawBlastCommon(&abTargetRange, &abPlaceRange, &abProximity, &abEnemyDamage, &abSelfDamage, &abPriority, &abDelay, &abSwitch, &abEatStop);
	ImGui::Checkbox(TL(S_AcRotate), &abRotate);
	Tip(S_TipAbRotate);
	ImGui::Checkbox(TL(S_SurroundRender), &abRender);
	if (abRender) {
		ImGui::Checkbox(TL(S_SurroundFade), &abFade);
		DrawFxStyleNode();
	}
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Ajustes de AutoCity (pestaña Explosivos de Combate y panel del ClickGUI).
void DrawAutoCitySettings(float width) {
	ImGui::PushID("autocity");
	ImGui::PushItemWidth(width);
	if (autoCity) MutedText(TF(S_SurroundStatus, AutoCityStatusText().c_str()).c_str());
	ImGui::SliderFloat(TL(S_CtRange), &ctRange, 1.0f, 12.0f, "%.1f");
	ImGui::SliderFloat(TL(S_CtReach), &ctReach, 1.0f, 8.0f, "%.1f");
	Tip(S_TipCtReach);
	static const StrId modes[] = {S_CtModeAuto, S_CtModeCrystal, S_CtModeAnchor, S_CtModeBed};
	ComboT(TL(S_CtMode), &ctMode, modes, IM_ARRAYSIZE(modes));
	Tip(S_TipCtMode);
	ImGui::Checkbox(TL(S_CtEnclosed), &ctEnclosed);
	Tip(S_TipCtEnclosed);
	ImGui::Checkbox(TL(S_CtBurrow), &ctBurrow);
	Tip(S_TipCtBurrow);
	ImGui::SliderFloat(TL(S_BlastEnemyDamage), &ctEnemyDamage, 0.0f, 100.0f, "%.0f");
	Tip(S_TipBlastEnemyDamage);
	ImGui::SliderFloat(TL(S_BlastSelfDamage), &ctSelfDamage, 0.0f, 100.0f, "%.0f");
	Tip(S_TipBlastSelfDamage);
	if (ctMode == 0 || ctMode == 1) {
		ImGui::SliderInt(TL(S_CtPlaceAt), &ctPlaceAt, 0, 100);
		Tip(S_TipCtPlaceAt);
		ImGui::Checkbox(TL(S_CtHit), &ctHit);
		Tip(S_TipCtHit);
	}
	DrawSwitchCombo(&ctSwitch);
	ImGui::Checkbox(TL(S_SurroundEatStop), &ctEatStop);
	Tip(S_TipSurroundEatStop);
	ImGui::Checkbox(TL(S_SurroundRender), &ctRender);
	if (ctRender) DrawFxStyleNode();
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Pestaña Explosivos de Combate: AutoAnchor, AutoBed y AutoCity con el color compartido.
void DrawBlastTab() {
	float w = UiUnit() * 300;
	// mismo separador que PageSeparator (menu.h, que se incluye despues)
	auto separator = []() {
		ImGui::Dummy(ImVec2(0.0f, 4.0f * scaleGlobal));
		ImGui::Separator();
		ImGui::Dummy(ImVec2(0.0f, 2.0f * scaleGlobal));
	};
	ModToggle(MOD_autoAnchor);
	if (autoAnchor) DrawAutoAnchorSettings(w);
	separator();
	ModToggle(MOD_autoBed);
	if (autoBed) DrawAutoBedSettings(w);
	separator();
	ModToggle(MOD_autoCity);
	if (autoCity) DrawAutoCitySettings(w);
	separator();
	MutedText(T(S_BlastColors));
	DrawBlastColors();
	separator();
	MutedText(T(S_FxStyle));
	ImGui::PushID("fxstyle");
	DrawFxStyle();
	ImGui::PopID();
}

// Ajustes de CrystalChams (pagina Visuals y panel del ClickGUI).
void DrawCrystalChamsSettings(float width) {
	ImGui::PushItemWidth(width);
	ImGui::SliderFloat(TL(S_ChamsRotateSpeed), &crystalChamsRotateSpeed, 0.0f, 10.0f, "%.2f");
	ImGui::SliderFloat(TL(S_ChamsBobSpeed), &crystalChamsBobSpeed, 0.0f, 10.0f, "%.2f");
	ImGui::SliderFloat(TL(S_ChamsBobAmount), &crystalChamsBobAmount, 0.0f, 1.0f, "%.2f");
	ImGui::SliderFloat(TL(S_ChamsScale), &crystalChamsScale, 0.1f, 3.0f, "%.2f");
	ImGui::Checkbox(TL(S_ChamsFancy), &crystalChamsFancy);
	ImGui::Checkbox(TL(S_ChamsFade), &crystalChamsFade);
	ImGui::SliderInt(TL(S_ChamsFadeDuration), &crystalChamsFadeDuration, 1, 40);
	ImGui::ColorEdit4(TL(S_ChamsFillColor), crystalChamsFillColor, ImGuiColorEditFlags_NoInputs);
	ImGui::ColorEdit4(TL(S_ChamsLineColor), crystalChamsLineColor, ImGuiColorEditFlags_NoInputs);
	ImGui::PopItemWidth();
}

// Pestañas "AutoCrystal" y "AutoCrystalX" de Combate. El placer y el helper
// viven en la seccion Otros; el AntiCrystal y el CrystalChams acompanan a sus
// ajustes en sus paginas.
void DrawAutoCrystalTab() {
	ModToggle(MOD_autoCrystal);
	DrawAutoCrystalSettings(UiUnit() * 300);
}

void DrawAutoCrystalXTab() {
	ModToggle(MOD_autoCrystalX);
	DrawAutoCrystalXSettings(UiUnit() * 300);
}

// Ajustes de Offhand (pestaña Otros de Combate y fila del ClickGUI).
void DrawOffhandSettings(float width) {
	static const StrId items[] = {S_OffhandTotem, S_OffhandShield};
	ImGui::PushItemWidth(width);
	if (!offhandSmart) ComboT(TL(S_OffhandItem), &offhandItem, items, IM_ARRAYSIZE(items));
	ImGui::SliderInt(TL(S_OffhandDelay), &offhandDelay, 0, 20);
	ModToggle(MOD_offhandSmart);
	if (offhandSmart) {
		ImGui::SliderFloat(TL(S_OffhandSwapTotem), &offhandSwapTotem, 0.0f, 20.0f, "%.0f");
		Tip(S_TipOffhandSwapTotem);
		ImGui::SliderFloat(TL(S_OffhandSwapShield), &offhandSwapShield, 0.0f, 20.0f, "%.0f");
		Tip(S_TipOffhandSwapShield);
		ModToggle(MOD_offhandSurroundOnly);
	}
	ImGui::PopItemWidth();
}

// Pestaña "Vuelo" de Movimiento: Fly y BypassFly de GatoClient.
void DrawFlyTab() {
	float u = UiUnit();
	SectionTitle(S_SectionFly);
	MutedText(T(S_TipFlyControls));
	ModToggle(MOD_gatoFly);
	ImGui::SameLine();
	ModToggle(MOD_bypassFly);
	ModToggle(MOD_flyLookControl);
	ImGui::PushItemWidth(u * 300);
	if (gatoFly) {
		SectionTitle(S_SectionGatoFly);
		ImGui::SliderFloat(TL(S_FlyHSpeed), &flyHSpeed, 0.2f, 3.0f, "%.2f");
		ImGui::SliderFloat(TL(S_FlyVSpeed), &flyVSpeed, 0.2f, 3.0f, "%.2f");
		ModToggle(MOD_flyAntiKick);
		ImGui::SameLine();
		ModToggle(MOD_flyDynamic);
		if (flyAntiKick) {
			ImGui::SliderFloat(TL(S_FlyKickInterval), &flyKickInterval, 0.5f, 3.0f, "%.2f");
			ImGui::SliderFloat(TL(S_FlyKickAmount), &flyKickAmount, 0.01f, 0.3f, "%.2f");
		} else {
			ImGui::SliderFloat(TL(S_FlyGlide), &flyGlide, -0.15f, 0.0f, "%.3f");
		}
		if (flyDynamic) {
			ImGui::SliderFloat(TL(S_FlyHDynamic), &flyHDynamic, 0.5f, 2.0f, "%.2f");
			ImGui::SliderFloat(TL(S_FlyVDynamic), &flyVDynamic, 0.5f, 2.0f, "%.2f");
		}
	}
	if (bypassFly) {
		SectionTitle(S_SectionBypassFly);
		MutedText(T(S_TipBfBlend));
		ImGui::SliderFloat(TL(S_BfInitialH), &bfInitialH, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfInitialV), &bfInitialV, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfInitBypH), &bfInitBypH, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfInitBypV), &bfInitBypV, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfFinalH), &bfFinalH, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfFinalV), &bfFinalV, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfFinalBypH), &bfFinalBypH, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfFinalBypV), &bfFinalBypV, 0.1f, 3.0f, "%.4f");
		ImGui::SliderFloat(TL(S_FlyGlide), &bfGlide, -0.2f, 0.2f, "%.4f");
		ImGui::SliderFloat(TL(S_BfReleaseDelay), &bfReleaseDelay, 0.0f, 0.5f, "%.2f");
		ImGui::SliderFloat(TL(S_BfDescentSpeed), &bfDescentSpeed, 0.1f, 5.0f, "%.4f");
		ImGui::SliderFloat(TL(S_BfDescentHorizontal), &bfDescentHorizontal, 0.0f, 3.0f, "%.2f");
		ImGui::SliderFloat(TL(S_BfOnlyShift), &bfOnlyShift, 0.0f, 5.0f, "%.2f");
	}
	ImGui::PopItemWidth();
}

void DrawVisualHudSettings(float u);  // visuals_gatyo.h

void DrawHudPage() {
	float u = UiUnit();
	SectionTitle(S_SectionEditor);
	if (AccentButton(TL(S_OpenHudEditor))) g_hudEditor = true;
	Tip(S_TipHudEditor);
	ImGui::SameLine();
	if (ImGui::Button(TL(S_ResetPositions))) {
		HudResetPositions();
		Notify(T(S_NotifyPositionsReset), NOTIFY_INFO);
	}

	SectionTitle(S_SectionWatermark);
	ImGui::PushItemWidth(u * 260);
	ModToggle(MOD_watermark);
	if (watermark) {
		ImGui::SameLine();
		static const StrId styles[] = {S_StyleCompact, S_StyleExtended, S_StyleText};
		ComboT(TL(S_WatermarkStyle), &watermarkStyle, styles, IM_ARRAYSIZE(styles));
		ModToggle(MOD_watermarkFps);
		ImGui::SameLine();
		ModToggle(MOD_watermarkTps);
		ModToggle(MOD_watermarkCoords);
		ImGui::SameLine();
		ModToggle(MOD_watermarkVersion);
	}
	ImGui::PopItemWidth();

	SectionTitle(S_SectionCoords);
	ModToggle(MOD_showPosition);
	ImGui::SameLine();
	ModToggle(MOD_hudCoordsDecimals);

	SectionTitle(S_SectionNear);
	ModToggle(MOD_playerNear);

	SectionTitle(S_SectionFps);
	ImGui::PushItemWidth(u * 260);
	ModToggle(MOD_hudFpsGraph);
	if (hudFpsGraph) {
		ImGui::SameLine();
		ImGui::SliderInt(TL(S_FpsWindow), &hudFpsGraphSeconds, 5, 30, "%d s");
	}
	ImGui::PopItemWidth();

	SectionTitle(S_SectionArrayList);
	ModToggle(MOD_hudArrayList);

	DrawVisualHudSettings(u);
}

// Pestaña "Paleta" de Visuales: color compartido por los modulos visuales.
void DrawPaletteTab() {
	float u = UiUnit();
	ImGui::PushItemWidth(u * 300);
	static const StrId modes[] = {S_PaletteStatic, S_PaletteFlow, S_PaletteRgb};
	ComboT(TL(S_PaletteMode), &visualColorMode, modes, IM_ARRAYSIZE(modes));
	Tip(S_TipPalette);
	if (visualColorMode == 1) {
		ColorEditT(S_FlowColorA, flowColorA);
		ImGui::SameLine();
		ColorEditT(S_FlowColorB, flowColorB);
	}
	if (visualColorMode != 0) ImGui::SliderFloat(TL(S_FlowSpeed), &flowSpeed, 0.0f, 5.0f, "%.2f");
	ImGui::PopItemWidth();

	// muestra del color en vivo
	ImGui::Dummy(ImVec2(0, 4.0f * scaleGlobal));
	MutedText(T(S_PalettePreview));
	ImVec2 min = ImGui::GetCursorScreenPos();
	float width = ImGui::GetContentRegionAvail().x;
	float height = ImGui::GetFrameHeight();
	ImDrawList* dl = ImGui::GetWindowDrawList();
	int start = dl->VtxBuffer.Size;
	int slices = 48;
	for (int i = 0; i < slices; i++) {
		float x0 = min.x + width * i / slices;
		float x1 = min.x + width * (i + 1) / slices;
		dl->AddRectFilled(ImVec2(x0, min.y), ImVec2(x1, min.y + height), GatyoU32(ImVec4(1, 1, 1, 1)));
	}
	GatyoShadeVerts(dl, start, dl->VtxBuffer.Size, true);
	ImGui::Dummy(ImVec2(width, height));
}

void DrawConfigPage() {
	GatyoPalette p = GatyoGetPalette();
	float u = UiUnit();
	static std::string profileName;
	if (g_profilesDirty) RefreshProfiles();

	SectionTitle(S_SectionProfiles);
	// campo de nombre: abre el teclado de Android
	float fieldWidth = u * 360;
	ImVec2 pos = ImGui::GetCursorScreenPos();
	float height = ImGui::GetFrameHeight();
	if (ImGui::InvisibleButton("##profile_name", ImVec2(fieldWidth, height))) RequestTextInput(T(S_ProfileName), &profileName);
	ImDrawList* dl = ImGui::GetWindowDrawList();
	dl->AddRectFilled(pos, ImVec2(pos.x + fieldWidth, pos.y + height), GatyoU32(ImGui::IsItemHovered() ? p.hover : GatyoAlpha(p.panel, 0.85f)));
	dl->AddRect(pos, ImVec2(pos.x + fieldWidth, pos.y + height), GatyoU32(GatyoAlpha(p.border, 0.9f)));
	dl->PushClipRect(pos, ImVec2(pos.x + fieldWidth, pos.y + height), true);
	dl->AddText(ImVec2(pos.x + ImGui::GetStyle().FramePadding.x, pos.y + ImGui::GetStyle().FramePadding.y),
	            GatyoU32(profileName.empty() ? p.muted : p.text), profileName.empty() ? T(S_ProfileNameHint) : profileName.c_str());
	dl->PopClipRect();
	ImGui::SameLine();
	if (AccentButton(TL(S_Save))) SaveProfile(profileName);

	if (g_profiles.empty()) {
		MutedText(T(S_NoProfiles));
	} else {
		ImGui::BeginChild("##profiles", ImVec2(0, ImMin((float)g_profiles.size(), 4.0f) * (ImGui::GetFrameHeightWithSpacing() + 2.0f) + ImGui::GetStyle().WindowPadding.y * 2.0f), true);
		for (const std::string& name : g_profiles) {
			ImGui::PushID(name.c_str());
			ImGui::AlignTextToFramePadding();
			ImGui::TextUnformatted(name.c_str());
			float buttons = ImGui::CalcTextSize(T(S_Load)).x + ImGui::CalcTextSize(T(S_Delete)).x + ImGui::GetStyle().FramePadding.x * 4.0f + ImGui::GetStyle().ItemSpacing.x;
			ImGui::SameLine(ImMax(ImGui::GetCursorPosX(), ImGui::GetWindowContentRegionMax().x - buttons));
			if (ImGui::Button(TL(S_Load))) {
				LoadProfile(name);
				profileName = name;
			}
			ImGui::SameLine();
			if (ImGui::Button(TL(S_Delete))) {
				g_confirmProfile = name;
				ConfirmRequest(CONFIRM_DELETE_PROFILE, TF(S_ConfirmDelete, name.c_str()));
			}
			ImGui::PopID();
		}
		ImGui::EndChild();
	}
	MutedText(TF(S_FolderPath, ProfilesDir().c_str()).c_str());

	SectionTitle(S_SectionFile);
	std::string filePath = GatyoDir() + "/Gatyo.json";
	if (ImGui::Button(TL(S_Export))) {
		EnsureGatyoDirs();
		saveConfig(filePath);
		bool ok = FileExists(filePath);
		(ok ? onFunctionSound : errorFunctionSound) = true;
		Notify(ok ? T(S_NotifyConfigSaved) : T(S_NotifyProfileError), ok ? NOTIFY_ON : NOTIFY_ERROR);
	}
	ImGui::SameLine();
	if (ImGui::Button(TL(S_Import))) {
		bool ok = FileExists(filePath) && LoadConfigKeepingLanguage(filePath);
		(ok ? onFunctionSound : errorFunctionSound) = true;
		Notify(ok ? T(S_NotifyConfigLoaded) : T(S_NotifyConfigMissing), ok ? NOTIFY_ON : NOTIFY_ERROR);
	}
	MutedText(filePath.c_str());

	SectionTitle(S_SectionReset);
	static int resetPage = PAGE_MOVEMENT;
	StrId sections[PAGE_COUNT];
	int pages[PAGE_COUNT];
	int count = 0, selected = 0;
	for (int page = 0; page < PAGE_COUNT; page++) {
		if (!GetSectionKeys(page).keys) continue;
		if (page == resetPage) selected = count;
		sections[count] = kPageNames[page];
		pages[count++] = page;
	}
	ImGui::PushItemWidth(u * 300);
	ComboT(TL(S_ResetWhich), &selected, sections, count);
	resetPage = pages[selected];
	ImGui::PopItemWidth();
	ImGui::SameLine();
	if (ImGui::Button(TL(S_ResetSection))) RequestResetSection(resetPage);
	ImGui::PushStyleColor(ImGuiCol_Button, GatyoAlpha(GatyoState::Danger, 0.55f));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, GatyoAlpha(GatyoState::Danger, 0.8f));
	if (ImGui::Button(TL(S_ResetAll))) ConfirmRequest(CONFIRM_RESET_ALL, T(S_ResetConfirmAll));
	ImGui::PopStyleColor(2);
}

void DrawInfoPage() {
	GatyoPalette p = GatyoGetPalette();
	ImDrawList* dl = ImGui::GetWindowDrawList();
	float brandSize = ImGui::GetFontSize() * 2.4f;
	ImVec2 pos = ImGui::GetCursorScreenPos();
	GatyoFlowText(dl, pos, "gatyo", brandSize);
	ImGui::Dummy(ImVec2(0, brandSize + 4.0f * scaleGlobal));

	auto row = [&](StrId label, const char* value) {
		ImGui::PushStyleColor(ImGuiCol_Text, p.muted);
		ImGui::TextUnformatted(T(label));
		ImGui::PopStyleColor();
		ImGui::SameLine(UiUnit() * 220);
		ImGui::TextUnformatted(value);
	};
	char build[64];
	snprintf(build, sizeof(build), "%d (%s)", GATYO_BUILD, GATYO_BUILD_DATE);
	row(S_InfoVersion, GATYO_VERSION);
	row(S_InfoBuild, build);
	row(S_InfoGame, "Minecraft Bedrock 1.21.111");
	row(S_InfoArch, kArchName);
	ImGui::Separator();
	ImGui::PushTextWrapPos(0.0f);
	ImGui::TextUnformatted(T(S_IntroBody));
	ImGui::PopTextWrapPos();
	ImGui::Dummy(ImVec2(0, 4.0f * scaleGlobal));
	if (ImGui::Button(TL(S_InfoShowIntro))) readMe = false;
	ImGui::Separator();
	MutedText(T(S_Credits));
}

// Ventana de presentacion (la primera vez, o desde Informacion).
void DrawIntroWindow(ImVec2 center) {
	GatyoPalette p = GatyoGetPalette();
	ImVec2 size(ImMin(screenWidth / 2.0f * uiScale, screenWidth * 0.95f), ImMin(screenHeight / 1.25f * uiScale, screenHeight * 0.95f));
	ImGui::SetNextWindowPos(center, ImGuiCond_Always, ImVec2(0.5f, 0.5f));
	ImGui::SetNextWindowSize(size, ImGuiCond_Always);
	if (ImGui::Begin("Gatyo###GatyoIntro", NULL, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove)) {
		g_window = ImGui::GetCurrentWindow();
		DrawMenuBackground();
		DrawLanguageButtons();
		ImGui::Dummy(ImVec2(0, 6.0f * scaleGlobal));

		ImDrawList* dl = ImGui::GetWindowDrawList();
		float brandSize = ImGui::GetFontSize() * 2.6f;
		GatyoFlowText(dl, ImGui::GetCursorScreenPos(), "gatyo", brandSize);
		ImGui::Dummy(ImVec2(0, brandSize));
		ImGui::SetWindowFontScale(1.25f);
		ImGui::TextUnformatted(T(S_IntroTitle));
		ImGui::SetWindowFontScale(1.0f);
		ImGui::PushTextWrapPos(0.0f);
		ImGui::TextUnformatted(T(S_IntroBody));
		ImGui::PopTextWrapPos();

		SectionTitle(S_IntroNewTitle);
		static const StrId news[] = {S_IntroNew1, S_IntroNew2, S_IntroNew3, S_IntroNew4, S_IntroNew5};
		for (StrId item : news) {
			ImVec2 bullet = ImGui::GetCursorScreenPos();
			float s = ImGui::GetFontSize() * 0.3f;
			float cy = bullet.y + ImGui::GetTextLineHeight() * 0.5f;
			dl->AddRectFilled(ImVec2(bullet.x, cy - s * 0.5f), ImVec2(bullet.x + s, cy + s * 0.5f), GatyoU32(p.accent));
			ImGui::Indent(s * 3.0f);
			ImGui::PushTextWrapPos(0.0f);
			ImGui::TextUnformatted(T(item));
			ImGui::PopTextWrapPos();
			ImGui::Unindent(s * 3.0f);
		}
		ImGui::Separator();
		MutedText(T(S_Credits));
		ImGui::Dummy(ImVec2(0, 6.0f * scaleGlobal));
		GatyoSwitch(TL(S_DontShowAgain), &uiSkipIntro);
		ImGui::SameLine();
		if (AccentButton(TL(S_GotIt))) readMe = true;
	}
	ImGui::End();
}
