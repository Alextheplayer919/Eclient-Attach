// Exporta los minidumps de Breakpad (el handler de crash de Bedrock) a
// almacenamiento externo, para analizar los crashes fuera del directorio
// privado de la app cuando el juego muere con SIGSEGV sin dejar tombstone.
#pragma once

#include <dlfcn.h>
#include <dirent.h>
#include <stdarg.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <android/log.h>

// destino legible desde adb: /sdcard/Android/data/com.mojang.minecraftpe/files/games/com.mojang/crashdumps
#define CRASHDUMP_DST "/sdcard/Android/data/com.mojang.minecraftpe/files/games/com.mojang/crashdumps"
#define CRASHDUMP_SRC "/data/user/0/com.mojang.minecraftpe/crash/"

typedef int (*LogVPrint_t)(int prio, const char* tag, const char* fmt, va_list ap);
static LogVPrint_t old_log_vprint = nullptr;

// fork + exec sh cp: async-signal-safe elementar. El hijo sobrevive aunque
// el juego muera justo despues (fork del contexto de señal).
// cp conserva los modos del origen (0600): chmod para que adb pueda leerlo.
static void CrashCopyDump(const char* path) {
    if (!path || path[0] != '/') return;
    pid_t p = fork();
    if (p == 0) {
        char cmd[1024];
        snprintf(cmd, sizeof(cmd), "cp -f '%s' " CRASHDUMP_DST "/ 2>/dev/null; chmod 0664 " CRASHDUMP_DST "/*.dmp 2>/dev/null", path);
        execlp("sh", "sh", "-c", cmd, (char*)nullptr);
        _exit(127);
    }
    // no reaping: si el padre muere el hijo termina solo
}

// extrae la ruta del minidump de una linea "…dump path: /data/.../xxx.dmp"
static void CrashScanDumpLine(const char* text) {
    if (!text) return;
    const char* p = strstr(text, "dump path:");
    if (!p) return;
    p += 10;
    while (*p == ' ') ++p;
    char path[512];
    size_t n = 0;
    while (p[n] && p[n] != ' ' && p[n] != '\n' && p[n] != '\r' && n < sizeof(path) - 1) ++n;
    path[n] = 0;
    if (n > 4 && !strcmp(path + n - 4, ".dmp")) CrashCopyDump(path);
}

static int new_log_vprint(int prio, const char* tag, const char* fmt, va_list ap) {
    if (old_log_vprint && fmt && strstr(fmt, "dump path")) {
        // el .dmp viene sustituido por %s: hay que formatear para extraerlo
        va_list c;
        va_copy(c, ap);
        char buf[1024];
        vsnprintf(buf, sizeof(buf), fmt, c);
        va_end(c);
        CrashScanDumpLine(buf);
    }
    return old_log_vprint(prio, tag, fmt, ap);
}

typedef int (*LogWrite_t)(int prio, const char* tag, const char* msg);
static LogWrite_t old_log_write = nullptr;
static int new_log_write(int prio, const char* tag, const char* msg) {
    if (msg && strstr(msg, "dump path")) CrashScanDumpLine(msg);
    return old_log_write ? old_log_write(prio, tag, msg) : 0;
}

// copia los .dmp que ya existan (de un crash anterior) al arranque
static void CrashCopyExisting() {
    mkdir(CRASHDUMP_DST, 0755);
    DIR* d = opendir(CRASHDUMP_SRC);
    if (!d) return;
    dirent* e;
    while ((e = readdir(d)) != nullptr) {
        size_t l = strlen(e->d_name);
        if (l > 4 && !strcmp(e->d_name + l - 4, ".dmp")) {
            char src[512];
            snprintf(src, sizeof(src), CRASHDUMP_SRC "%s", e->d_name);
            // fuera de señal: fork/sh normal
            CrashCopyDump(src);
        }
    }
    closedir(d);
}

static void CrashDumpInit() {
    void* vprint = dlsym(RTLD_DEFAULT, "__android_log_vprint");
    if (vprint && !old_log_vprint) {
        DobbyHook(vprint, (void*)new_log_vprint, (void**)&old_log_vprint);
    }
    void* wprint = dlsym(RTLD_DEFAULT, "__android_log_write");
    if (wprint && !old_log_write) {
        DobbyHook(wprint, (void*)new_log_write, (void**)&old_log_write);
    }
    CrashCopyExisting();
}
