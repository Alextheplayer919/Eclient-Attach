#pragma once
// AutoBed: pone camas junto al rival y las hace explotar. Portado del BedAura
// de GatoClient con las rutas de la suite.
//
//   - Solo explotan en el Nether y el End (en el Overworld la cama fija el
//     spawn): la dimension sale de la vtable del Dimension del BlockSource.
//   - Una cama son dos celdas: el pie (donde se hace clic) y la cabeza, que va
//     hacia donde mira el jugador. Las dos tienen que ser de aire, con un
//     bloque macizo debajo y libres de entidades. El pie se apoya en un vecino
//     que no reaccione al clic (nada de cofres ni mesas).
//   - Orientacion (ExRunBed): el servidor usa el yaw del ultimo paquete de
//     movimiento que proceso, y el paquete de un tick sale DESPUES de la
//     colocacion de ese tick. Por eso, con Rotacion, el modulo primero apunta
//     el yaw (spoof del PlayerAuthInputPacket) y coloca al tick siguiente, ya
//     con el yaw entregado. Sin Rotacion coloca de inmediato y la cabeza queda
//     donde caiga.
//   - Dano de la explosion (potencia 5, radio 10) en el pie y en la cabeza: al
//     rival se le cuenta el menor de los dos y a ti el mayor, para no
//     equivocarse con el centro exacto.
//   - Colocar -> explotar en el mismo tick si el cliente ya ve la cama; si no,
//     se retoma al tick siguiente con la cama "viva". Las camas que ya estan
//     junto al rival tambien son candidatas: se explotan antes de poner otra.
//   - Render: la cama se dibuja plana y orientada, con la almohada en la
//     cabeza, desliza entre posiciones y muestra el dano; al explotar deja una
//     onda.

enum AutoBedStatus {
	AB_ST_IDLE, AB_ST_NO_TARGET, AB_ST_OVERWORLD, AB_ST_NO_BED, AB_ST_NO_SPOT, AB_ST_LOW_DAMAGE,
	AB_ST_SELF_DAMAGE, AB_ST_WORKING, AB_ST_AIMING, AB_ST_PAUSED, AB_ST_NO_SWITCH,
};
static std::atomic<int> g_abStatus{AB_ST_IDLE};
static std::atomic<int> g_abStatLow{0}, g_abStatSelf{0};

static std::string AutoBedStatusText() {
	switch (g_abStatus.load()) {
		case AB_ST_NO_TARGET: return T(S_AcxStNoTarget);
		case AB_ST_OVERWORLD: return T(S_AbStOverworld);
		case AB_ST_NO_BED: return T(S_AbStNoBed);
		case AB_ST_NO_SPOT: return T(S_AbStNoSpot);
		case AB_ST_LOW_DAMAGE: return TF(S_AcxStLowDamage, g_abStatLow.load(), abEnemyDamage);
		case AB_ST_SELF_DAMAGE: return TF(S_AaStSelfDamage, g_abStatSelf.load(), abSelfDamage);
		case AB_ST_WORKING: return T(S_AaStWorking);
		case AB_ST_AIMING: return T(S_AbStAiming);
		case AB_ST_PAUSED: return T(S_AcxStPaused);
		case AB_ST_NO_SWITCH: return T(S_AcxStNoSwitch);
	}
	return T(S_AcxStOff);
}

static ExOverlay g_abOverlay;

#if defined(__aarch64__)

static const int kAbRetryTicks = 4;
static const int kAbLiveTicks = 60;
static bool g_abWas = false;
static uint32_t g_abLastAct = 0;
static AcRetryRing g_abRetry;
static ExBedJob g_abJob;
static ExBedAim g_abAim;
// Ultimo plan elegido (para no saltar entre direcciones de un tick a otro).
static vec3_ti g_abPlanFoot{0, 0, 0};
static float g_abPlanYaw = 0.0f;
static uint32_t g_abPlanTick = 0;

static void AbReset() {
	g_abWas = false;
	g_abLastAct = 0;
	g_abRetry.Clear();
	g_abJob = ExBedJob();
	g_abAim = ExBedAim();
	g_abPlanTick = 0;
	ExPublish(g_abOverlay, {});
}

// Las cuatro direcciones de la cabeza y el yaw que la produce (el mismo mapa del
// original: +x -> -90, -x -> 90, +z -> 0, -z -> 180).
struct AbDir {
	int dx, dz;
	float yaw;
};
static const AbDir kAbDirs[4] = {{1, 0, -90.0f}, {-1, 0, 90.0f}, {0, 1, 0.0f}, {0, -1, 180.0f}};

// Marca de una cama (pie + cabeza) para el render.
static ExMark AbBedMark(const vec3_ti& foot, const vec3_ti& head, float enemy, float self) {
	ExMark m = ExMarkCell(foot, EXM_BED, 1);
	m.hx = (int8_t)ImClamp(head.x - foot.x, -1, 1);
	m.hz = (int8_t)ImClamp(head.z - foot.z, -1, 1);
	m.enemy = enemy;
	m.self = self;
	snprintf(m.label, sizeof(m.label), "BED");
	return m;
}

static void AutoBedOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!autoBed) {
		if (g_abWas) AbReset();
		g_abWas = false;
		g_abStatus = AB_ST_IDLE;
		return;
	}
	g_abWas = true;
	AcAdvanceTick();
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	if (!ExBedExplodes(ExDimensionOf(region))) {
		g_abStatus = AB_ST_OVERWORLD;
		ExPublish(g_abOverlay, {});
		return;
	}

	// la cama viva que ya no existe: si se le hizo clic, exploto
	if (g_abJob.valid) {
		bool expired = AcTicksSince(g_abJob.tick) > kAbLiveTicks;
		bool gone = AcTicksSince(g_abJob.tick) > 2 && !ExIsBedBlock(AcBlockAt(region, g_abJob.foot)) && !ExIsBedBlock(AcBlockAt(region, g_abJob.head));
		if (gone && g_abJob.detonatedAt) {
			glm::vec3 c = (ExCenterOf(g_abJob.foot) + ExCenterOf(g_abJob.head)) * 0.5f;
			ExPushBurst(c.x, c.y, c.z, blastLineColor, 1.0f);
		}
		if (expired || gone) g_abJob = ExBedJob();
	}

	if (abEatStop && AcEatingActive(lp)) {
		g_abStatus = AB_ST_PAUSED;
		return;
	}
	if (g_abLastAct && AcTicksSince(g_abLastAct) < abDelay) return;

	AcEntity me = AcSelfEntity(lp);
	bool selfImmune = !lp->isAttackableGamemode();
	const GaxV3 eye = GaxPos(lp);
	std::vector<AcEntity> targets = AcCollectTargets(lp, level, abTargetRange, false);
	std::sort(targets.begin(), targets.end(), [](const AcEntity& a, const AcEntity& b) { return a.dist < b.dist; });
	if (targets.size() > 4) targets.resize(4);
	if (targets.empty()) {
		g_abStatus = AB_ST_NO_TARGET;
		ExPublish(g_abOverlay, {});
		return;
	}

	// Dano por celda en cache: muchas camas comparten celdas.
	std::unordered_map<uint64_t, float> enemyCache, selfCache;
	auto enemyAt = [&](const vec3_ti& cell) {
		uint64_t k = AcPackCell(cell.x, cell.y, cell.z);
		auto it = enemyCache.find(k);
		if (it != enemyCache.end()) return it->second;
		float best = 0.0f;
		for (const AcEntity& t : targets) best = ImMax(best, ExDamageTo(t, region, ExCenterOf(cell), nullptr));
		enemyCache[k] = best;
		return best;
	};
	auto selfAt = [&](const vec3_ti& cell) {
		if (selfImmune) return 0.0f;
		uint64_t k = AcPackCell(cell.x, cell.y, cell.z);
		auto it = selfCache.find(k);
		if (it != selfCache.end()) return it->second;
		float d = ExDamageTo(me, region, ExCenterOf(cell), nullptr);
		selfCache[k] = d;
		return d;
	};
	auto bedEnemy = [&](const vec3_ti& foot, const vec3_ti& head) { return ImMin(enemyAt(foot), enemyAt(head)); };
	auto bedSelf = [&](const vec3_ti& foot, const vec3_ti& head) { return ImMax(selfAt(foot), selfAt(head)); };
	auto selfSafe = [&](float d) { return selfImmune || (d <= abSelfDamage && d < (float)lp->getHealth()); };

	// ---- el plan: la cama viva primero, si no el mejor candidato --------------
	vec3_ti planFoot{0, 0, 0}, planHead{0, 0, 0}, planClicked{0, 0, 0};
	unsigned char planFace = 0;
	float planYaw = 0.0f, planEnemy = 0.0f, planSelf = 0.0f;
	bool havePlan = false;
	int statLow = 0, statSelf = 0;

	if (g_abJob.valid) {
		bool footBed = ExIsBedBlock(AcBlockAt(region, g_abJob.foot));
		bool headBed = ExIsBedBlock(AcBlockAt(region, g_abJob.head));
		if (footBed || headBed) {
			float enemy = bedEnemy(g_abJob.foot, g_abJob.head), self = bedSelf(g_abJob.foot, g_abJob.head);
			if (enemy >= abEnemyDamage * 0.5f && selfSafe(self)) {
				planFoot = g_abJob.foot;
				planHead = g_abJob.head;
				planEnemy = enemy;
				planSelf = self;
				havePlan = true;
			}
		}
	}

	if (!havePlan) {
		int span = ImClamp(abProximity, 1, 5);
		float minX = 1e9f, minY = 1e9f, minZ = 1e9f, maxX = -1e9f, maxY = -1e9f, maxZ = -1e9f;
		for (const AcEntity& t : targets) {
			minX = ImMin(minX, t.box.lower.x); maxX = ImMax(maxX, t.box.upper.x);
			minY = ImMin(minY, t.box.lower.y); maxY = ImMax(maxY, t.box.upper.y);
			minZ = ImMin(minZ, t.box.lower.z); maxZ = ImMax(maxZ, t.box.upper.z);
		}
		StCollectBlockers(level, minX - span - 2, minY - 2, minZ - span - 2, maxX + span + 2, maxY + 4, maxZ + span + 2);

		float bestScore = -1e9f;
		int checked = 0;
		for (const AcEntity& t : targets) {
			ExFootprint f = ExFootprintOf(t.box);
			for (int dx = -span; dx <= span && checked < 160; dx++) {
				for (int dz = -span; dz <= span && checked < 160; dz++) {
					for (int dy = -1; dy <= 1 && checked < 160; dy++) {
						vec3_ti foot{f.x0 + dx, f.feetY + dy, f.z0 + dz};
						if (ExDistToBlock(eye, foot) > abPlaceRange) continue;
						Block* fb = AcBlockAt(region, foot);
						// una cama que ya esta junto al rival: se explota antes de poner otra
						if (ExIsBedBlock(fb)) {
							checked++;
							float enemy = enemyAt(foot);
							if (enemy < abEnemyDamage) { statLow++; continue; }
							float self = selfAt(foot);
							if (!selfSafe(self)) { statSelf++; continue; }
							float score = (abPriority == 0 ? enemy - 0.5f * self : 0.0f) + 3.0f;
							if (score > bestScore) {
								bestScore = score;
								planFoot = planHead = foot;
								planEnemy = enemy;
								planSelf = self;
								havePlan = true;
							}
							continue;
						}
						if (!AcIsAir(fb) || !ExHasSupport(region, foot.x, foot.y, foot.z)) continue;
						if (!StCellFree(foot.x, foot.y, foot.z)) continue;
						if (g_abRetry.Recent(AcPackCell(foot.x, foot.y, foot.z), kAbRetryTicks)) continue;
						vec3_ti clicked{0, 0, 0};
						unsigned char face = 0;
						if (!ExAnchor(region, foot, clicked, face)) continue;
						checked++;
						for (const AbDir& d : kAbDirs) {
							vec3_ti head{foot.x + d.dx, foot.y, foot.z + d.dz};
							if (ExDistToBlock(eye, head) > abPlaceRange + 1.0f) continue;
							if (!AcIsAir(AcBlockAt(region, head)) || !ExHasSupport(region, head.x, head.y, head.z)) continue;
							if (!StCellFree(head.x, head.y, head.z)) continue;
							float enemy = bedEnemy(foot, head);
							if (enemy < abEnemyDamage) { statLow++; continue; }
							float self = bedSelf(foot, head);
							if (!selfSafe(self)) { statSelf++; continue; }
							float score = abPriority == 0 ? enemy - 0.5f * self
														  : -AcDist3F((float)foot.x + 0.5f, (float)foot.y + 0.5f, (float)foot.z + 0.5f, t.pos.x, t.pos.y, t.pos.z);
							// histeresis: la misma cama y la misma direccion del plan anterior
							if (AcTicksSince(g_abPlanTick) <= 2 && ExSameCell(foot, g_abPlanFoot) && fabsf(AcWrap180(g_abPlanYaw - d.yaw)) < 0.5f) score += 5.0f;
							if (score > bestScore) {
								bestScore = score;
								planFoot = foot;
								planHead = head;
								planClicked = clicked;
								planFace = face;
								planYaw = d.yaw;
								planEnemy = enemy;
								planSelf = self;
								havePlan = true;
							}
						}
					}
				}
			}
		}
		if (havePlan) {
			g_abPlanFoot = planFoot;
			g_abPlanYaw = planYaw;
			g_abPlanTick = g_acTick;
		}
	}
	g_abStatLow = statLow;
	g_abStatSelf = statSelf;

	if (!havePlan) {
		g_abStatus = statSelf > 0 && statLow == 0 ? AB_ST_SELF_DAMAGE : (statLow > 0 ? AB_ST_LOW_DAMAGE : AB_ST_NO_SPOT);
		g_abAim = ExBedAim();
		ExPublish(g_abOverlay, {});
		return;
	}
	if (abRender) ExPublish(g_abOverlay, {AbBedMark(planFoot, planHead, planEnemy, selfImmune ? -1.0f : planSelf)});
	else ExPublish(g_abOverlay, {});

	switch (ExRunBed(lp, gm, region, planFoot, planHead, planClicked, planFace, planYaw, abRotate, abSwitch, g_abJob, g_abAim, g_abRetry)) {
		case EXR_NO_ITEM: g_abStatus = AB_ST_NO_BED; break;
		case EXR_NO_SWITCH: g_abStatus = AB_ST_NO_SWITCH; break;
		case EXR_AIMING: g_abStatus = AB_ST_AIMING; return;  // el yaw se refresca cada tick, sin espera
		default:
			g_abStatus = AB_ST_WORKING;
			// una cama ajena (o la propia ya puesta) tambien se sigue hasta que explote
			if (!g_abJob.valid && ExSameCell(planFoot, planHead)) {
				g_abJob.valid = true;
				g_abJob.foot = g_abJob.head = planFoot;
				g_abJob.tick = g_acTick;
				g_abJob.detonatedAt = g_acTick;
			}
			break;
	}
	g_abLastAct = g_acTick;
}

#else
// Otros ABIs: no-op con la misma firma.
static void AutoBedOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
#endif

static void RenderAutoBed(ImDrawList* dl) {
	ExRenderOverlay(dl, g_abOverlay, autoBed && abRender, abFade, blastFillColor, blastLineColor);
}
