// Generado por tools/build_native.sh. No editar a mano.
#pragma once
#define GATYO_VERSION "1.0.0"
#define GATYO_BUILD 71
#define GATYO_BUILD_DATE "2026-10-26"
