#pragma once
// AutoCity: cuando el rival se encierra (un hoyo de obsidiana, un surround),
// rompe solo el bloque junto a el y remata con cristal, anchor o cama. Es el
// AutoCity ("AutoMine") de GatoClient, que minaba el bloque de la ciudad con
// PacketMine y opcionalmente dejaba un cristal, llevado a los tres explosivos.
//
//   1. Objetivo: los N mas cercanos dentro del Rango (mismos filtros del
//      KillAura). "Encerrado" = los cuatro lados de su huella, a la altura de
//      los pies, son bloques; sin esa condicion (opcion Solo si esta
//      encerrado) tambien sirve cualquier lado macizo. Con Burrow, si el rival
//      esta metido dentro de un bloque, ese bloque va primero.
//   2. Bloque de la ciudad: cada lado macizo al alcance (Alcance al bloque) se
//      evalua por el dano que habra DESPUES de romperlo: la celda cuenta como
//      aire en el raycast de exposicion. Gana el de mas dano (menos el propio
//      a la mitad) que pase el dano minimo y el tope propio.
//   3. Explosivo (Modo): Auto prueba cristal, anchor y cama, en ese orden, con
//      lo que haya en la hotbar y lo que explote en la dimension (el anchor no
//      explota en el Nether, la cama solo en el Nether y el End).
//        Cristal: se pone SOBRE el bloque antes de que se rompa (al llegar al
//                 % de progreso elegido); cuando el bloque cae se golpea. El
//                 bloque es obsidiana, asi que no se puede poner despues.
//        Anchor:  cuando el bloque cae, se coloca en la celda, se carga y se
//                 detona (ExRunAnchor).
//        Cama:    igual, con el yaw apuntado desde la mitad del minado para que
//                 llegue al servidor antes de colocar (ExRunBed).
//   4. El minado lo hace el motor de PacketMine (PmBegin): inicio por la funcion
//      del juego y golpe final cuando el progreso propio llega a 1. Funciona
//      aunque el modulo PacketMine este apagado; usa sus ajustes de tipo,
//      velocidad, cambio de herramienta y retardo.
//   5. Render: el bloque de la ciudad late con su barra de progreso, y el
//      explosivo que viene se ve por adelantado (el cristal girando sobre el
//      bloque, la cama plana o el anchor con sus cargas). El remate termina
//      cuando el anchor o la cama desaparecen de verdad, con una onda.

enum AutoCityStatus {
	CT_ST_IDLE, CT_ST_NO_TARGET, CT_ST_NOT_ENCLOSED, CT_ST_NO_CANDIDATE, CT_ST_MINING, CT_ST_EXPLOSIVE,
	CT_ST_DONE, CT_ST_PAUSED, CT_ST_NO_ITEMS, CT_ST_UNBREAKABLE,
};
static std::atomic<int> g_ctStatus{CT_ST_IDLE};
static std::atomic<int> g_ctProgress{0};

static std::string AutoCityStatusText() {
	switch (g_ctStatus.load()) {
		case CT_ST_NO_TARGET: return T(S_AcxStNoTarget);
		case CT_ST_NOT_ENCLOSED: return T(S_CtStNotEnclosed);
		case CT_ST_NO_CANDIDATE: return T(S_CtStNoCandidate);
		case CT_ST_MINING: return TF(S_CtStMining, g_ctProgress.load());
		case CT_ST_EXPLOSIVE: return T(S_CtStExplosive);
		case CT_ST_DONE: return T(S_CtStDone);
		case CT_ST_PAUSED: return T(S_AcxStPaused);
		case CT_ST_NO_ITEMS: return T(S_CtStNoItems);
		case CT_ST_UNBREAKABLE: return T(S_PmStUnbreakable);
	}
	return T(S_AcxStOff);
}

static ExOverlay g_ctOverlay;

#if defined(__aarch64__)

enum CtKind { CT_K_NONE = 0, CT_K_CRYSTAL = 1, CT_K_ANCHOR = 2, CT_K_BED = 3 };

struct CtPlan {
	bool valid = false;
	vec3_ti city{0, 0, 0};
	unsigned char face = 1;     // cara por la que se mina (la que mira al jugador)
	int kind = CT_K_NONE;
	uint64_t targetRid = 0;
	vec3_ti clicked{0, 0, 0};   // apoyo del anchor / la cama en la celda de la ciudad
	unsigned char cface = 0;
	vec3_ti head{0, 0, 0};      // cabeza de la cama
	float yaw = 0.0f;
	uint32_t since = 0;
	uint32_t brokenAt = 0;      // tick en que el bloque cayo (0 = sigue)
	int crystalsPlaced = 0;
	uint32_t crystalTick = 0;
	float enemy = -1.0f, self = -1.0f;  // dano estimado (para el texto del render)
};
static CtPlan g_ct;
static bool g_ctWas = false;
static uint32_t g_ctCooldown = 0;           // sin elegir otro plan hasta este tick
static uint32_t g_ctLastSelect = 0;
static AcRetryRing g_ctRetry;
static ExAnchorJob g_ctAnchorJob;
static ExBedJob g_ctBedJob;
static ExBedAim g_ctBedAim;
static std::unordered_map<uint64_t, uint32_t> g_ctBlacklist;  // celda -> tick hasta el que se evita

static const int kCtSelectEvery = 2;        // ticks entre evaluaciones de planes
static const int kCtGiveUpTicks = 60;       // un explosivo que no sale en ~3 s se abandona
static const float kCtHitReach = 6.0f;

static void CtReset(GameMode* gm) {
	if (g_ct.valid && PmActiveOn(g_ct.city)) PmCancel(gm);
	g_ct = CtPlan();
	g_ctWas = false;
	g_ctCooldown = 0;
	g_ctLastSelect = 0;
	g_ctRetry.Clear();
	g_ctAnchorJob = ExAnchorJob();
	g_ctBedJob = ExBedJob();
	g_ctBedAim = ExBedAim();
	g_ctBlacklist.clear();
	ExPublish(g_ctOverlay, {});
}

static bool CtBlacklisted(const vec3_ti& c) {
	auto it = g_ctBlacklist.find(AcPackCell(c.x, c.y, c.z));
	return it != g_ctBlacklist.end() && (int32_t)(it->second - g_acTick) > 0;
}

static void CtBlacklist(const vec3_ti& c, int ticks) {
	g_ctBlacklist[AcPackCell(c.x, c.y, c.z)] = g_acTick + ticks;
}

// Dano de un cristal en "exp" con la celda "ignore" ya rota.
static float CtCrystalDamage(const AcEntity& who, BlockSource* region, const glm::vec3& exp, const vec3_ti* ignore) {
	float seen = ExSeenPercent(region, who.box, exp, ignore);
	return AcxDamage(who.box, exp, seen, who.armor, who.armorPieces);
}

// Cristal cerca de la posicion donde iria el del bloque de la ciudad.
static Actor* CtCrystalAt(LocalPlayer* lp, Level* level, const vec3_ti& c) {
	glm::vec3 want((float)c.x + 0.5f, (float)c.y + 1.0f, (float)c.z + 0.5f);
	for (AcEntity& e : AcCollectCrystals(lp, level, 16.0f)) {
		if (AcDist3F(e.pos.x, e.pos.y, e.pos.z, want.x, want.y, want.z) < 1.1f) return e.actor;
	}
	return nullptr;
}

// Bloque de la ciudad que se puede mirar para minar: no aire, no liquido, no bedrock.
static bool CtMineable(BlockSource* region, const vec3_ti& c) {
	Block* b = AcBlockAt(region, c);
	return !AcIsAir(b) && !ExIsLiquid(b) && !AcIsBedrock(b);
}

static void AutoCityOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!autoCity) {
		if (g_ctWas) CtReset(gm);
		g_ctWas = false;
		g_ctStatus = CT_ST_IDLE;
		return;
	}
	g_ctWas = true;
	AcAdvanceTick();
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	const GaxV3 eye = GaxPos(lp);
	const int dim = ExDimensionOf(region);
	const bool eating = ctEatStop && AcEatingActive(lp);
	AcEntity me = AcSelfEntity(lp);
	const bool selfImmune = !lp->isAttackableGamemode();
	auto selfSafe = [&](float d) { return selfImmune || (d <= ctSelfDamage && d < (float)lp->getHealth()); };

	std::vector<AcEntity> targets = AcCollectTargets(lp, level, ctRange, false);
	std::sort(targets.begin(), targets.end(), [](const AcEntity& a, const AcEntity& b) { return a.dist < b.dist; });
	if (targets.size() > 3) targets.resize(3);

	// -----------------------------------------------------------------------------
	// Plan en marcha
	// -----------------------------------------------------------------------------
	if (g_ct.valid) {
		const AcEntity* target = nullptr;
		for (const AcEntity& t : targets) {
			if (t.rid == g_ct.targetRid) target = &t;
		}
		bool broken = !CtMineable(region, g_ct.city);
		// el rival se fue o murio y el bloque sigue ahi: se cancela y se reelige
		if (!target && !broken) {
			if (PmActiveOn(g_ct.city)) PmCancel(gm);
			g_ct = CtPlan();
			g_ctCooldown = g_acTick + 4;
			return;
		}
		if (AcTicksSince(g_ct.since) > 400) {  // ~20 s sin resultado: otro bloque
			CtBlacklist(g_ct.city, 200);
			if (PmActiveOn(g_ct.city)) PmCancel(gm);
			g_ct = CtPlan();
			return;
		}
		std::vector<ExMark> marks;
		auto buildMarks = [&](float progress) {
			marks.clear();
			if (!ctRender) return;
			if (!broken) {
				ExMark city = ExMarkCell(g_ct.city, EXM_CITY, 1);
				city.progress = progress;
				snprintf(city.label, sizeof(city.label), "CITY %d%%", (int)(progress * 100.0f));
				marks.push_back(city);
			}
			// el explosivo que viene: el cristal sobre el bloque, el anchor o la cama en la celda
			ExMark e = ExMarkCell(g_ct.city, EXM_BOX, 2);
			if (g_ct.kind == CT_K_CRYSTAL) {
				e.style = EXM_CRYSTAL;
				e.x0 += 0.3f; e.x1 -= 0.3f; e.z0 += 0.3f; e.z1 -= 0.3f;
				e.y0 += 1.15f; e.y1 = e.y0 + 0.4f;
			} else if (g_ct.kind == CT_K_ANCHOR) {
				if (!broken) return;
				e.style = EXM_ANCHOR;
				e.charge = (int8_t)ExAnchorCharge(AcBlockAt(region, g_ct.city));
			} else if (g_ct.kind == CT_K_BED) {
				e.style = EXM_BED;
				e.hx = (int8_t)ImClamp(g_ct.head.x - g_ct.city.x, -1, 1);
				e.hz = (int8_t)ImClamp(g_ct.head.z - g_ct.city.z, -1, 1);
				if (!broken) e.y0 += 1.0f;  // se ve encima mientras se mina
			} else {
				return;
			}
			e.enemy = g_ct.enemy;
			e.self = g_ct.self;
			marks.push_back(e);
		};
		buildMarks(broken ? 1.0f : PmProgress());

		if (!broken) {
			// ---- minando ------------------------------------------------------------
			if (!PmActiveOn(g_ct.city)) {
				if (ExDistToBlock(eye, g_ct.city) > ctReach) {
					g_ctStatus = CT_ST_NO_CANDIDATE;
					ExPublish(g_ctOverlay, marks);
					return;
				}
				g_ct.face = ExFaceToward(eye, g_ct.city);
				if (!PmBegin(lp, gm, g_ct.city, g_ct.face, PM_OWNER_CITY)) {
					g_ctStatus = CT_ST_UNBREAKABLE;
					CtBlacklist(g_ct.city, 400);
					g_ct = CtPlan();
					return;
				}
			}
			float progress = PmProgress();
			g_ctProgress = (int)(progress * 100.0f);
			g_ctStatus = CT_ST_MINING;

			if (g_ct.kind == CT_K_CRYSTAL && !eating && g_ct.crystalsPlaced < 3 &&
				progress * 100.0f >= (float)ctPlaceAt && AcTicksSince(g_ct.crystalTick) >= 4 &&
				!CtCrystalAt(lp, level, g_ct.city)) {
				// SOBRE el bloque, antes de que caiga: despues ya no hay base
				void* ci = (void*)CI;
				AcSlotsBegin(lp);
				if (AcSwitchSlot(lp, ci, ctSwitch, Ac::NameEndCrystal) >= 0) {
					ExBuildAt(gm, g_ct.city, 1);
					g_ct.crystalsPlaced++;
					g_ct.crystalTick = g_acTick;
				} else {
					g_ctStatus = CT_ST_NO_ITEMS;
				}
				AcSlotsEnd(lp, ci);
			}
			if (g_ct.kind == CT_K_BED && progress >= 0.5f) {
				ExAimYaw(lp, g_ct.yaw);  // el yaw ya habra llegado cuando el bloque caiga
				ExBedAimed(g_ctBedAim, g_ct.yaw);
			}
			buildMarks(progress);
			ExPublish(g_ctOverlay, marks);
			return;
		}

		// ---- el bloque cayo: remate ---------------------------------------------------
		if (!g_ct.brokenAt) g_ct.brokenAt = g_acTick;
		g_ctProgress = 100;
		if (eating) {
			g_ctStatus = CT_ST_PAUSED;
			return;
		}
		if (AcTicksSince(g_ct.brokenAt) > kCtGiveUpTicks) {
			g_ct = CtPlan();
			g_ctCooldown = g_acTick + 6;
			return;
		}
		bool finished = false;
		switch (g_ct.kind) {
			case CT_K_NONE:
				finished = true;
				break;
			case CT_K_CRYSTAL: {
				Actor* crystal = CtCrystalAt(lp, level, g_ct.city);
				if (!crystal) {
					// nunca se puso (o ya explotaron): no hay base para ponerlo ahora
					finished = AcTicksSince(g_ct.brokenAt) > 10;
					break;
				}
				if (!ctHit) {
					finished = true;
					break;
				}
				glm::vec3 exp((float)g_ct.city.x + 0.5f, (float)g_ct.city.y + 1.0f, (float)g_ct.city.z + 0.5f);
				float enemy = target ? CtCrystalDamage(*target, region, exp, nullptr) : 0.0f;
				float self = selfImmune ? 0.0f : CtCrystalDamage(me, region, exp, nullptr);
				GaxV3 cp = GaxPos(crystal);
				if (enemy >= ctEnemyDamage && selfSafe(self) && AcDist3F(eye.x, eye.y, eye.z, cp.x, cp.y, cp.z) <= kCtHitReach) {
					AcAttack(gm, crystal);
					lp->swing();
					ExPushBurst(cp.x, cp.y, cp.z, blastLineColor, 1.2f);
					finished = true;
				}
				break;
			}
			case CT_K_ANCHOR: {
				// termina cuando el anchor desaparece despues de detonarlo, no al mandar el clic
				if (g_ctAnchorJob.valid && g_ctAnchorJob.detonatedAt && AcTicksSince(g_ctAnchorJob.tick) > 1 &&
					!ExIsAnchorBlock(AcBlockAt(region, g_ct.city))) {
					ExBurstAtCell(g_ct.city, blastLineColor, 1.0f);
					finished = true;
					break;
				}
				int r = ExRunAnchor(lp, gm, region, g_ct.city, g_ct.clicked, g_ct.cface, ctSwitch, g_ctAnchorJob, g_ctRetry);
				if (r == EXR_NO_ITEM || r == EXR_NO_GLOWSTONE || r == EXR_NO_SWITCH || r == EXR_NO_DETONATOR) {
					g_ctStatus = CT_ST_NO_ITEMS;
					return;
				}
				if (r == EXR_REJECTED) {
					g_ct = CtPlan();
					g_ctCooldown = g_acTick + 20;
					return;
				}
				break;
			}
			case CT_K_BED: {
				if (g_ctBedJob.valid && g_ctBedJob.detonatedAt && AcTicksSince(g_ctBedJob.tick) > 1 &&
					!ExIsBedBlock(AcBlockAt(region, g_ct.city)) && !ExIsBedBlock(AcBlockAt(region, g_ct.head))) {
					glm::vec3 c = (ExCenterOf(g_ct.city) + ExCenterOf(g_ct.head)) * 0.5f;
					ExPushBurst(c.x, c.y, c.z, blastLineColor, 1.0f);
					finished = true;
					break;
				}
				int r = ExRunBed(lp, gm, region, g_ct.city, g_ct.head, g_ct.clicked, g_ct.cface, g_ct.yaw, true, ctSwitch,
								 g_ctBedJob, g_ctBedAim, g_ctRetry);
				if (r == EXR_NO_ITEM || r == EXR_NO_SWITCH) {
					g_ctStatus = CT_ST_NO_ITEMS;
					return;
				}
				break;
			}
		}
		if (finished) {
			g_ctStatus = CT_ST_DONE;
			g_ct = CtPlan();
			g_ctCooldown = g_acTick + 8;
			ExPublish(g_ctOverlay, {});
		} else {
			g_ctStatus = CT_ST_EXPLOSIVE;
			buildMarks(1.0f);
			ExPublish(g_ctOverlay, marks);
		}
		return;
	}

	// -----------------------------------------------------------------------------
	// Elegir plan
	// -----------------------------------------------------------------------------
	ExPublish(g_ctOverlay, {});
	if (targets.empty()) {
		g_ctStatus = CT_ST_NO_TARGET;
		return;
	}
	if ((int32_t)(g_ctCooldown - g_acTick) > 0) return;
	if (g_ctLastSelect && AcTicksSince(g_ctLastSelect) < kCtSelectEvery) return;
	g_ctLastSelect = g_acTick;

	// kinds disponibles: lo que hay en la hotbar y lo que explota aca
	bool haveCrystal = AcHasItem(lp, Ac::NameEndCrystal);
	bool haveAnchor = ExAnchorExplodes(dim) && AcHasItem(lp, Ex::NameRespawnAnchor) && AcHasItem(lp, Ex::NameGlowstone);
	bool haveBed = ExBedExplodes(dim) && AcHasItem(lp, Ex::NameBed);
	int order[3];
	int orderN = 0;
	if (ctMode == 0 || ctMode == 1) { if (haveCrystal) order[orderN++] = CT_K_CRYSTAL; }
	if (ctMode == 0 || ctMode == 2) { if (haveAnchor) order[orderN++] = CT_K_ANCHOR; }
	if (ctMode == 0 || ctMode == 3) { if (haveBed) order[orderN++] = CT_K_BED; }

	// todas las entidades de la zona, una sola vez
	float minX = 1e9f, minY = 1e9f, minZ = 1e9f, maxX = -1e9f, maxY = -1e9f, maxZ = -1e9f;
	for (const AcEntity& t : targets) {
		minX = ImMin(minX, t.box.lower.x); maxX = ImMax(maxX, t.box.upper.x);
		minY = ImMin(minY, t.box.lower.y); maxY = ImMax(maxY, t.box.upper.y);
		minZ = ImMin(minZ, t.box.lower.z); maxZ = ImMax(maxZ, t.box.upper.z);
	}
	StCollectBlockers(level, minX - 3, minY - 2, minZ - 3, maxX + 3, maxY + 4, maxZ + 3);
	std::vector<GaxBox> boxes = AcCollectBoxes(level, lp);

	CtPlan best;
	float bestScore = -1e9f;
	int statNotEnclosed = 0, statNoKind = 0;
	for (const AcEntity& t : targets) {
		ExFootprint f = ExFootprintOf(t.box);
		// lados de la huella a la altura de los pies (sin esquinas)
		std::vector<vec3_ti> ring;
		for (int x = f.x0 - 1; x <= f.x1 + 1; x++) {
			for (int z = f.z0 - 1; z <= f.z1 + 1; z++) {
				bool insideX = x >= f.x0 && x <= f.x1, insideZ = z >= f.z0 && z <= f.z1;
				if (insideX == insideZ) continue;  // la huella misma o una esquina
				ring.push_back(vec3_ti{x, f.feetY, z});
			}
		}
		bool enclosed = true;
		for (const vec3_ti& c : ring) {
			Block* b = AcBlockAt(region, c);
			if (AcIsAir(b) || ExIsLiquid(b)) enclosed = false;
		}
		// burrow: el rival esta dentro de un bloque
		std::vector<vec3_ti> burrow;
		if (ctBurrow) {
			for (int x = f.x0; x <= f.x1; x++) {
				for (int z = f.z0; z <= f.z1; z++) {
					vec3_ti c{x, f.feetY, z};
					if (CtMineable(region, c)) burrow.push_back(c);
				}
			}
		}
		if (ctEnclosed && !enclosed && burrow.empty()) {
			statNotEnclosed++;
			continue;
		}

		auto offer = [&](const CtPlan& p, float score) {
			if (score > bestScore) {
				bestScore = score;
				best = p;
				best.valid = true;
				best.targetRid = t.rid;
			}
		};

		// el bloque donde esta metido va primero: tapa todo el dano
		for (const vec3_ti& c : burrow) {
			if (ExDistToBlock(eye, c) > ctReach || CtBlacklisted(c)) continue;
			CtPlan p;
			p.city = c;
			p.kind = CT_K_NONE;
			offer(p, 1000.0f);
		}

		for (const vec3_ti& c : ring) {
			if (!CtMineable(region, c) || ExDistToBlock(eye, c) > ctReach || CtBlacklisted(c)) continue;
			bool kindFound = false;
			for (int oi = 0; oi < orderN && !kindFound; oi++) {
				int kind = order[oi];
				CtPlan p;
				p.city = c;
				p.kind = kind;
				float enemy = 0.0f, self = 0.0f;
				if (kind == CT_K_CRYSTAL) {
					// obsidiana con dos de aire encima y la jaula libre
					if (!AcIsObsidian(AcBlockAt(region, c)) || !AcCanPlaceAt(region, c, false) || !AcCageFree(boxes, c, nullptr)) continue;
					glm::vec3 exp((float)c.x + 0.5f, (float)c.y + 1.0f, (float)c.z + 0.5f);
					enemy = CtCrystalDamage(t, region, exp, &c);
					if (enemy < ctEnemyDamage) continue;
					self = selfImmune ? 0.0f : CtCrystalDamage(me, region, exp, &c);
				} else if (kind == CT_K_ANCHOR) {
					if (!ExAnchor(region, c, p.clicked, p.cface)) continue;
					enemy = ExDamageTo(t, region, ExCenterOf(c), &c);
					if (enemy < ctEnemyDamage) continue;
					self = selfImmune ? 0.0f : ExDamageTo(me, region, ExCenterOf(c), &c);
				} else {  // cama
					if (!ExHasSupport(region, c.x, c.y, c.z) || !ExAnchor(region, c, p.clicked, p.cface)) continue;
					float bestBed = -1e9f;
					for (const AbDir& d : kAbDirs) {
						vec3_ti h{c.x + d.dx, c.y, c.z + d.dz};
						if (!AcIsAir(AcBlockAt(region, h)) || !ExHasSupport(region, h.x, h.y, h.z) || !StCellFree(h.x, h.y, h.z)) continue;
						float e = ImMin(ExDamageTo(t, region, ExCenterOf(c), &c), ExDamageTo(t, region, ExCenterOf(h), &c));
						if (e < ctEnemyDamage) continue;
						float s = selfImmune ? 0.0f : ImMax(ExDamageTo(me, region, ExCenterOf(c), &c), ExDamageTo(me, region, ExCenterOf(h), &c));
						if (e - 0.5f * s > bestBed) {
							bestBed = e - 0.5f * s;
							enemy = e;
							self = s;
							p.head = h;
							p.yaw = d.yaw;
						}
					}
					if (bestBed < -1e8f) continue;
				}
				if (!selfSafe(self)) continue;
				kindFound = true;
				p.enemy = enemy;
				p.self = selfImmune ? -1.0f : self;
				offer(p, enemy - 0.5f * self);
			}
			if (!kindFound) statNoKind++;
		}
	}

	if (!best.valid) {
		if (orderN == 0 && !(ctBurrow)) g_ctStatus = CT_ST_NO_ITEMS;
		else g_ctStatus = statNotEnclosed > 0 && statNoKind == 0 ? CT_ST_NOT_ENCLOSED : CT_ST_NO_CANDIDATE;
		return;
	}
	best.since = g_acTick;
	best.face = ExFaceToward(eye, best.city);
	g_ct = best;
	g_ctAnchorJob = ExAnchorJob();
	g_ctBedJob = ExBedJob();
	g_ctBedAim = ExBedAim();
	g_ctStatus = CT_ST_MINING;
	g_ctProgress = 0;
	// el primer paso del minado sale en este mismo tick
	if (!PmBegin(lp, gm, g_ct.city, g_ct.face, PM_OWNER_CITY)) {
		g_ctStatus = CT_ST_UNBREAKABLE;
		CtBlacklist(g_ct.city, 400);
		g_ct = CtPlan();
	}
}

#else
// Otros ABIs: no-op con la misma firma.
static void AutoCityOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
#endif

static void RenderAutoCity(ImDrawList* dl) {
	ExRenderOverlay(dl, g_ctOverlay, autoCity && ctRender, true, blastFillColor, blastLineColor);
}
