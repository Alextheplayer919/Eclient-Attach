#pragma once
// ClickGUI: modo alternativo al panel, al estilo de los clientes de PC. Una
// ventana flotante por categoria (se arrastra desde el encabezado y se pliega
// con un toque), una barra superior con buscador y una burbuja para reabrirlo.
// Cada modulo es una fila: tocarla lo activa y la flecha despliega sus ajustes.

static const int kCgPages[] = {
	PAGE_MOVEMENT, PAGE_COMBAT, PAGE_BUILDING, PAGE_PLAYERS, PAGE_VISUALS, PAGE_HUD, PAGE_OTHER, PAGE_APPEARANCE,
};
static const int kCgPageCount = IM_ARRAYSIZE(kCgPages);

static bool g_cgOpen = true;
static double g_cgOpenTime = -10.0;
static float g_cgExtend[PAGE_COUNT];
static bool g_cgExtendReady = false;
static float g_cgContentHeight[PAGE_COUNT];
static bool g_cgExpanded[MOD_COUNT];
static bool g_cgHeaderDragged = false;  // el toque actual movio una ventana

// Sub-opciones que en el ClickGUI van dentro de los ajustes de su modulo.
static int CgParentOf(int mod) {
	switch (mod) {
		case MOD_useGeyserCooldown: case MOD_swing: case MOD_rotations: case MOD_targetLock:
		case MOD_hurtCheck: case MOD_emulateNativeAttack:
			return MOD_killAura;
		case MOD_espBox: case MOD_espLine: case MOD_espDistance: case MOD_espNametag: case MOD_espHealth:
		case MOD_espPlatform: case MOD_espHealthBar: case MOD_espHealthColor: case MOD_espHealthGradient:
		case MOD_espDistanceScale: case MOD_espPaletteColor: case MOD_tracerGradient:
			return MOD_esp;
		case MOD_watermarkFps: case MOD_watermarkTps: case MOD_watermarkCoords: case MOD_watermarkVersion:
			return MOD_watermark;
		case MOD_hudCoordsDecimals:
			return MOD_showPosition;
		case MOD_flyDynamic: case MOD_flyAntiKick: case MOD_flyLookControl:
			return MOD_gatoFly;
		case MOD_offhandSmart: case MOD_offhandSurroundOnly:
			return MOD_offhand;
		case MOD_chatGreenText: case MOD_chatFancy: case MOD_chatClientSuffix: case MOD_chatPrefixTag:
		case MOD_chatPrefixUpper: case MOD_chatPrefixLower: case MOD_chatPrefixNums: case MOD_chatSuffixTag:
		case MOD_chatSuffixUpper: case MOD_chatSuffixLower: case MOD_chatSuffixNums: case MOD_chatFakeName:
		case MOD_chatCustomBefore: case MOD_chatCustomAfter:
			return MOD_chatModule;
		case MOD_gaxHurttime: case MOD_gaxAttackMobs: case MOD_gaxRandomizeHit: case MOD_gaxTargetVisualize:
		case MOD_gaxNoSwing: case MOD_gaxMoveCamera:
			return MOD_gatoAuraX;
		case MOD_popCountSelf: case MOD_popCountFriends: case MOD_popSendPop: case MOD_popSendDeath:
		case MOD_popRandomMessage:
			return MOD_popCounter;
		case MOD_espPops:
			return MOD_esp;
		case MOD_pearlPredict: case MOD_pearlOwner:
			return MOD_pearlTracker;
		case MOD_logSpotNotify:
			return MOD_logSpot;
		case MOD_waypointDistance:
			return MOD_waypoints;
		case MOD_targetHudCompare: case MOD_targetHudTotems: case MOD_targetHudFollow:
			return MOD_targetHud;
		case MOD_itemCounterVertical: case MOD_itemCounterHideZero:
			return MOD_itemCounter;
		case MOD_hudInfoDirection: case MOD_hudInfoBps:
			return MOD_hudInfo;
		case MOD_fakePlayerMove: case MOD_fakePlayerCombat: case MOD_fakePlayerGapples:
		case MOD_fakePlayerNoKnockback: case MOD_fakePlayerInfinite:
			return MOD_fakePlayer;
		case MOD_holeEspFill: case MOD_holeEspOutline:
			return MOD_holeEsp;
		case MOD_noRenderEntities: case MOD_noRenderBlockEntities: case MOD_noRenderParticles: case MOD_noRenderWeather:
			return MOD_noRender;
		case MOD_allEspPlayers: case MOD_allEspMobs: case MOD_allEspItems: case MOD_allEspXp:
		case MOD_allEspCrystals: case MOD_allEspTnt: case MOD_allEspBoats: case MOD_allEspMinecarts:
			return MOD_allEsp;
	}
	return -1;
}

static bool CgHasSettings(int mod) {
	switch (mod) {
		case MOD_killAura: case MOD_mobAura: case MOD_hitBox: case MOD_autoClicker: case MOD_enableFov:
		case MOD_esp: case MOD_damageIndicators: case MOD_watermark: case MOD_showPosition:
		case MOD_hudFpsGraph: case MOD_xrayDefault: case MOD_uiAnimations: case MOD_uiBgImage: case MOD_notifEnabled:
		case MOD_gatoFly: case MOD_bypassFly: case MOD_gatoAuraX: case MOD_customFov: case MOD_offhand:
		case MOD_chatModule: case MOD_popCounter:
		case MOD_pearlTracker: case MOD_logSpot: case MOD_waypoints: case MOD_screenTint: case MOD_targetHud:
		case MOD_itemCounter: case MOD_hudInfo: case MOD_sessionHud: case MOD_customText: case MOD_hudImage:
		case MOD_fakePlayer: case MOD_holeEsp: case MOD_allEsp: case MOD_noRender:
		// Suite de cristales: el placer y el helper funcionan sin ajustes.
		case MOD_autoCrystal: case MOD_autoCrystalX: case MOD_antiCrystal: case MOD_crystalChams: case MOD_charms:
		case MOD_selfTrap: case MOD_surround: case MOD_platform:
		case MOD_packetMine: case MOD_autoTrap: case MOD_autoAnchor: case MOD_autoBed: case MOD_autoCity:
		case MOD_plus999Aura: case MOD_autoHotbar: case MOD_nametags: case MOD_viewModel: case MOD_swingSpeed:
			return true;
	}
	return false;
}

static float CgUnit() {
	return UiUnit();
}

// Medidas con el tamaño de texto del ClickGUI, para usarlas fuera de sus ventanas.
static float CgFontSize() {
	return ImGui::GetFontSize() * cgTextScale;
}

static float CgFrameHeight() {
	return CgFontSize() + ImGui::GetStyle().FramePadding.y * 2.0f;
}

static void CgOpenInPanel(int page) {
	uiLayout = 0;
	pageId = page;
	g_searchQuery.clear();
}

// En las ventanas los sliders ocupan todo el ancho, asi que casi cualquier
// deslizamiento empieza sobre uno. Al tocarlo el valor no salta: se queda
// quieto hasta saber que quiere el dedo. Si el gesto es horizontal el slider
// sigue al dedo; si es vertical lo suelta (el desplazamiento lo toma
// TouchScroll); si se levanta sin moverse cuenta como toque y salta ahi.
template <typename V>
static void CgGuardSlider(V before, V* value) {
	static ImGuiID activeId = 0;
	static V start, tapValue;
	static bool decided = false;
	ImGuiID id = ImGui::GetItemID();
	if (ImGui::IsItemActivated()) {
		activeId = id;
		start = before;
		decided = false;
	}
	if (activeId != id) return;
	if (ImGui::IsItemActive()) {
		if (decided) return;
		tapValue = *value;
		*value = start;
		// mismo umbral que TouchScroll, que corre despues en el mismo frame
		if (!ImGui::IsMouseDragging(ImGuiMouseButton_Left, kTouchDragThreshold * scaleGlobal)) return;
		ImVec2 drag = ImGui::GetMouseDragDelta(ImGuiMouseButton_Left);
		if (fabsf(drag.x) > fabsf(drag.y)) {
			decided = true;
			g_touchKeepItem = id;
			*value = tapValue;
		} else {
			ImGui::ClearActiveID();
			activeId = 0;
		}
	} else {
		// se solto sin decidir: fue un toque
		if (!decided && !g_touchScrolled) *value = tapValue;
		if (g_touchKeepItem == id) g_touchKeepItem = 0;
		activeId = 0;
	}
}

static bool CgSliderFloat(const char* id, float* v, float min, float max, const char* format) {
	float before = *v;
	bool changed = ImGui::SliderFloat(id, v, min, max, format);
	CgGuardSlider(before, v);
	return changed;
}

static bool CgSliderInt(const char* id, int* v, int min, int max, const char* format = "%d") {
	int before = *v;
	bool changed = ImGui::SliderInt(id, v, min, max, format);
	CgGuardSlider(before, v);
	return changed;
}

static bool CgDragFloat(const char* id, float* v, float speed, float min, float max, const char* format) {
	float before = *v;
	bool changed = ImGui::DragFloat(id, v, speed, min, max, format);
	CgGuardSlider(before, v);
	return changed;
}

static bool CgDragInt(const char* id, int* v, float speed, int min, int max) {
	int before = *v;
	bool changed = ImGui::DragInt(id, v, speed, min, max);
	CgGuardSlider(before, v);
	return changed;
}

// Etiqueta arriba del control: las ventanas son angostas y no entra al costado.
static void CgLabel(StrId id) {
	ImGui::PushStyleColor(ImGuiCol_Text, GatyoGetPalette().muted);
	ImGui::PushTextWrapPos(0.0f);
	ImGui::TextUnformatted(T(id));
	ImGui::PopTextWrapPos();
	ImGui::PopStyleColor();
}

static void CgChildToggles(int parent) {
	for (int i = 0; i < MOD_COUNT; i++) {
		if (CgParentOf(i) == parent) ModToggle(i);
	}
}

static void CgAuraTypeCombo() {
	static const StrId auraTypes[] = {S_AuraSingle, S_AuraNearest, S_AuraMulti};
	CgLabel(S_AuraType);
	if (!useGeyserCooldown && !emulateNativeAttack) {
		ComboT("##cg_aura", &auraType, auraTypes, 3);
	} else {
		if (auraType == 2) auraType = 1;
		ComboT("##cg_aura", &auraType, auraTypes, 2);
	}
	Tip(S_TipAuraType);
}

// Ajustes de cada modulo. Respetan las mismas reglas que el panel (rangos,
// acoplamientos y opciones que dependen de otras).
static void CgModuleSettings(int mod) {
	ImGui::PushID(mod);
	ImGui::PushItemWidth(-1);
	switch (mod) {
		case MOD_killAura:
			CgLabel(S_AttackRange);
			if (CgDragFloat("##range", &killRange, 0.015f, 1.0f, 10.0f, "%.1f")) {
				if (killRange > rotationsRange) rotationsRange = killRange;
			}
			if (rotations || targetLock) {
				CgLabel(S_LockRange);
				if (CgDragFloat("##lock", &rotationsRange, 0.015f, 1.0f, 100.0f, "%.1f")) {
					if (killRange > rotationsRange) killRange = rotationsRange;
				}
			}
			if (!useGeyserCooldown) {
				CgLabel(S_HitDelay);
				CgDragInt("##delay", &maxKillTick, 0.05f, 1, 150);
				Tip(S_TipDelayTicks);
			}
			CgAuraTypeCombo();
			CgChildToggles(mod);
			break;
		case MOD_mobAura:
			CgLabel(S_MobRange);
			CgDragFloat("##mobrange", &mobAuraRange, 0.015f, 1.0f, 10.0f, "%.1f");
			if (!useGeyserCooldown) {
				CgLabel(S_MobDelay);
				CgDragInt("##mobdelay", &maxMobAuraTick, 0.05f, 1, 150);
				Tip(S_TipDelayTicks);
			}
			CgAuraTypeCombo();
			if (ImGui::Button(TL(S_TabMobList))) CgOpenInPanel(PAGE_COMBAT);
			break;
		case MOD_hitBox:
			CgLabel(S_HitBoxSize);
			CgDragFloat("##hitbox", &hitBoxValue, 0.015f, 0.6f, 10.0f, "%.1f");
			break;
		case MOD_autoClicker:
			CgLabel(S_ClickDelay);
			CgDragInt("##click", &maxAutoClickTick, 0.05f, 1, 150);
			Tip(S_TipDelayTicks);
			break;
		case MOD_enableFov:
			CgLabel(S_Fov);
			CgSliderFloat("##fov", &fov, -90.0f, 90.0f, "%.0f");
			break;
		case MOD_xrayDefault:
			if (ImGui::Button(TL(S_OpenInPanel))) CgOpenInPanel(PAGE_VISUALS);
			break;
		case MOD_esp: {
			CgChildToggles(mod);
			static const StrId boxStyles[] = {S_BoxFull, S_BoxCorners, S_BoxSoft};
			CgLabel(S_EspBoxStyle);
			ComboT("##box", &espBoxStyle, boxStyles, IM_ARRAYSIZE(boxStyles));
			CgLabel(S_Thickness);
			CgSliderFloat("##thick", &espThickness, 0.5f, 6.0f, "%.1f");
			CgLabel(S_Opacity);
			CgSliderFloat("##opacity", &espOpacity, 0.1f, 1.0f, "%.2f");
			static const StrId origins[] = {S_OriginCrosshair, S_OriginBottom, S_OriginTop};
			CgLabel(S_TracerOrigin);
			ComboT("##origin", &espLineMode, origins, IM_ARRAYSIZE(origins));
			CgLabel(S_Thickness);
			CgSliderFloat("##tracer", &tracerThickness, 0.5f, 6.0f, "%.1f");
			break;
		}
		case MOD_damageIndicators: {
			CgLabel(S_DmgSize);
			CgSliderFloat("##dmgsize", &dmgSize, 0.5f, 2.5f, "%.2fx");
			CgLabel(S_DmgDuration);
			CgSliderFloat("##dmgtime", &dmgDuration, 0.4f, 3.0f, "%.1f");
			static const StrId dmgModes[] = {S_DmgClassic, S_DmgPalette, S_DmgCustom};
			CgLabel(S_DmgColorMode);
			ComboT("##dmgmode", &dmgColorMode, dmgModes, IM_ARRAYSIZE(dmgModes));
			if (dmgColorMode == 2) ImGui::ColorEdit3("##dmgcolor", dmgColor, ImGuiColorEditFlags_NoInputs);
			break;
		}
		case MOD_watermark: {
			static const StrId styles[] = {S_StyleCompact, S_StyleExtended, S_StyleText};
			CgLabel(S_WatermarkStyle);
			ComboT("##wmstyle", &watermarkStyle, styles, IM_ARRAYSIZE(styles));
			CgChildToggles(mod);
			break;
		}
		case MOD_showPosition:
			CgChildToggles(mod);
			break;
		case MOD_hudFpsGraph:
			CgLabel(S_FpsWindow);
			CgSliderInt("##fpsw", &hudFpsGraphSeconds, 5, 30, "%d s");
			break;
		case MOD_gatoAuraX: {
			static const StrId targetModes[] = {S_GaxSingle, S_GaxMulti};
			CgLabel(S_GaxRotation);
			GatoAuraXRotationCombo("##gaxrot");
			Tip(S_TipGaxRotation);
			CgLabel(S_GaxTargetMode);
			ComboT("##gaxtargets", &gaxTargetMode, targetModes, IM_ARRAYSIZE(targetModes));
			CgLabel(S_GaxRange);
			CgSliderFloat("##gaxrange", &gaxRange, 2.0f, 150.0f, "%.1f");
			CgLabel(S_GaxInterval);
			CgSliderInt("##gaxinterval", &gaxInterval, 0, 20);
			CgLabel(S_GaxMultiplier);
			CgSliderInt("##gaxmult", &gaxMultiplier, 1, 10);
			if (gaxRotationMode == GAX_ROT_ECLIPSE) {
				CgLabel(S_GaxEclipseLead);
				CgSliderFloat("##gaxeclipse", &gaxEclipseLead, 0.0f, 4.0f, "%.1f");
				Tip(S_TipGaxEclipse);
			}
			CgLabel(S_GaxVertOffset);
			CgSliderFloat("##gaxvoff", &gaxVertOffset, -1.0f, 1.0f, "%.2f");
			CgChildToggles(mod);
			if (gaxRandomizeHit) {
				CgLabel(S_GaxHitChance);
				CgSliderInt("##gaxchance", &gaxHitChance, 1, 100);
			}
			if (gaxTargetVisualize) {
				CgLabel(S_GaxTvColor);
				ImGui::ColorEdit4("##gaxtv", gaxTvColor, ImGuiColorEditFlags_NoInputs);
			}
			DrawAuraWeaponSettings(&gaxSwitchMode, &gaxRainMode, &gaxAutoTrident, -1.0f);
			break;
		}
		case MOD_plus999Aura:
			DrawPlus999AuraSettings(-1.0f);
			break;
		case MOD_autoHotbar:
			DrawAutoHotbarSettings(-1.0f);
			break;
		case MOD_nametags:
			DrawNametagsSettings(-1.0f);
			break;
		case MOD_viewModel:
			DrawViewModelSettings(-1.0f);
			break;
		case MOD_swingSpeed:
			DrawSwingSpeedSettings(-1.0f);
			break;
		// Suite de cristales: la misma lista de ajustes que la del panel,
		// ancha al maximo dentro de la fila. Sin toggles hijos: los bools de
		// sub-ajustes de estos modulos son ajustes normales.
		case MOD_autoCrystal:
			DrawAutoCrystalSettings(-1.0f);
			break;
		case MOD_autoCrystalX:
			DrawAutoCrystalXSettings(-1.0f);
			break;
		case MOD_antiCrystal:
			DrawAntiCrystalSettings(-1.0f);
			break;
		case MOD_crystalChams:
			DrawCrystalChamsSettings(-1.0f);
			break;
		case MOD_charms:
			DrawCharmsSettings(-1.0f);
			break;
		case MOD_selfTrap:
			DrawSelfTrapSettings(-1.0f);
			break;
		case MOD_surround:
			DrawSurroundSettings(-1.0f);
			break;
		case MOD_platform:
			DrawPlatformSettings(-1.0f);
			break;
		case MOD_packetMine:
			DrawPacketMineSettings(-1.0f);
			break;
		case MOD_autoTrap:
			DrawAutoTrapSettings(-1.0f);
			break;
		case MOD_autoAnchor:
			DrawAutoAnchorSettings(-1.0f);
			break;
		case MOD_autoBed:
			DrawAutoBedSettings(-1.0f);
			break;
		case MOD_autoCity:
			DrawAutoCitySettings(-1.0f);
			break;
		case MOD_holeEsp:
			DrawHoleEspSettings(-1.0f, true);
			break;
		case MOD_noRender:
			CgChildToggles(mod);
			break;
		case MOD_allEsp:
			DrawAllEspSettings(-1.0f, true);
			break;
		case MOD_chatModule:
			ModToggle(MOD_chatGreenText);
			ModToggle(MOD_chatFancy);
			ModToggle(MOD_chatClientSuffix);
			if (chatClientSuffix) ChatTextField(S_ChatClientName, &chatClientName, -1.0f);
			ModToggle(MOD_chatPrefixTag);
			if (chatPrefixTag) {
				CgLabel(S_ChatTagLength);
				CgSliderInt("##chatprefix", &chatPrefixLength, 1, 32);
				ModToggle(MOD_chatPrefixUpper);
				ModToggle(MOD_chatPrefixLower);
				ModToggle(MOD_chatPrefixNums);
			}
			ModToggle(MOD_chatSuffixTag);
			if (chatSuffixTag) {
				CgLabel(S_ChatTagLength);
				CgSliderInt("##chatsuffix", &chatSuffixLength, 1, 32);
				ModToggle(MOD_chatSuffixUpper);
				ModToggle(MOD_chatSuffixLower);
				ModToggle(MOD_chatSuffixNums);
			}
			DrawChatCustomPhrases(-1.0f);
			ModToggle(MOD_chatFakeName);
			if (chatFakeName) ChatTextField(S_ChatFakeNameValue, &chatFakeNameValue, -1.0f);
			break;
		case MOD_popCounter:
			DrawPopCounterSettings(-1.0f, true);
			break;
		case MOD_offhand: {
			static const StrId items[] = {S_OffhandTotem, S_OffhandShield};
			if (!offhandSmart) {
				CgLabel(S_OffhandItem);
				ComboT("##offitem", &offhandItem, items, IM_ARRAYSIZE(items));
			}
			CgLabel(S_OffhandDelay);
			CgSliderInt("##offdelay", &offhandDelay, 0, 20);
			ModToggle(MOD_offhandSmart);
			if (offhandSmart) {
				CgLabel(S_OffhandSwapTotem);
				CgSliderFloat("##offtotem", &offhandSwapTotem, 0.0f, 20.0f, "%.0f");
				Tip(S_TipOffhandSwapTotem);
				CgLabel(S_OffhandSwapShield);
				CgSliderFloat("##offshield", &offhandSwapShield, 0.0f, 20.0f, "%.0f");
				Tip(S_TipOffhandSwapShield);
				ModToggle(MOD_offhandSurroundOnly);
			}
			break;
		}
		case MOD_customFov:
			CgLabel(S_CustomFovValue);
			CgSliderFloat("##customfov", &customFovValue, 1.0f, 359.0f, "%.0f");
			break;
		case MOD_pearlTracker:
			CgChildToggles(mod);
			CgLabel(S_Color);
			ImGui::ColorEdit3("##pearlcolor", pearlColor, ImGuiColorEditFlags_NoInputs);
			break;
		case MOD_logSpot:
			CgChildToggles(mod);
			CgLabel(S_LogSpotMinutes);
			CgSliderInt("##logmin", &logSpotMinutes, 1, 60);
			CgLabel(S_Color);
			ImGui::ColorEdit3("##logcolor", logSpotColor, ImGuiColorEditFlags_NoInputs);
			break;
		case MOD_waypoints:
			CgChildToggles(mod);
			DrawWaypointSettings(-1.0f);
			break;
		case MOD_screenTint:
			CgLabel(S_TintColor);
			ImGui::ColorEdit4("##tint", screenTintColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
			break;
		case MOD_targetHud:
			CgLabel(S_TargetRange);
			CgSliderFloat("##targetrange", &targetHudRange, 3.0f, 30.0f, "%.0f");
			Tip(S_TipTargetRange);
			CgChildToggles(mod);
			break;
		case MOD_itemCounter: case MOD_hudInfo:
			CgChildToggles(mod);
			break;
		case MOD_sessionHud:
			if (ImGui::Button(TL(S_SessionReset), ImVec2(-1, 0))) VisualsResetSession();
			break;
		case MOD_fakePlayer:
			DrawFakePlayerSettings(-1.0f, true);
			break;
		case MOD_customText:
			ChatTextField(S_CustomTextValue, &customTextValue, -1.0f);
			CgLabel(S_TextSize);
			CgSliderFloat("##textsize", &customTextSize, 0.5f, 3.0f, "%.2fx");
			break;
		case MOD_hudImage:
			CgLabel(S_ImageScale);
			CgSliderFloat("##imgscale", &hudImageScale, 0.1f, 4.0f, "%.2fx");
			CgLabel(S_Opacity);
			CgSliderFloat("##imgopacity", &hudImageOpacity, 0.05f, 1.0f, "%.2f");
			DrawHudImageReload();
			break;
		case MOD_gatoFly:
			CgLabel(S_FlyHSpeed);
			CgSliderFloat("##flyh", &flyHSpeed, 0.2f, 3.0f, "%.2f");
			CgLabel(S_FlyVSpeed);
			CgSliderFloat("##flyv", &flyVSpeed, 0.2f, 3.0f, "%.2f");
			CgChildToggles(mod);
			if (flyAntiKick) {
				CgLabel(S_FlyKickInterval);
				CgSliderFloat("##flykicki", &flyKickInterval, 0.5f, 3.0f, "%.2f");
				CgLabel(S_FlyKickAmount);
				CgSliderFloat("##flykicka", &flyKickAmount, 0.01f, 0.3f, "%.2f");
			} else {
				CgLabel(S_FlyGlide);
				CgSliderFloat("##flyglide", &flyGlide, -0.15f, 0.0f, "%.3f");
			}
			if (flyDynamic) {
				CgLabel(S_FlyHDynamic);
				CgSliderFloat("##flyhd", &flyHDynamic, 0.5f, 2.0f, "%.2f");
				CgLabel(S_FlyVDynamic);
				CgSliderFloat("##flyvd", &flyVDynamic, 0.5f, 2.0f, "%.2f");
			}
			break;
		case MOD_bypassFly: {
			ModToggle(MOD_flyLookControl);
			struct BfSlider { StrId label; float* value; float min, max; const char* format; };
			const BfSlider sliders[] = {
				{S_BfInitialH, &bfInitialH, 0.1f, 3.0f, "%.4f"}, {S_BfInitialV, &bfInitialV, 0.1f, 3.0f, "%.4f"},
				{S_BfInitBypH, &bfInitBypH, 0.1f, 3.0f, "%.4f"}, {S_BfInitBypV, &bfInitBypV, 0.1f, 3.0f, "%.4f"},
				{S_BfFinalH, &bfFinalH, 0.1f, 3.0f, "%.4f"}, {S_BfFinalV, &bfFinalV, 0.1f, 3.0f, "%.4f"},
				{S_BfFinalBypH, &bfFinalBypH, 0.1f, 3.0f, "%.4f"}, {S_BfFinalBypV, &bfFinalBypV, 0.1f, 3.0f, "%.4f"},
				{S_FlyGlide, &bfGlide, -0.2f, 0.2f, "%.4f"}, {S_BfReleaseDelay, &bfReleaseDelay, 0.0f, 0.5f, "%.2f"},
				{S_BfDescentSpeed, &bfDescentSpeed, 0.1f, 5.0f, "%.4f"},
				{S_BfDescentHorizontal, &bfDescentHorizontal, 0.0f, 3.0f, "%.2f"},
				{S_BfOnlyShift, &bfOnlyShift, 0.0f, 5.0f, "%.2f"},
			};
			for (const BfSlider& slider : sliders) {
				CgLabel(slider.label);
				ImGui::PushID(slider.value);
				CgSliderFloat("##bf", slider.value, slider.min, slider.max, slider.format);
				ImGui::PopID();
			}
			break;
		}
		case MOD_uiAnimations:
			CgLabel(S_AnimSpeed);
			CgSliderFloat("##animspeed", &uiAnimSpeed, 0.25f, 3.0f, "%.2fx");
			break;
		case MOD_uiBgImage:
			CgLabel(S_ImageOpacity);
			CgSliderFloat("##imgopacity", &uiBgImageOpacity, 0.05f, 1.0f, "%.2f");
			if (ImGui::Button(TL(S_ReloadImage), ImVec2(-1, 0))) LoadBackgroundImage();
			if (!g_bgTexture) {
				ImGui::PushTextWrapPos(0.0f);
				ImGui::TextColored(GatyoState::Danger, "%s", T(S_ImageMissing));
				ImGui::PopTextWrapPos();
			}
			break;
		case MOD_notifEnabled: {
			CgLabel(S_NotifDuration);
			CgSliderFloat("##notiftime", &notifDuration, 1.5f, 10.0f, "%.1f");
			static const StrId positions[] = {S_PosBottomRight, S_PosTopRight};
			CgLabel(S_NotifPosition);
			ComboT("##notifpos", &notifPosition, positions, IM_ARRAYSIZE(positions));
			break;
		}
	}
	ImGui::PopItemWidth();
	ImGui::PopID();
}

// Ajustes de la categoria que no son modulos (valores, combos, accesos).
static bool CgHasPageExtras(int page) {
	return page == PAGE_MOVEMENT || page == PAGE_COMBAT || page == PAGE_PLAYERS || page == PAGE_VISUALS ||
	       page == PAGE_HUD || page == PAGE_OTHER || page == PAGE_APPEARANCE;
}

static const char* const kCgLookKeys[] = {
	"cgTextScale", "cgRowScale", "cgHeaderStyle", "cgBackdropDim", "cgWidthScale",
};

// Muestras de acento en filas que se parten segun el ancho de la ventana.
static void CgAccentSwatches() {
	static const StrId presetNames[] = {S_AccentViolet, S_AccentPink, S_AccentLavender, S_AccentCyan, S_AccentMint, S_AccentAmber, S_AccentCoral};
	ImGuiStyle& style = ImGui::GetStyle();
	float size = ImGui::GetFrameHeight();
	float avail = ImGui::GetContentRegionAvail().x;
	int perRow = ImMax(1, (int)((avail + style.ItemSpacing.x) / (size + style.ItemSpacing.x)));
	ImGui::ColorEdit3("##accent", uiAccent, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel);
	for (int i = 0; i < IM_ARRAYSIZE(kAccentPresets); i++) {
		if ((i + 1) % perRow != 0) ImGui::SameLine();
		const GatyoAccentPreset& preset = kAccentPresets[i];
		ImGui::PushID(i);
		if (ImGui::ColorButton("##preset", GatyoRgb(preset.r, preset.g, preset.b), ImGuiColorEditFlags_NoTooltip, ImVec2(size, size))) {
			uiAccent[0] = preset.r / 255.0f;
			uiAccent[1] = preset.g / 255.0f;
			uiAccent[2] = preset.b / 255.0f;
		}
		Tip(presetNames[i]);
		ImGui::PopID();
	}
}

// Ventana "Apariencia" del ClickGUI: tamaño, colores, ventanas y fondo.
static void CgLookSettings() {
	CgLabel(S_CgTextSize);
	static float pendingText = 1.0f;
	CgSliderFloat("##cgtext", &pendingText, 0.8f, 1.4f, "%.2fx");
	// se aplica al soltar: cambiar el tamaño mientras se arrastra mueve el slider
	if (ImGui::IsItemDeactivatedAfterEdit()) cgTextScale = pendingText;
	if (!ImGui::IsItemActive()) pendingText = cgTextScale;
	CgLabel(S_CgRowHeight);
	static float pendingRow = 1.0f;
	CgSliderFloat("##cgrow", &pendingRow, 0.8f, 1.6f, "%.2fx");
	if (ImGui::IsItemDeactivatedAfterEdit()) cgRowScale = pendingRow;
	if (!ImGui::IsItemActive()) pendingRow = cgRowScale;
	CgLabel(S_CgWindowWidth);
	static float pendingWidth = 1.0f;
	CgSliderFloat("##cgwidth", &pendingWidth, 0.6f, 1.6f, "%.2fx");
	if (ImGui::IsItemDeactivatedAfterEdit()) cgWidthScale = pendingWidth;
	if (!ImGui::IsItemActive()) pendingWidth = cgWidthScale;

	SectionTitle(S_CgSectionColors);
	static const StrId themes[] = {S_ThemeGatyo, S_ThemeDark, S_ThemeLight, S_ThemeManual};
	CgLabel(S_SectionTheme);
	ComboT("##cgtheme", &uiTheme, themes, IM_ARRAYSIZE(themes));
	if (uiTheme == 3) {
		ColorEditT(S_ManualBg, uiManualBg);
		ColorEditT(S_ManualPanel, uiManualPanel);
		ColorEditT(S_ManualBorder, uiManualBorder);
		ColorEditT(S_ManualText, uiManualText);
		ColorEditT(S_ManualMuted, uiManualMuted);
		ColorEditT(S_ManualSecondary, uiManualSecondary);
		ColorEditT(S_ManualOff, uiManualOff);
	}
	CgLabel(S_SectionAccent);
	CgAccentSwatches();
	static const StrId headers[] = {S_CgHeaderGlass, S_CgHeaderAccent, S_CgHeaderGradient};
	CgLabel(S_CgHeaderStyle);
	ComboT("##cgheader", &cgHeaderStyle, headers, IM_ARRAYSIZE(headers));

	SectionTitle(S_CgSectionWindows);
	CgLabel(S_GlassOpacity);
	CgSliderFloat("##cgglass", &uiGlassOpacity, 0.3f, 1.0f, "%.2f");
	CgLabel(S_GlassBlur);
	CgSliderInt("##cgblur", &uiGlassBlur, 0, 60, "%d px");
	Tip(S_TipGlassBlur);
	CgLabel(S_CgBackdropDim);
	CgSliderFloat("##cgdim", &cgBackdropDim, 0.0f, 0.85f, "%.2f");
	Tip(S_TipCgBackdrop);

	SectionTitle(S_SectionBackground);
	CgLabel(S_BgStyle);
	ComboT("##cgbg", &uiBgStyle, kBackgroundNames, BG_COUNT);
	if (uiBgStyle != BG_NONE) {
		CgLabel(S_BgIntensity);
		CgSliderFloat("##cgbgint", &uiBgIntensity, 0.1f, 1.0f, "%.2f");
		if (uiBgStyle == BG_DOTS || uiBgStyle == BG_PARTICLES || uiBgStyle == BG_STARS) {
			CgLabel(S_DotsDensity);
			CgSliderInt("##cgbgdensity", &uiBgDotsDensity, 20, 400);
		}
	}

	ImGui::Dummy(ImVec2(0, 4.0f * scaleGlobal));
	if (ImGui::Button(TL(S_CgResetLook), ImVec2(-1, 0))) {
		applyDefaults(kCgLookKeys, IM_ARRAYSIZE(kCgLookKeys));
		Notify(T(S_NotifyCgReset), NOTIFY_INFO);
	}
}

static void CgPageExtras(int page) {
	ImGui::PushItemWidth(-1);
	switch (page) {
		case PAGE_MOVEMENT:
			if (isLANGame) break;
			CgLabel(S_WalkSpeed);
			CgDragInt("##walk", &speedValue, 0.05f, 1, 50);
			CgLabel(S_WaterSpeed);
			CgDragInt("##water", &waterSpeedValue, 0.05f, 1, 50);
			CgLabel(S_LavaSpeed);
			CgDragInt("##lava", &lavaSpeedValue, 0.05f, 1, 50);
			CgLabel(S_JumpBoost);
			CgDragFloat("##jump", &jumpValue, 0.05f, 1, 50, "%.0f");
			CgLabel(S_Gravity);
			CgSliderFloat("##gravity", &gravityValue, -0.08, 0.08, "%.2f");
			Tip(S_TipGravity);
			break;
		case PAGE_COMBAT:
		case PAGE_PLAYERS:
			if (ImGui::Button(TL(S_OpenInPanel), ImVec2(-1, 0))) CgOpenInPanel(page);
			break;
		case PAGE_VISUALS: {
			static const StrId fogModes[] = {S_FogOff, S_FogClear, S_FogWeather, S_FogWater, S_FogLava, S_FogLavaFireRes, S_FogPowderSnow};
			CgLabel(S_FogMode);
			ComboT("##fog", &fogState, fogModes, IM_ARRAYSIZE(fogModes));
			static const StrId chamsModes[] = {S_ChamsOff, S_ChamsDefault, S_ChamsShading, S_ChamsWireframe, S_ChamsOutline, S_ChamsVisOutline, S_ChamsVisShading, S_ChamsVisBoth};
			CgLabel(S_Chams);
			ComboT("##chams", &chamsint, chamsModes, IM_ARRAYSIZE(chamsModes));
			CgLabel(S_GameFontSize);
			CgSliderInt("##font", &fontSize, 0, 10);
			if (ImGui::Button(TL(S_OpenInPanel), ImVec2(-1, 0))) CgOpenInPanel(page);
			break;
		}
		case PAGE_HUD:
			if (AccentButton(TL(S_OpenHudEditor), ImVec2(-1, 0))) g_hudEditor = true;
			break;
		case PAGE_OTHER:
			CgLabel(S_HostMaxPlayers);
			CgDragInt("##maxplayers", &myMaxPlayers, 0.05f, 1, 1000);
			Tip(S_TipHostMax);
			CgLabel(S_TabQuickCommands);
			DrawTextList(quickCommands, S_QuickCommandTitle, -1.0f, SendQuickCommand);
			if (ImGui::Button(TL(S_SectionScreenButtons), ImVec2(-1, 0))) CgOpenInPanel(PAGE_KEYBINDS);
			break;
		case PAGE_APPEARANCE:
			CgLookSettings();
			break;
	}
	ImGui::PopItemWidth();
}

// Chevron: apunta a la derecha (cerrado) y gira hacia abajo al abrirse.
static void CgChevron(ImDrawList* dl, ImVec2 center, float size, float open, ImU32 color) {
	float angle = open * IM_PI * 0.5f;
	ImVec2 pts[3] = {ImVec2(-0.35f, -0.6f), ImVec2(0.45f, 0.0f), ImVec2(-0.35f, 0.6f)};
	for (ImVec2& p : pts) {
		float x = p.x * cosf(angle) - p.y * sinf(angle);
		float y = p.x * sinf(angle) + p.y * cosf(angle);
		p = ImVec2(center.x + x * size, center.y + y * size);
	}
	dl->AddTriangleFilled(pts[0], pts[1], pts[2], color);
}

// Fila de modulo. Tocar el nombre lo activa; la zona de la flecha despliega
// sus ajustes. Se activa al soltar, y no si el toque se uso para desplazar.
static void CgModuleRow(int mod, float width) {
	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems) return;
	const ModuleInfo& m = kModules[mod];
	GatyoPalette p = GatyoGetPalette();
	ImGuiStyle& style = ImGui::GetStyle();

	float height = ImGui::GetFrameHeight() * 1.15f * cgRowScale;
	bool hasSettings = CgHasSettings(mod);
	float arrowWidth = hasSettings ? height * 1.1f : 0.0f;
	ImVec2 pos = window->DC.CursorPos;
	ImRect rowBb(pos, ImVec2(pos.x + width, pos.y + height));
	ImRect mainBb(pos, ImVec2(rowBb.Max.x - arrowWidth, rowBb.Max.y));
	ImRect arrowBb(ImVec2(mainBb.Max.x, pos.y), rowBb.Max);

	ImGuiID id = window->GetID(m.key);
	ImGuiID arrowId = window->GetID((std::string(m.key) + "_arrow").c_str());
	ImGui::ItemSize(rowBb);
	if (!ImGui::ItemAdd(rowBb, id)) return;

	bool blocked = ModuleBlocked(mod);
	bool hovered, held;
	bool pressed = ImGui::ButtonBehavior(mainBb, id, &hovered, &held, ImGuiButtonFlags_PressedOnRelease);
	if (held) g_touchPressedItem = id;
	if (pressed && !g_touchScrolled && !blocked) ToggleModuleFromShortcut(mod);

	bool arrowHovered = false, arrowHeld = false;
	if (hasSettings) {
		ImGui::KeepAliveID(arrowId);
		if (ImGui::ButtonBehavior(arrowBb, arrowId, &arrowHovered, &arrowHeld, ImGuiButtonFlags_PressedOnRelease) && !g_touchScrolled) {
			g_cgExpanded[mod] = !g_cgExpanded[mod];
		}
		if (arrowHeld) g_touchPressedItem = arrowId;
	}

	bool on = *m.value;
	float* anim = window->StateStorage.GetFloatRef(id, on ? 1.0f : 0.0f);
	if (uiAnimations) *anim += ((on ? 1.0f : 0.0f) - *anim) * ImMin(1.0f, ImGui::GetIO().DeltaTime * 14.0f * uiAnimSpeed);
	else *anim = on ? 1.0f : 0.0f;
	float* arrowAnim = window->StateStorage.GetFloatRef(arrowId, g_cgExpanded[mod] ? 1.0f : 0.0f);
	float arrowTarget = g_cgExpanded[mod] ? 1.0f : 0.0f;
	if (uiAnimations) *arrowAnim += (arrowTarget - *arrowAnim) * ImMin(1.0f, ImGui::GetIO().DeltaTime * 16.0f * uiAnimSpeed);
	else *arrowAnim = arrowTarget;

	ImDrawList* dl = window->DrawList;
	if (*anim > 0.01f) dl->AddRectFilled(rowBb.Min, rowBb.Max, GatyoU32(GatyoAlpha(p.accent, 0.28f * *anim)));
	if (hovered || arrowHovered) dl->AddRectFilled(rowBb.Min, rowBb.Max, GatyoU32(GatyoAlpha(p.hover, held || arrowHeld ? 0.45f : 0.22f)));
	if (*anim > 0.01f) {
		int start = dl->VtxBuffer.Size;
		float barWidth = 3.0f * scaleGlobal * *anim;
		dl->AddRectFilled(rowBb.Min, ImVec2(rowBb.Min.x + barWidth, rowBb.Max.y), GatyoU32(ImVec4(1, 1, 1, 1)));
		GatyoShadeVerts(dl, start, dl->VtxBuffer.Size, true);
	}

	ImVec4 textColor = GatyoMix(p.muted, p.text, *anim);
	if (blocked) textColor.w *= 0.45f;
	float textY = pos.y + (height - ImGui::GetFontSize()) * 0.5f;
	ImVec2 textMin(pos.x + style.FramePadding.x + 4.0f * scaleGlobal, textY);
	float textMaxX = mainBb.Max.x - 4.0f * scaleGlobal;
	ImGui::PushStyleColor(ImGuiCol_Text, textColor);
	ImGui::RenderTextEllipsis(dl, textMin, ImVec2(textMaxX, rowBb.Max.y), textMaxX, textMaxX, ModName(mod), NULL, NULL);
	ImGui::PopStyleColor();
	if (hasSettings) {
		ImU32 chevron = GatyoU32(arrowHovered ? p.accent : GatyoAlpha(p.muted, 0.9f));
		CgChevron(dl, arrowBb.GetCenter(), height * 0.16f, *arrowAnim, chevron);
	}
	if (hovered) Tip(blocked ? T(S_BlockedByAntiCheat) : ModDesc(mod));

	if (g_cgExpanded[mod] && hasSettings) {
		ImGui::Dummy(ImVec2(0, 2.0f * scaleGlobal));
		float indent = 10.0f * scaleGlobal;
		ImVec2 guideTop = ImGui::GetCursorScreenPos();
		ImGui::Indent(indent);
		ImGui::PushItemWidth(width - indent * 2.0f);
		ImGui::BeginGroup();
		CgModuleSettings(mod);
		ImGui::EndGroup();
		ImGui::PopItemWidth();
		ImGui::Unindent(indent);
		float guideBottom = ImGui::GetItemRectMax().y;
		dl->AddLine(ImVec2(guideTop.x + indent * 0.4f, guideTop.y), ImVec2(guideTop.x + indent * 0.4f, guideBottom), GatyoU32(GatyoAlpha(p.accent, 0.6f)), ImMax(1.0f, 1.5f * scaleGlobal));
		ImGui::Dummy(ImVec2(0, 4.0f * scaleGlobal));
	}
}

// Distribucion por defecto. El ancho sale del nombre mas largo, multiplicado
// por el ajuste "Ancho de ventanas" (por debajo de 1x los nombres se recortan);
// si no entran todas en una fila se parten en varias y cada fila limita el
// alto de sus ventanas para no pisarse.
struct CgLayout {
	float width;
	int perRow;
	int rows;
	float rowHeight;
	float top;
};
static CgLayout g_cgLayout;

static float CgRowHeight() {
	return CgFrameHeight() * 1.15f * cgRowScale;
}

static void CgComputeLayout(float top) {
	ImGuiStyle& style = ImGui::GetStyle();
	float pad = 6.0f * scaleGlobal;
	float arrow = CgRowHeight() * 1.1f;
	float needed = 0.0f;
	for (int i = 0; i < MOD_COUNT; i++) {
		if (CgParentOf(i) >= 0) continue;
		needed = ImMax(needed, ImGui::CalcTextSize(ModName(i)).x * cgTextScale);
	}
	needed += style.FramePadding.x * 2.0f + 8.0f * scaleGlobal + arrow + pad * 2.0f;
	for (int slot = 0; slot < kCgPageCount; slot++) {
		float title = ImGui::CalcTextSize(T(kPageNames[kCgPages[slot]])).x * 1.1f * cgTextScale;
		needed = ImMax(needed, title + ImGui::CalcTextSize("00/00").x * cgTextScale + CgFrameHeight() * 1.35f + 30.0f * scaleGlobal);
	}

	float margin = 16.0f * scaleGlobal;
	float gap = 12.0f * scaleGlobal;
	CgLayout layout;
	layout.width = ImClamp(needed * cgWidthScale, 120.0f * scaleGlobal, screenWidth * 0.45f);
	layout.perRow = ImMax(1, (int)((screenWidth - margin * 2.0f + gap) / (layout.width + gap)));
	layout.rows = (kCgPageCount + layout.perRow - 1) / layout.perRow;
	layout.top = top;
	layout.rowHeight = (screenHeight - top - margin) / layout.rows;
	g_cgLayout = layout;
}

static ImVec2 CgDefaultPos(int slot) {
	const CgLayout& l = g_cgLayout;
	float gap = 12.0f * scaleGlobal;
	int row = slot / l.perRow;
	int column = slot % l.perRow;
	int inRow = ImMin(l.perRow, kCgPageCount - row * l.perRow);
	float rowWidth = inRow * l.width + (inRow - 1) * gap;
	float startX = (screenWidth - rowWidth) * 0.5f;
	return ImVec2(startX + column * (l.width + gap), l.top + row * l.rowHeight);
}

static void CgArrangeWindows() {
	for (int i = 0; i < PAGE_COUNT; i++) {
		cgWindowX[i] = cgWindowY[i] = -1;
		cgWindowCollapsed[i] = false;
	}
}

static std::vector<int> CgPageModules(int page, const std::string& query) {
	std::vector<int> mods;
	for (int i = 0; i < MOD_COUNT; i++) {
		if (kModules[i].page != page) continue;
		if (query.empty()) {
			if (CgParentOf(i) >= 0) continue;
		} else if (!ModuleMatches(i, query)) {
			continue;
		}
		mods.push_back(i);
	}
	return mods;
}

// Texto legible sobre un encabezado de color: oscuro si el fondo es claro.
static ImVec4 CgTextOn(ImVec4 bg) {
	float luminance = bg.x * 0.299f + bg.y * 0.587f + bg.z * 0.114f;
	return luminance > 0.62f ? GatyoRgb(28, 16, 44) : GatyoRgb(250, 244, 255);
}

static void DrawCgWindow(int page, int slot, const std::string& query) {
	std::vector<int> mods = CgPageModules(page, query);
	if (!query.empty() && mods.empty()) return;

	GatyoPalette p = GatyoGetPalette();
	ImGuiIO& io = ImGui::GetIO();
	float width = g_cgLayout.width;
	float headerHeight = CgFrameHeight() * 1.35f;
	float pad = 6.0f * scaleGlobal;

	bool autoPlaced = cgWindowX[page] < 0;
	ImVec2 pos = autoPlaced ? CgDefaultPos(slot) : ImVec2(cgWindowX[page], cgWindowY[page]);
	pos.x = ImClamp(pos.x, -width + 60.0f * scaleGlobal, screenWidth - 60.0f * scaleGlobal);
	pos.y = ImClamp(pos.y, 0.0f, screenHeight - headerHeight);

	bool collapsed = cgWindowCollapsed[page] && query.empty();
	float& extend = g_cgExtend[page];
	float target = collapsed ? 0.0f : 1.0f;
	if (uiAnimations) extend += (target - extend) * ImMin(1.0f, io.DeltaTime * 12.0f * uiAnimSpeed);
	else extend = target;
	if (fabsf(extend - target) < 0.005f) extend = target;

	float maxBody = ImMax(0.0f, screenHeight - pos.y - headerHeight - 16.0f * scaleGlobal);
	if (autoPlaced && g_cgLayout.rows > 1) maxBody = ImMin(maxBody, g_cgLayout.rowHeight - headerHeight - 12.0f * scaleGlobal);
	float bodyHeight = ImMin(g_cgContentHeight[page], maxBody) * extend;

	char name[32];
	snprintf(name, sizeof(name), "##cg_window_%d", page);
	ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
	ImGui::SetNextWindowSize(ImVec2(width, headerHeight + bodyHeight), ImGuiCond_Always);
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
	ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
	                         ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollWithMouse;
	bool visible = ImGui::Begin(name, NULL, flags);
	ImGui::PopStyleVar();
	if (!visible) {
		ImGui::End();
		return;
	}
	ImGui::SetWindowFontScale(cgTextScale);
	ImDrawList* dl = ImGui::GetWindowDrawList();
	ImVec2 max(pos.x + width, pos.y + headerHeight + bodyHeight);
	ImVec2 headerMax(max.x, pos.y + headerHeight);

	// vidrio de la ventana completa y encabezado segun el estilo elegido
	dl->AddRectFilled(pos, max, GatyoU32(GatyoAlpha(p.bg, ImClamp(uiGlassOpacity, 0.2f, 1.0f))));
	ImVec4 headerText = p.muted;
	if (cgHeaderStyle == 1) {
		dl->AddRectFilled(pos, headerMax, GatyoU32(GatyoAlpha(p.accent, ImMin(1.0f, uiGlassOpacity + 0.05f))));
		headerText = CgTextOn(p.accent);
	} else if (cgHeaderStyle == 2) {
		int start = dl->VtxBuffer.Size;
		dl->AddRectFilled(pos, headerMax, GatyoU32(ImVec4(1, 1, 1, ImMin(1.0f, uiGlassOpacity + 0.05f))));
		GatyoShadeVerts(dl, start, dl->VtxBuffer.Size, false);
		headerText = CgTextOn(p.accent);
	} else {
		dl->AddRectFilled(pos, headerMax, GatyoU32(GatyoAlpha(p.panel, ImMin(1.0f, uiGlassOpacity + 0.1f))));
	}
	dl->AddRect(pos, max, GatyoU32(GatyoAlpha(p.border, 0.9f)), 0.0f, 0, ImMax(1.0f, scaleGlobal));
	if (cgHeaderStyle == 0) {
		int flowStart = dl->VtxBuffer.Size;
		dl->AddRectFilled(ImVec2(pos.x, pos.y + headerHeight - 2.0f * scaleGlobal), headerMax, GatyoU32(ImVec4(1, 1, 1, 1)));
		GatyoShadeVerts(dl, flowStart, dl->VtxBuffer.Size, false);
	}

	float titleSize = ImGui::GetFontSize() * 1.1f;
	int active = 0;
	for (int mod : mods) active += *kModules[mod].value ? 1 : 0;
	char count[16];
	snprintf(count, sizeof(count), "%d/%d", active, (int)mods.size());
	float countWidth = ImGui::CalcTextSize(count).x;
	float chevronSpace = headerHeight * 0.7f;
	float countX = max.x - chevronSpace - countWidth - 6.0f * scaleGlobal;
	dl->PushClipRect(pos, ImVec2(countX - 6.0f * scaleGlobal, pos.y + headerHeight), true);
	ImVec2 titlePos(pos.x + 12.0f * scaleGlobal, pos.y + (headerHeight - titleSize) * 0.5f);
	if (cgHeaderStyle == 0) GatyoFlowText(dl, titlePos, T(kPageNames[page]), titleSize, 1.0f, false);
	else dl->AddText(NULL, titleSize, titlePos, GatyoU32(headerText), T(kPageNames[page]));
	dl->PopClipRect();
	ImU32 headerMuted = GatyoU32(cgHeaderStyle == 0 ? p.muted : GatyoAlpha(headerText, 0.8f));
	dl->AddText(ImVec2(max.x - chevronSpace - countWidth - 6.0f * scaleGlobal, pos.y + (headerHeight - ImGui::GetFontSize()) * 0.5f), headerMuted, count);
	CgChevron(dl, ImVec2(max.x - chevronSpace * 0.55f, pos.y + headerHeight * 0.5f), headerHeight * 0.13f, extend, headerMuted);

	// encabezado: arrastrar mueve la ventana, tocar la pliega
	ImGui::SetCursorScreenPos(pos);
	ImGui::InvisibleButton("##header", ImVec2(width, headerHeight));
	if (ImGui::IsItemActive() && !ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
		if (ImGui::IsMouseDragging(ImGuiMouseButton_Left, 14.0f * scaleGlobal)) g_cgHeaderDragged = true;
		if (g_cgHeaderDragged) {
			cgWindowX[page] = pos.x + io.MouseDelta.x;
			cgWindowY[page] = pos.y + io.MouseDelta.y;
		}
	}
	if (ImGui::IsItemDeactivated() && !g_cgHeaderDragged && query.empty()) {
		cgWindowCollapsed[page] = !cgWindowCollapsed[page];
	}
	Tip(S_TipCgHeader);

	if (bodyHeight > 1.0f) {
		ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + headerHeight));
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(pad, pad));
		ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(ImGui::GetStyle().ItemSpacing.x, 3.0f * scaleGlobal));
		ImGui::BeginChild("##body", ImVec2(width, bodyHeight), false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_AlwaysUseWindowPadding);
		float rowWidth = width - pad * 2.0f;
		for (int mod : mods) CgModuleRow(mod, rowWidth);

		if (query.empty() && CgHasPageExtras(page)) {
			ImGui::Dummy(ImVec2(0, 4.0f * scaleGlobal));
			SectionTitle(page == PAGE_APPEARANCE ? S_CgSectionSize : S_CgSettings);
			CgPageExtras(page);
		}
		g_cgContentHeight[page] = ImGui::GetCursorPosY() + pad;

		TouchScroll(true);
		// indicador de desplazamiento
		float scrollMax = ImGui::GetScrollMaxY();
		if (scrollMax > 0.5f) {
			float visible = bodyHeight / (bodyHeight + scrollMax);
			float barHeight = bodyHeight * visible;
			float barY = pos.y + headerHeight + (bodyHeight - barHeight) * (ImGui::GetScrollY() / scrollMax);
			ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(max.x - 3.0f * scaleGlobal, barY), ImVec2(max.x - 1.0f, barY + barHeight), GatyoU32(GatyoAlpha(p.accent, 0.6f)));
		}
		ImGui::EndChild();
		ImGui::PopStyleVar(2);
	}
	ImGui::End();
}

// Barra superior centrada: marca, buscador y acciones.
static float DrawCgTopBar() {
	GatyoPalette p = GatyoGetPalette();
	ImGuiStyle& style = ImGui::GetStyle();
	float u = CgUnit();
	float margin = 14.0f * scaleGlobal;
	float searchWidth = 300.0f * u;
	const char* labels[] = {TL(S_OpenHudEditor), TL(S_ArrangeWindows), TL(S_LayoutPanel), TL(S_Close)};
	float buttons = 0.0f;
	for (const char* l : labels) buttons += ImGui::CalcTextSize(l, NULL, true).x + style.FramePadding.x * 2.0f + style.ItemSpacing.x;
	float brandSize = ImGui::GetFontSize() * 1.3f;
	float brandWidth = ImGui::CalcTextSize("gatyo").x * 1.3f + style.ItemSpacing.x * 2.0f;
	float width = brandWidth + searchWidth + buttons + style.WindowPadding.x * 2.0f;
	float height = ImGui::GetFrameHeight() + style.WindowPadding.y * 2.0f;
	ImVec2 pos((screenWidth - width) * 0.5f, margin);

	ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
	ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_Always);
	ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove;
	if (ImGui::Begin("##cg_topbar", NULL, flags)) {
		ImDrawList* dl = ImGui::GetWindowDrawList();
		GatyoGlassPanel(dl, pos, ImVec2(pos.x + width, pos.y + height));
		ImVec2 cursor = ImGui::GetCursorScreenPos();
		GatyoFlowText(dl, ImVec2(cursor.x, pos.y + (height - brandSize) * 0.5f), "gatyo", brandSize, 1.0f, false);
		ImGui::Dummy(ImVec2(brandWidth - style.ItemSpacing.x, ImGui::GetFrameHeight()));
		ImGui::SameLine();
		DrawSearchField(searchWidth);
		ImGui::SameLine();
		if (ImGui::Button(labels[0])) g_hudEditor = true;
		ImGui::SameLine();
		if (ImGui::Button(labels[1])) {
			CgArrangeWindows();
			Notify(T(S_NotifyArranged), NOTIFY_INFO);
		}
		ImGui::SameLine();
		if (ImGui::Button(labels[2])) uiLayout = 0;
		ImGui::SameLine();
		ImGui::PushStyleColor(ImGuiCol_Button, GatyoAlpha(p.accent, 0.75f));
		if (ImGui::Button(labels[3])) {
			g_cgOpen = false;
			g_cgOpenTime = ImGui::GetTime();
		}
		ImGui::PopStyleColor();
	}
	ImGui::End();
	return pos.y + height;
}

// Burbuja flotante con el ClickGUI cerrado: tocarla lo abre, arrastrarla la mueve.
static void DrawCgBubble() {
	GatyoPalette p = GatyoGetPalette();
	ImGuiIO& io = ImGui::GetIO();
	float size = 64.0f * scaleGlobal * uiScale;
	ImVec2 pos(cgBubbleX < 0 ? screenWidth - size - 24.0f * scaleGlobal : cgBubbleX,
	           cgBubbleY < 0 ? screenHeight * 0.30f : cgBubbleY);
	pos.x = ImClamp(pos.x, 0.0f, screenWidth - size);
	pos.y = ImClamp(pos.y, 0.0f, screenHeight - size);

	ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
	ImGui::SetNextWindowSize(ImVec2(size, size), ImGuiCond_Always);
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
	ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove;
	if (ImGui::Begin("##cg_bubble", NULL, flags)) {
		g_window = ImGui::GetCurrentWindow();
		ImDrawList* dl = ImGui::GetWindowDrawList();
		ImVec2 max(pos.x + size, pos.y + size);
		ImGui::SetCursorScreenPos(pos);
		ImGui::InvisibleButton("##bubble", ImVec2(size, size));
		bool hovered = ImGui::IsItemHovered();
		if (ImGui::IsItemActive() && !ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
			if (ImGui::IsMouseDragging(ImGuiMouseButton_Left, 14.0f * scaleGlobal)) g_cgHeaderDragged = true;
			if (g_cgHeaderDragged) {
				cgBubbleX = pos.x + io.MouseDelta.x;
				cgBubbleY = pos.y + io.MouseDelta.y;
			}
		}
		if (ImGui::IsItemDeactivated() && !g_cgHeaderDragged) {
			g_cgOpen = true;
			g_cgOpenTime = ImGui::GetTime();
		}

		dl->AddRectFilled(pos, max, GatyoU32(GatyoAlpha(p.bg, ImMin(1.0f, uiGlassOpacity + 0.05f))));
		if (hovered) dl->AddRectFilled(pos, max, GatyoU32(GatyoAlpha(p.hover, 0.3f)));
		int start = dl->VtxBuffer.Size;
		float border = ImMax(2.0f, 2.5f * scaleGlobal);
		dl->AddRect(pos, max, GatyoU32(ImVec4(1, 1, 1, 1)), 0.0f, 0, border);
		GatyoShadeVerts(dl, start, dl->VtxBuffer.Size, false);
		float glyph = size * 0.62f;
		float glyphWidth = ImGui::CalcTextSize("g").x * (glyph / ImGui::GetFontSize());
		GatyoFlowText(dl, ImVec2(pos.x + (size - glyphWidth) * 0.5f, pos.y + (size - glyph) * 0.42f), "g", glyph, 1.0f, false);
		Tip(S_CgOpenGatyo);
	}
	ImGui::End();
	ImGui::PopStyleVar();
}

void DrawClickGui() {
	if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) g_cgHeaderDragged = false;
	if (!g_cgExtendReady) {
		for (int i = 0; i < PAGE_COUNT; i++) {
			g_cgExtend[i] = cgWindowCollapsed[i] ? 0.0f : 1.0f;
			g_cgContentHeight[i] = 300.0f * scaleGlobal;
		}
		g_cgExtendReady = true;
	}

	if (!g_cgOpen) {
		DrawCgBubble();
		return;
	}

	GatyoPalette p = GatyoGetPalette();
	ImGuiIO& io = ImGui::GetIO();
	ImGui::PushStyleVar(ImGuiStyleVar_Alpha, GatyoTransition(g_cgOpenTime, 0.3f));

	// fondo a pantalla completa: atenua el juego y dibuja el fondo elegido.
	// Es la ventana que define el area tactil (toda la pantalla).
	ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
	ImGui::SetNextWindowSize(io.DisplaySize, ImGuiCond_Always);
	ImGuiWindowFlags backdropFlags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
	                                 ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoFocusOnAppearing |
	                                 ImGuiWindowFlags_NoScrollWithMouse;
	if (ImGui::Begin("##cg_backdrop", NULL, backdropFlags)) {
		g_window = ImGui::GetCurrentWindow();
		ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, GatyoU32(GatyoAlpha(p.bg, cgBackdropDim)));
		DrawMenuBackground();
	}
	ImGui::End();

	CgComputeLayout(DrawCgTopBar() + 14.0f * scaleGlobal);
	std::string query = FoldForSearch(g_searchQuery.c_str());
	for (int slot = 0; slot < kCgPageCount; slot++) DrawCgWindow(kCgPages[slot], slot, query);

	ImGui::PopStyleVar();
}
