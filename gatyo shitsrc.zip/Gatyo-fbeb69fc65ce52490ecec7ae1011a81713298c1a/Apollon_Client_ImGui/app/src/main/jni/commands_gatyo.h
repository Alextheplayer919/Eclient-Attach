#pragma once
// Mandar mensajes y comandos como si los escribieras en el chat, y la lista de
// comandos rapidos (un toque desde el menu o un boton en pantalla).
//
// - Comandos ("/..."): MinecraftScreenModel::executeCommand, lo mismo que hace
//   la pantalla de chat. Esa funcion (y el aviso de error que puede mostrar)
//   solo lee el IClientInstance en +80, asi que se le pasa un modelo falso.
// - Mensajes: lo que hace MinecraftScreenModel::sendChatMessage sin la parte
//   de la interfaz: TextPacket::createChat con tu nombre, xuid y platformId,
//   y PacketSender::send. El modulo Chat los transforma como a los tuyos.
//
// Todo se manda desde el hilo del juego (NormalTick): el menu y los packets
// solo encolan.

#include <deque>
#include <optional>

#if defined(__aarch64__)
namespace GatyoSend {
	enum : uintptr_t {
		ScreenModelExecuteCommand = 0x7029FC8,  // MinecraftScreenModel::executeCommand(std::string const&)
		TextPacketCreateChat = 0xA4A6DB8,       // TextPacket::createChat(autor, mensaje, filtrado, xuid, platformId)
		TextPacketDestroy = 0xA4A6B08,          // TextPacket::~TextPacket
	};
	// vtable de ClientInstance (bytes), como los usa sendChatMessage
	static const int kClientPlatformId = 1208;  // std::string por valor
	static const int kClientUser = 1488;        // shared_ptr<...> const&: el usuario con su xuid
	static const int kClientPacketSender = 2400;
	static const int kUserIsGuest = 40;         // vtable del usuario: si da 1 no hay xuid
	static const int kUserXuid = 184;           // vtable del usuario: std::string const& (xuid)
	static const int kSenderSend = 24;          // vtable de PacketSender: send(Packet&)
	static const int kModelClient = 80;         // MinecraftScreenModel -> IClientInstance*
}

// sizeof(TextPacket) es 0xD0; mas de 16 bytes se devuelve por x8, como el juego.
struct GatyoTextPacket {
	alignas(16) uint8_t data[0x100];
};

template <typename T>
static T SendFn(uintptr_t offset) {
	return (T)getAbsoluteAddress(MineLib, offset);
}

static void RunCommandNow(const std::string& command) {
	if (!CI) return;
	alignas(16) void* model[16] = {};
	model[GatyoSend::kModelClient / sizeof(void*)] = CI;
	SendFn<void (*)(void*, const std::string&)>(GatyoSend::ScreenModelExecuteCommand)(model, command);
}

static void SendChatNow(const std::string& message) {
	if (!CI || !localPlayer) return;
	void* client = CI;
	void** vtable = *(void***)client;

	std::string xuid;
	void** user = ((void** (*)(void*))vtable[GatyoSend::kClientUser / 8])(client);
	if (user && user[0]) {
		void** userVtable = *(void***)user[0];
		if (!(((uint64_t (*)(void*))userVtable[GatyoSend::kUserIsGuest / 8])(user[0]) & 1)) {
			const std::string* id = ((const std::string* (*)(void*, int))userVtable[GatyoSend::kUserXuid / 8])(user[0], 1);
			if (id) xuid = *id;
		}
	}
	std::string platformId = ((std::string (*)(void*))vtable[GatyoSend::kClientPlatformId / 8])(client);
	std::string author = localPlayer->getName();
	std::optional<std::string> filtered;

	typedef GatyoTextPacket (*CreateChat)(const std::string&, const std::string&, const std::optional<std::string>&,
	                                      const std::string&, const std::string&);
	GatyoTextPacket packet = SendFn<CreateChat>(GatyoSend::TextPacketCreateChat)(author, message, filtered, xuid, platformId);
	void* sender = ((void* (*)(void*))vtable[GatyoSend::kClientPacketSender / 8])(client);
	if (sender) ((void (*)(void*, void*))(*(void***)sender)[GatyoSend::kSenderSend / 8])(sender, &packet);
	SendFn<void (*)(void*)>(GatyoSend::TextPacketDestroy)(&packet);
}
#endif

static std::mutex g_sendMutex;
static std::deque<std::string> g_sendQueue;
static const size_t kSendQueueMax = 16;

// Desde cualquier hilo. "/..." es un comando; lo demas, un mensaje.
void QueueSend(std::string text) {
	while (!text.empty() && (text.back() == ' ' || text.back() == '\n')) text.pop_back();
	if (text.empty() || text == "/") return;
	std::lock_guard<std::mutex> lock(g_sendMutex);
	if (g_sendQueue.size() < kSendQueueMax) g_sendQueue.push_back(text);
}

// Al salir del mundo: lo pendiente no se manda en el siguiente.
void ClearSendQueue() {
	std::lock_guard<std::mutex> lock(g_sendMutex);
	g_sendQueue.clear();
}

// Desde NormalTick: uno por tick, para no mandar varios mensajes juntos.
void FlushSendQueue() {
	std::string text;
	{
		std::lock_guard<std::mutex> lock(g_sendMutex);
		if (g_sendQueue.empty()) return;
		text = g_sendQueue.front();
		g_sendQueue.pop_front();
	}
#if defined(__aarch64__)
	if (text[0] == '/') RunCommandNow(text);
	else SendChatNow(text);
#endif
}

// Desde el menu o un boton en pantalla (hilo de render).
void SendQuickCommand(const std::string& text) {
	if (inMenu || !localPlayer) {
		errorFunctionSound = true;
		Notify(T(S_NotifyQuickNoWorld), NOTIFY_ERROR);
		return;
	}
	QueueSend(text);
	onFunctionSound = true;
	Notify(TF(S_NotifyQuickSent, text.c_str()), NOTIFY_ON);
}

// Lista de textos editable (mensajes, comandos). Tocar un texto abre el
// teclado. Con `onSend`, cada fila tiene un boton Enviar. Ancho negativo: las
// ventanas angostas del ClickGUI, con los botones debajo del texto.
// La lista cambia con g_textMutex tomado: el hilo del juego la lee y el
// dialogo de texto escribe en sus elementos.
void DrawTextList(std::vector<std::string>& list, StrId title, float width, void (*onSend)(const std::string&) = nullptr) {
	int edit = -1, remove = -1, send = -1;
	bool narrow = width < 0.0f;
	ImGui::PushID(&list);
	for (size_t i = 0; i < list.size(); i++) {
		std::string shown;
		{
			std::lock_guard<std::mutex> lock(g_textMutex);
			shown = list[i];
		}
		std::string label = (shown.empty() ? std::string(T(S_ChatEmpty)) : shown) + "###text";
		ImGui::PushID((int)i);
		if (narrow) {
			if (ImGui::Button(label.c_str(), ImVec2(-1.0f, 0))) edit = (int)i;
			if (onSend) {
				if (AccentButton(TL(S_QuickSend))) send = (int)i;
				ImGui::SameLine();
			}
		} else {
			if (onSend) {
				if (AccentButton(TL(S_QuickSend))) send = (int)i;
				ImGui::SameLine();
			}
			if (ImGui::Button(label.c_str(), ImVec2(width, 0))) edit = (int)i;
			ImGui::SameLine();
		}
		if (ImGui::Button(TL(S_ListRemove))) remove = (int)i;
		ImGui::PopID();
	}
	if (list.empty()) MutedText(T(S_EmptyList));
	bool add = ImGui::Button(TL(S_ListAdd), ImVec2(narrow ? -1.0f : 0.0f, 0));
	ImGui::PopID();

	if (send >= 0 && onSend) {
		std::string text;
		{
			std::lock_guard<std::mutex> lock(g_textMutex);
			text = list[send];
		}
		onSend(text);
	}
	if (remove >= 0 || add) {
		std::lock_guard<std::mutex> lock(g_textMutex);
		ForgetTextTargetIn(list.data(), list.data() + list.size());
		if (remove >= 0) list.erase(list.begin() + remove);
		if (add) {
			list.push_back("");
			edit = (int)list.size() - 1;
		}
	}
	if (edit >= 0 && edit < (int)list.size()) RequestTextInput(T(title), &list[edit]);
}

// Pestaña "Comandos rapidos" de la pagina Otros y su version del ClickGUI.
void DrawQuickCommandsSettings(float width) {
	MutedText(T(S_TipQuickCommands));
	DrawTextList(quickCommands, S_QuickCommandTitle, width, SendQuickCommand);
}
