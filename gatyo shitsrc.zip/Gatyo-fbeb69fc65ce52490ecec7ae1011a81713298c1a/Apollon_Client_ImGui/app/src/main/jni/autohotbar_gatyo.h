#pragma once
// AutoHotbar portado de GatoClient (AutoHotbar.cpp): cada item elegido tiene
// su slot de la hotbar, y si ese slot esta vacio o tiene otra cosa se trae el
// item desde el inventario (slots 9..35). Como el original, un cambio es un
// swap de dos slots; aca va con la misma transaccion de inventario que el
// Offhand (dos acciones del contenedor 0) y, igual que el, espera a que el
// servidor lo confirme antes de mandar otro.
//
// Diferencias con PC: el original compara un ID numerico fijo por item (la
// espada de diamante, el pico de diamante...). Aca se compara por nombre, asi
// que "Espada" acepta cualquier espada y trae la mejor que haya; las pociones
// se reconocen por su tipo (fuerza 31-33, dano 23-24). Se agregaron el totem y
// las botellas de experiencia. Si dos items piden el mismo slot gana el de mas
// arriba en la lista. Solo actua con el HUD a la vista (nada de menus o el
// inventario abierto).

enum AutoHotbarItem {
	AH_SWORD, AH_PICKAXE, AH_OBSIDIAN, AH_CRYSTAL, AH_POTION, AH_HARMING, AH_BED, AH_ANVIL, AH_TNT, AH_GAPPLE,
	AH_NETHERITE, AH_PISTON, AH_REDSTONE, AH_GLOWSTONE, AH_ANCHOR, AH_PEARL, AH_TOTEM, AH_XP, AH_COUNT
};

struct AutoHotbarEntry {
	const char* key;            // clave en la config
	StrId label;
	const char* const* names;   // nombres aceptados, del mejor al peor
	int aux[3];                 // tipos de pocion aceptados (0 = cualquiera)
};

static const char* const kAhSwords[] = {"netherite_sword", "diamond_sword", "iron_sword", "stone_sword", "golden_sword", "wooden_sword", nullptr};
static const char* const kAhPickaxes[] = {"netherite_pickaxe", "diamond_pickaxe", "iron_pickaxe", "stone_pickaxe", "golden_pickaxe", "wooden_pickaxe", nullptr};
static const char* const kAhObsidian[] = {"obsidian", nullptr};
static const char* const kAhCrystal[] = {"end_crystal", nullptr};
static const char* const kAhPotion[] = {"potion", "splash_potion", "lingering_potion", nullptr};
static const char* const kAhHarming[] = {"splash_potion", "lingering_potion", "potion", nullptr};
static const char* const kAhBed[] = {"bed", nullptr};
static const char* const kAhAnvil[] = {"anvil", "chipped_anvil", "damaged_anvil", nullptr};
static const char* const kAhTnt[] = {"tnt", nullptr};
static const char* const kAhGapple[] = {"golden_apple", "enchanted_golden_apple", nullptr};
static const char* const kAhNetherite[] = {"netherite_block", nullptr};
static const char* const kAhPiston[] = {"piston", "sticky_piston", nullptr};
static const char* const kAhRedstone[] = {"redstone_block", nullptr};
static const char* const kAhGlowstone[] = {"glowstone", nullptr};
static const char* const kAhAnchor[] = {"respawn_anchor", nullptr};
static const char* const kAhPearl[] = {"ender_pearl", nullptr};
static const char* const kAhTotem[] = {"totem_of_undying", nullptr};
static const char* const kAhXp[] = {"experience_bottle", nullptr};

static const AutoHotbarEntry kAutoHotbarEntries[AH_COUNT] = {
	{"sword", S_AhSword, kAhSwords, {0}},
	{"pickaxe", S_AhPickaxe, kAhPickaxes, {0}},
	{"obsidian", S_AhObsidian, kAhObsidian, {0}},
	{"crystal", S_AhCrystal, kAhCrystal, {0}},
	{"potion", S_AhPotion, kAhPotion, {31, 32, 33}},   // fuerza, fuerza larga, fuerza II
	{"harming", S_AhHarming, kAhHarming, {23, 24, 0}}, // dano, dano II
	{"bed", S_AhBed, kAhBed, {0}},
	{"anvil", S_AhAnvil, kAhAnvil, {0}},
	{"tnt", S_AhTnt, kAhTnt, {0}},
	{"gapple", S_AhGapple, kAhGapple, {0}},
	{"netherite", S_AhNetherite, kAhNetherite, {0}},
	{"piston", S_AhPiston, kAhPiston, {0}},
	{"redstone", S_AhRedstone, kAhRedstone, {0}},
	{"glowstone", S_AhGlowstone, kAhGlowstone, {0}},
	{"anchor", S_AhAnchor, kAhAnchor, {0}},
	{"pearl", S_AhPearl, kAhPearl, {0}},
	{"totem", S_AhTotem, kAhTotem, {0}},
	{"xp", S_AhXp, kAhXp, {0}},
};

#if defined(__aarch64__)
static const int kAhInventoryStart = 9;
static const int kAhPendingTicks = 10;  // ~0.5 s esperando la confirmacion

static int g_ahDelayTicks = 0;
static int g_ahPendingTicks = 0;
static int g_ahPendingSlot = -1;
static int g_ahPendingItem = -1;

// Rango del stack para la entrada (0 = el mejor), -1 si no le sirve.
static int AhRank(const AutoHotbarEntry& e, void* stack) {
	const char* name = AcItemName(stack);
	if (!*name) return -1;
	for (int i = 0; e.names[i]; i++) {
		if (strcmp(name, e.names[i]) != 0) continue;
		if (e.aux[0]) {
			int aux = AcStackAux(stack);
			if (aux != e.aux[0] && aux != e.aux[1] && aux != e.aux[2]) return -1;
		}
		return i;
	}
	return -1;
}

// Cambia los items de dos slots del inventario (la hotbar es 0..8).
static void AhSwap(LocalPlayer* lp, void* container, int a, int b) {
	void* stackA = OffhandSlotItem(container, a);
	void* stackB = OffhandSlotItem(container, b);
	void* empty = (void*)(OffhandBase() + GatyoInventory::ItemStackEmpty);
	auto isNull = OffhandFn<bool (*)(void*)>(GatyoInventory::ItemStackIsNull);
	if (!stackA || isNull(stackA)) stackA = empty;
	if (!stackB || isNull(stackB)) stackB = empty;

	alignas(16) uint8_t fromA[GatyoInventory::kActionSize];
	alignas(16) uint8_t fromB[GatyoInventory::kActionSize];
	alignas(16) uint8_t transaction[GatyoInventory::kTransactionSize];
	OffhandBuildAction(fromA, GatyoInventory::kContainerInventory, a, stackA, stackB);
	OffhandBuildAction(fromB, GatyoInventory::kContainerInventory, b, stackB, stackA);
	memset(transaction, 0, sizeof(transaction));
	*(float*)(transaction + 32) = 1.0f;
	auto addAction = OffhandFn<void (*)(void*, void*)>(GatyoInventory::InventoryTransactionAddAction);
	addAction(transaction, fromA);
	addAction(transaction, fromB);
	OffhandFn<void (*)(void*, void*)>(GatyoInventory::LocalPlayerSendInventoryTransaction)(lp, transaction);
	auto destroyAction = OffhandFn<void (*)(void*)>(GatyoInventory::InventoryActionDestroy);
	destroyAction(fromA);
	destroyAction(fromB);
	OffhandFn<void (*)(void*)>(GatyoInventory::InventoryTransactionDestroy)(transaction);
}

static void AutoHotbarReset() {
	g_ahDelayTicks = 0;
	g_ahPendingTicks = 0;
	g_ahPendingSlot = -1;
	g_ahPendingItem = -1;
}

// Desde normalTick: a lo sumo un cambio por tick.
static void AutoHotbarOnNormalTick(LocalPlayer* lp) {
	static bool wasEnabled = false;
	if (!autoHotbar || !inHudScreen) {
		if (wasEnabled && !autoHotbar) AutoHotbarReset();
		wasEnabled = autoHotbar;
		return;
	}
	if (!wasEnabled) {
		AutoHotbarReset();
		wasEnabled = true;
	}
	void* container = OffhandContainer(lp);
	if (!container) return;

	if (g_ahPendingTicks > 0) {
		if (AhRank(kAutoHotbarEntries[g_ahPendingItem], OffhandSlotItem(container, g_ahPendingSlot)) >= 0) g_ahPendingTicks = 0;
		else if (--g_ahPendingTicks > 0) return;
	}
	if (g_ahDelayTicks < autoHotbarDelay) {
		g_ahDelayTicks++;
		return;
	}

	bool claimed[kAcHotbarSlots] = {};
	for (int e = 0; e < AH_COUNT; e++) {
		if (!autoHotbarItems[e]) continue;
		int target = ImClamp(autoHotbarSlots[e], 1, 9) - 1;
		if (claimed[target]) continue;  // ya lo pidio un item de mas arriba
		claimed[target] = true;
		const AutoHotbarEntry& entry = kAutoHotbarEntries[e];
		if (AhRank(entry, OffhandSlotItem(container, target)) >= 0) continue;
		int best = -1, bestRank = INT_MAX;
		for (int i = kAhInventoryStart; i < kOffhandSlots; i++) {
			int rank = AhRank(entry, OffhandSlotItem(container, i));
			if (rank >= 0 && rank < bestRank) {
				best = i;
				bestRank = rank;
			}
		}
		if (best < 0) continue;
		AhSwap(lp, container, best, target);
		g_ahDelayTicks = 0;
		g_ahPendingTicks = kAhPendingTicks;
		g_ahPendingSlot = target;
		g_ahPendingItem = e;
		return;
	}
}
#else
static void AutoHotbarOnNormalTick(LocalPlayer*) {}
static void AutoHotbarReset() {}
#endif
