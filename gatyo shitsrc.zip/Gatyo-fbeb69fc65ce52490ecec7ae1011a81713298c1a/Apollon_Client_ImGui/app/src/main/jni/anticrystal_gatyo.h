#pragma once
// AntiCrystal: mutacion del propio PlayerAuthInputPacket para desplazar el
// punto de contacto del cristal enemigo. Portado del AntiCrystal de
// GatoClient; los offsets de campo vienen del write() del paquete que ya
// verifico GatoAuraX:
//
//   pitch 0x2C, yaw 0x30, x 0x34, y 0x38, z 0x3C, cabeza 0x40,
//   velocidad 0x44 (xyz), mMove 0x60 (xy), banderas de entrada 0x88 (bit 136).
//
// Puede bajar el Y del paquete (Reduce Y), desplazar el XZ en contra de la
// velocidad (Horizontal: velocidad) o en contra de la mirada (Horizontal:
// mirada), y dejar a cero la informacion de movimiento (Parada de movida:
// velocidad 0x44-0x4C y mMove 0x60/0x64). Con Solo en el suelo (Feet Only) no
// toca nada mientras el jugador se mueve verticalmente: lo mas parecido al
// check de suelo del original con los datos que trae el paquete.

static void AntiCrystalOnAuthInput(void* packet) {
#if defined(__aarch64__)
	if (!antiCrystal || panic || !packet) return;
	char* p = (char*)packet;
	float* pos = (float*)(p + 0x34);
	float* vel = (float*)(p + 0x44);
	float* move = (float*)(p + 0x60);

	// Solo en el suelo: si hay velocidad vertical relevante, no toca nada.
	if (antiCrystalFeetOnly && fabsf(vel[1]) > 0.05f) return;

	// Reduce Y: bajar el punto de contacto del paquete.
	float dy = ImClamp(antiCrystalReduceY, -1.0f, 1.0f);
	if (dy != 0.0f) pos[1] -= dy;

	// Horizontal: desplazamiento del XZ.
	float dxz = ImClamp(antiCrystalReduceXZ, 0.0f, 2.0f);
	if (dxz > 0.0f) {
		float offX = 0.0f, offZ = 0.0f;
		if (antiCrystalHorizontal == 0) {
			// contra la velocidad del paquete
			float vx = vel[0], vz = vel[2];
			float speed = sqrtf(vx * vx + vz * vz);
			if (speed > 0.001f) {
				offX = -(vx / speed) * dxz;
				offZ = -(vz / speed) * dxz;
			}
		} else {
			// contra la mirada (el yaw del paquete)
			float yawDeg = *(float*)(p + 0x30);
			float rad = yawDeg * 3.14159265f / 180.0f;
			offX = sinf(rad) * dxz;
			offZ = cosf(rad) * dxz;
		}
		pos[0] += offX;
		pos[2] += offZ;
	}

	// Parada de movida: velocidad del paquete y mMove en cero.
	if (antiCrystalMotionSpoof) {
		vel[0] = 0.0f;
		vel[1] = 0.0f;
		vel[2] = 0.0f;
		move[0] = 0.0f;
		move[1] = 0.0f;
	}
#else
	(void)packet;
#endif
}

// (Firma unica en todos los ABIs: la version ARM64 muta el paquete, el resto
// queda en no-op.)
