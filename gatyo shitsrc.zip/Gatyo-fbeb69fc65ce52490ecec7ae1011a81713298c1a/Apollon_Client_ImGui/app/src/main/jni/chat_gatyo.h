#pragma once
// Modulo "Chat" de GatoClient (ChatSuffix): agrega cosas a los mensajes que
// mandas. Igual que el original, cambia el TextPacket de salida justo antes de
// serializarlo: texto verde ("> "), el nombre del cliente al final, letras
// versalitas, etiquetas al azar antes y despues, y un nombre de autor falso.
// Ademas (no esta en PC) frases o simbolos propios antes y despues de cada
// mensaje, de una lista que se recorre en orden o al azar.
//
// TextPacket (1.21.111 arm64, de su write() en IDA): tipo +44 (Chat = 1),
// autor std::string +48 ("Player Name"), mensaje std::string +72 ("Message").

#if defined(__aarch64__)
namespace GatyoChat {
	enum : uintptr_t {
		TextPacketWrite = 0xA4A7A20,  // TextPacket::write(BinaryStream&) const, slot 7 del vtable
	};
	static const int kType = 44;
	static const int kAuthor = 48;
	static const int kMessage = 72;
	static const uint8_t kTypeChat = 1;
}

static std::string ChatRandomTag(int length, bool upper, bool lower, bool numbers) {
	std::string chars;
	if (upper) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	if (lower) chars += "abcdefghijklmnopqrstuvwxyz";
	if (numbers) chars += "0123456789";
	if (chars.empty() || length <= 0) return "";
	static std::mt19937 rng{std::random_device{}()};
	std::uniform_int_distribution<size_t> pick(0, chars.size() - 1);
	std::string out;
	for (int i = 0; i < ImMin(length, 32); i++) out += chars[pick(rng)];
	return out;
}

// Versalitas del original: letras (mayusculas y minusculas) y digitos a subindice.
static std::string ChatFancy(const std::string& text) {
	static const char* const kLetters[26] = {
		"ᴀ", "ʙ", "ᴄ", "ᴅ", "ᴇ", "ꜰ", "ɢ", "ʜ", "ɪ", "ᴊ", "ᴋ", "ʟ", "ᴍ",
		"ɴ", "ᴏ", "ᴘ", "ǫ", "ʀ", "ꜱ", "ᴛ", "ᴜ", "ᴠ", "ᴡ", "x", "ʏ", "ᴢ",
	};
	static const char* const kDigits[10] = {"₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉"};
	std::string out;
	for (char c : text) {
		if (c >= 'A' && c <= 'Z') out += kLetters[c - 'A'];
		else if (c >= 'a' && c <= 'z') out += kLetters[c - 'a'];
		else if (c >= '0' && c <= '9') out += kDigits[c - '0'];
		else out += c;
	}
	return out;
}

// Frase propia de una lista: en orden (una distinta por mensaje) o al azar.
static std::string ChatPickPhrase(const std::vector<std::string>& list, size_t& next) {
	if (list.empty()) return "";
	size_t index;
	if (chatCustomRandom) {
		static std::mt19937 rng{std::random_device{}()};
		index = std::uniform_int_distribution<size_t>(0, list.size() - 1)(rng);
	} else {
		index = next++ % list.size();
	}
	return list[index];
}

static bool ChatIsSpace(char c) { return c == ' ' || c == '\t'; }

// `before` y `after` son las frases propias: van tal cual (sin versalitas) y
// con un espacio de separacion si la frase no lo trae.
static std::string ChatTransform(const std::string& message, const std::string& clientName,
                                 const std::string& before, const std::string& after) {
	std::string tagBefore = chatPrefixTag ? ChatRandomTag(chatPrefixLength, chatPrefixUpper, chatPrefixLower, chatPrefixNums) : "";
	std::string tagAfter = chatSuffixTag ? ChatRandomTag(chatSuffixLength, chatSuffixUpper, chatSuffixLower, chatSuffixNums) : "";
	std::string out;
	if (!tagBefore.empty()) out += tagBefore + " | ";
	out += message;
	if (chatClientSuffix && out.find(clientName) == std::string::npos) out += " | " + clientName;
	if (!tagAfter.empty()) out += " | " + tagAfter;
	if (chatFancy) out = ChatFancy(out);
	if (!before.empty()) out = before + (ChatIsSpace(before.back()) ? "" : " ") + out;
	if (!after.empty()) out += (ChatIsSpace(after.front()) ? "" : " ") + after;
	if (chatGreenText) out = "> " + out;  // el "> " tiene que ir primero para que el texto salga verde
	return out;
}

void* (*old_TextPacketWrite)(void* packet, void* stream);
void* TextPacketWrite(void* packet, void* stream) {
	if (panic || !chatModule || *(uint8_t*)((char*)packet + GatyoChat::kType) != GatyoChat::kTypeChat) {
		return old_TextPacketWrite(packet, stream);
	}
	// el ultimo mensaje transformado: si el paquete se serializa de nuevo (o
	// vuelve como eco en un mundo local) no se transforma dos veces
	static std::string lastOut;
	std::string& message = *(std::string*)((char*)packet + GatyoChat::kMessage);
	if (!message.empty() && message[0] != '/' && message != lastOut) {
		std::string clientName, fakeName, before, after;
		{
			std::lock_guard<std::mutex> lock(g_textMutex);  // el dialogo de texto los escribe desde otro hilo
			clientName = chatClientName.empty() ? "Gatyo" : chatClientName;
			fakeName = chatFakeNameValue;
			static size_t nextBefore = 0, nextAfter = 0;
			if (chatCustomBefore) before = ChatPickPhrase(chatBeforePhrases, nextBefore);
			if (chatCustomAfter) after = ChatPickPhrase(chatAfterPhrases, nextAfter);
		}
		message = ChatTransform(message, clientName, before, after);
		lastOut = message;
		if (chatFakeName && !fakeName.empty()) *(std::string*)((char*)packet + GatyoChat::kAuthor) = fakeName;
	}
	return old_TextPacketWrite(packet, stream);
}
#endif

// Campo de texto: muestra el valor y abre el teclado de Android al tocarlo.
// Con ancho negativo (ventanas angostas del ClickGUI) la etiqueta va arriba.
static void ChatTextField(StrId label, std::string* value, float width) {
	std::string shown;
	{
		std::lock_guard<std::mutex> lock(g_textMutex);
		shown = *value;
	}
	if (width < 0.0f) MutedText(T(label));
	ImGui::PushID(value);
	if (ImGui::Button(shown.empty() ? T(S_ChatEmpty) : shown.c_str(), ImVec2(width, 0))) RequestTextInput(T(label), value);
	ImGui::PopID();
	if (width >= 0.0f) {
		ImGui::SameLine();
		ImGui::AlignTextToFramePadding();
		ImGui::TextUnformatted(T(label));
	}
}

// Simbolos para tocar y agregarlos como frase nueva de la lista (despues se
// editan con el teclado). Todos entran en la fuente del menu y en la del juego.
static void ChatSymbolPalette(std::vector<std::string>& list, const char* id) {
	static const char* const kSymbols[] = {
		"★", "☆", "✦", "✧", "♛", "♚", "⚔", "☠", "♥", "❤", "✿", "❀", "⚡", "☯", "✪", "❖",
		"➤", "»", "«", "↯", "✔", "✘", "☾", "☀", "♪", "∞", "⛧", "『』", "【】", "«»", "• ", "︱",
	};
	MutedText(T(S_ChatSymbols));
	ImGui::PushID(id);
	float avail = ImGui::GetContentRegionAvail().x, x = 0.0f;
	for (int i = 0; i < IM_ARRAYSIZE(kSymbols); i++) {
		ImGui::PushID(i);
		float w = ImGui::CalcTextSize(kSymbols[i]).x + ImGui::GetStyle().FramePadding.x * 2.0f;
		if (i > 0 && x + w < avail) ImGui::SameLine();
		else x = 0.0f;
		if (ImGui::Button(kSymbols[i])) {
			std::lock_guard<std::mutex> lock(g_textMutex);
			list.push_back(kSymbols[i]);
		}
		x += w + ImGui::GetStyle().ItemSpacing.x;
		ImGui::PopID();
	}
	ImGui::PopID();
}

// Frases propias antes y despues del mensaje (panel y ClickGUI).
void DrawChatCustomPhrases(float width) {
	ModToggle(MOD_chatCustomBefore);
	if (chatCustomBefore) {
		DrawTextList(chatBeforePhrases, S_ChatBeforeTitle, width);
		ChatSymbolPalette(chatBeforePhrases, "before");
	}
	ModToggle(MOD_chatCustomAfter);
	if (chatCustomAfter) {
		DrawTextList(chatAfterPhrases, S_ChatAfterTitle, width);
		ChatSymbolPalette(chatAfterPhrases, "after");
	}
	if (chatCustomBefore || chatCustomAfter) {
		ImGui::Checkbox(TL(S_ChatCustomRandom), &chatCustomRandom);
		Tip(S_TipChatCustomRandom);
	}
}

// Ajustes del modulo Chat (pagina Otros y fila del ClickGUI). `narrow` pone
// cada control en su linea, para las ventanas del ClickGUI.
void DrawChatSettings(float width, bool narrow) {
	ImGui::PushItemWidth(width);
	ModToggle(MOD_chatGreenText);
	if (!narrow) ImGui::SameLine();
	ModToggle(MOD_chatFancy);
	ModToggle(MOD_chatClientSuffix);
	if (chatClientSuffix) ChatTextField(S_ChatClientName, &chatClientName, width);
	ModToggle(MOD_chatPrefixTag);
	if (chatPrefixTag) {
		ImGui::SliderInt(TL(S_ChatTagLength), &chatPrefixLength, 1, 32);
		ModToggle(MOD_chatPrefixUpper);
		if (!narrow) ImGui::SameLine();
		ModToggle(MOD_chatPrefixLower);
		if (!narrow) ImGui::SameLine();
		ModToggle(MOD_chatPrefixNums);
	}
	ModToggle(MOD_chatSuffixTag);
	if (chatSuffixTag) {
		ImGui::PushID("suffix");
		ImGui::SliderInt(TL(S_ChatTagLength), &chatSuffixLength, 1, 32);
		ImGui::PopID();
		ModToggle(MOD_chatSuffixUpper);
		if (!narrow) ImGui::SameLine();
		ModToggle(MOD_chatSuffixLower);
		if (!narrow) ImGui::SameLine();
		ModToggle(MOD_chatSuffixNums);
	}
	DrawChatCustomPhrases(width);
	ModToggle(MOD_chatFakeName);
	if (chatFakeName) ChatTextField(S_ChatFakeNameValue, &chatFakeNameValue, width);
	ImGui::PopItemWidth();
}
