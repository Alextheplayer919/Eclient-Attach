#pragma once
// CrystalChams: cristales rellenos en el render del mundo (con la profundidad
// del juego, en worldrender_gatyo.h) y un fallback por overlay de ImGui para
// cuando el contexto GL del juego no sale limpio. Portado del CrystalChams de
// GatoClient:
//
//   El hilo del juego publica el listado de EndCrystal a 64 bloques o menos
//   en el snapshot del mundo (g_worldShared.crystals, mismo contrato del
//   ESP: el overlay copia a g_world cada frame). El render del juego toma
//   esa lista desde el hilo GL con el mutex; el overlay de ImGui la usa
//   desde su copia, sin tocar punteros del juego.
//
//   Forma: las tres capas del cristal del juego (vidrio, vidrio y nucleo),
//   paradas sobre una punta y girando una dentro de otra (CrystalShells).
//   Animacion: giro, balanceo, aparicion creciendo y desvanecimiento al
//   romperse (Fade duracion). Escala y los dos colores (relleno y linea) van
//   en los ajustes; "Brillo extra" suma un reflejo en el render del mundo.

#if defined(__aarch64__)

// ---------------------------------------------------------------------------
// Publicacion (hilo del juego)
// ---------------------------------------------------------------------------
static bool g_crChamsWas = false;     // estaba encendido el tick anterior
static double g_crChamsSeen = -100.0; // ultima vez que hubo cristales

// Avanza el tick de la suite igual que los demas modulos.
static void CrystalChamsOnNormalTick(LocalPlayer* lp, Level* level) {
	if (!crystalChams) {
		if (g_crChamsWas) {
			std::lock_guard<std::mutex> lock(g_worldMutex);
			g_worldShared.crystals.clear();
			g_crystalChamsWorldReady = false;
			g_wrChamsNoSlot = false;  // al volver a encenderlo se reintenta el render del mundo
			g_crChamsWas = false;
		}
		return;
	}
	g_crChamsWas = true;
	AcAdvanceTick();
	std::vector<EntityStruct> list;
	bool inWorld = lp && level && GaxValid(lp) && !panic && !inMenu;
	if (inWorld && lp->getHealth() > 0) {
		std::vector<AcEntity> crystals = AcCollectCrystals(lp, level, 64.0f);
		vec2_t dims(1.0f, 1.0f);
		list.reserve(crystals.size());
		for (AcEntity& c : crystals) {
			EntityStruct e;
			e.id = (uintptr_t)c.actor;      // solo para seguirlo entre ticks
			e.typeId = kAcCrystalType;
			e.position = vec3_t(c.pos.x, c.pos.y, c.pos.z);
			e.hitBox = dims;
			list.push_back(e);
		}
	}
	double now = AcNow();
	if (!list.empty()) g_crChamsSeen = now;
	{
		std::lock_guard<std::mutex> lock(g_worldMutex);
		g_worldShared.crystals = list;
	}
	// sigue un rato despues del ultimo cristal: el que se rompio tiene que
	// terminar de desvanecerse en el mismo render (si no, el overlay lo
	// dibujaba sin profundidad durante el fade)
	g_crystalChamsWorldReady = inWorld && now - g_crChamsSeen < 3.0;
}

// ---------------------------------------------------------------------------
// Fallback por overlay (hilo de ImGui)
// ---------------------------------------------------------------------------
static std::unordered_map<uintptr_t, CrystalAnim> g_crAnim;
static double g_crOverlayLast = 0.0;

static void RenderCrystalChamsOverlay(ImDrawList* dl, vec3_t cameraPos, glm::vec2 axisFov, glm::mat4 viewMatrix) {
	if (!g_viewValid) return;
	if (CrystalChamsWorldActive() || !crystalChams) {  // el render del mundo se encarga
		g_crAnim.clear();
		return;
	}
	double now = AcNow();
	float dt = (float)ImClamp(now - g_crOverlayLast, 0.0, 0.1);
	g_crOverlayLast = now;
	if (!CrystalAnimate(g_crAnim, g_world.crystals, now, dt)) return;

	// de la mas lejana a la mas cercana
	struct Item { const CrystalAnim* anim; glm::vec3 center; float distance; };
	std::vector<Item> items;
	for (const auto& kv : g_crAnim) {
		if (kv.second.alpha <= 0.0f) continue;
		glm::vec3 center = CrystalCenter(kv.second);
		items.push_back({&kv.second, center, glm::length(center - g_view.cam)});
	}
	std::sort(items.begin(), items.end(), [](const Item& a, const Item& b) { return a.distance > b.distance; });

	static const float kShellAlpha[kCrystalShells] = {0.6f, 0.8f, 1.6f};
	for (const Item& it : items) {
		CrystalShell shells[kCrystalShells];
		CrystalShells(it.center, CrystalScale(*it.anim), it.anim->spin, shells);
		float a = it.anim->alpha;
		// sin profundidad solo van las caras de adelante: primero el nucleo,
		// asi el vidrio de afuera se mezcla encima
		for (int i = kCrystalShells - 1; i >= 0; i--) {
			ImVec4 fill(crystalChamsFillColor[0], crystalChamsFillColor[1], crystalChamsFillColor[2],
						ImSaturate(crystalChamsFillColor[3] * kShellAlpha[i]) * a);
			ImU32 line = ImGui::ColorConvertFloat4ToU32(ImVec4(
				crystalChamsLineColor[0], crystalChamsLineColor[1], crystalChamsLineColor[2], crystalChamsLineColor[3] * a * (i == 0 ? 1.0f : 0.7f)));
			GatyoSolidBox3D(dl, g_view, shells[i].corners, fill, line, ImMax(1.0f, (i == 0 ? 1.2f : 0.9f) * scaleGlobal));
		}
	}
}

#else
// Otros ABIs: no-ops con la misma firma.
static void CrystalChamsOnNormalTick(LocalPlayer*, Level*) {}
static void RenderCrystalChamsOverlay(ImDrawList*, vec3_t, glm::vec2, glm::mat4) {}
#endif
