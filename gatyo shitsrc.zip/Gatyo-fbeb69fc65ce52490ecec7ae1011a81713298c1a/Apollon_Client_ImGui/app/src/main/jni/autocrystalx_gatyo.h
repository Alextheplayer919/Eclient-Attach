#pragma once
// AutoCrystalX: la version dinamica del cristal, portada del AutoCrystalX de
// GatoClient con las capas de este cliente. Los fallbacks son los decididos
// con el usuario:
//
//   * Paquete Place / Paquete Attack / Paquete Terreno / ID Predict usaban
//     paquetes de transaccion (ItemUse / ItemUseOnActor / InventoryTransaction
//     del actor) que en 1.21.111 siguen sin estar verificados en IDA, asi que
//     las acciones salen por las llamadas del juego: buildBlock para colocar
//     el cristal o el soporte, attack para romper. Los controles quedan en la
//     UI con el aviso del fallback.
//   * La armadura sale del ActorEquipmentComponent (crystal_common): la
//     formula de danio es la del original con su reduccion.
//
//   Lo efectivamente portado:
//   - Rangos por separado: Objetivo / Rotura / Origen / Proximity.
//   - Danio al objetivo, Danio propio y Danio minimo con la formula ACX.
//   - Prioridad (danio / distancia), Fase (la jaula puede pisar el AABB del
//     objetivo) y Modo Java (un solo aire encima).
//   - Rompe y coloca en el mismo tick, como el original; solo Alternado los
//     separa. El cristal golpeado ya no ocupa su base (el reemplazo sale con
//     el golpe) y los paquetes AddActor/RemoveActor corren un pase rapido
//     apenas aparece o desaparece un cristal. Multitarea es la del original: seguir actuando mientras se come
//     (con Pausa al comer apagada).
//   - Terreno: sin base material cerca, coloca un soporte de obsidiana anclado
//     (bloque por tick con retardo) y el cristal sale el tick siguiente. Air
//     Place deja poner el soporte sin vecino donde apoyarlo (en el original
//     tambien es una opcion del terreno: el cristal siempre va sobre base).
//   - Cambio de slot con los cuatro modos y Alternado (una accion por tick).
//   - Sync con el KA del usuario (ventana de postgolpe que sortea retardos).
//   - Dinamico: velocidad EMA por objetivo, box desplazada (Predict Ticks con
//     peso de velocidad) y intercepto en la direccion de movida (solo con
//     Proximity >= 12, como el original).
//   - Dinero desperdiciado (Waste): el techo de dano propio se ensancha.
//   - Render propio con Lerp/Speed, Fade y dano en texto.

// ---------------------------------------------------------------------------
// Estado para la UI: por que coloca o no coloca. Lo publica el tick (hilo del
// juego) y lo lee el menu; cada cambio queda tambien en logcat.
// ---------------------------------------------------------------------------
enum AcxStatus {
	ACX_ST_OFF, ACX_ST_PLACING, ACX_ST_PAUSED, ACX_ST_NO_CRYSTAL, ACX_ST_NO_TARGET,
	ACX_ST_NO_BASE, ACX_ST_LOW_DAMAGE, ACX_ST_SELF_DAMAGE, ACX_ST_NO_SWITCH,
};
static std::atomic<int> g_acxStatus{ACX_ST_OFF};
static std::atomic<int> g_acxStatBases{0};          // bases validas (aire encima, jaula libre)
static std::atomic<int> g_acxStatLow{0};            // descartadas por Danio minimo
static std::atomic<int> g_acxStatSelf{0};           // descartadas por el tope de danio propio
static std::atomic<float> g_acxStatMinSelf{0.0f};   // el menor danio propio entre las descartadas

static std::string AcxStatusText() {
	switch (g_acxStatus.load()) {
		case ACX_ST_PLACING: return T(S_AcxStPlacing);
		case ACX_ST_PAUSED: return T(S_AcxStPaused);
		case ACX_ST_NO_CRYSTAL: return T(S_AcxStNoCrystal);
		case ACX_ST_NO_TARGET: return T(S_AcxStNoTarget);
		case ACX_ST_NO_BASE: return T(S_AcxStNoBase);
		case ACX_ST_LOW_DAMAGE: return TF(S_AcxStLowDamage, g_acxStatLow.load(), acxMinDamage);
		case ACX_ST_SELF_DAMAGE: return TF(S_AcxStSelfDamage, g_acxStatSelf.load(), g_acxStatMinSelf.load(), acxSelfDamage + ImMax(0.0f, acxWasteAmount));
		case ACX_ST_NO_SWITCH: return T(S_AcxStNoSwitch);
	}
	return T(S_AcxStOff);
}

#if defined(__aarch64__)
#include <unordered_set>
#include <cstdio>

static void AcxPublishStatus(int status) {
	static int logged = -1;
	static double loggedAt = 0.0;
	g_acxStatus = status;
	double now = AcNow();
	// GATYO_PROBE: solo los cambios, como mucho uno por segundo
	if (status != logged && now - loggedAt >= 1.0) {
		logged = status;
		loggedAt = now;
		__android_log_print(ANDROID_LOG_INFO, "Gatyo", "acx: estado %d bases %d bajo %d propio %d (min %.1f)",
			status, g_acxStatBases.load(), g_acxStatLow.load(), g_acxStatSelf.load(), g_acxStatMinSelf.load());
	}
}

// ---------------------------------------------------------------------------
// Estado del modulo
// ---------------------------------------------------------------------------
static bool g_acxWas = false;
static uint32_t g_acxLastBreak = 0;    // tick del ultimo golpe
static uint32_t g_acxLastPlace = 0;    // tick de la ultima colocacion
static uint32_t g_acxLastTerrain = 0;  // tick del ultimo soporte
static bool g_acxAttackedThisTick = false;
static bool g_acxPlacedThisTick = false;

// Golpes por cristal (runtime ID -> tick). Un cristal golpeado no se vuelve a
// golpear hasta kAcxRehitTicks (el siguiente golpe va a otro) y deja de ocupar
// su base durante kAcxGoneTicks: el reemplazo sale en el mismo gesto que el
// golpe, sin esperar a que el servidor lo quite. El servidor procesa los
// paquetes en orden (el golpe primero), asi que la base ya esta libre cuando
// le llega la colocacion.
static std::unordered_map<uint64_t, uint32_t> g_acxHits;
static const int kAcxRehitTicks = 2;
static const int kAcxGoneTicks = 6;

// Pase rapido: los paquetes AddActor/RemoveActor (netinject_gatyo.h) corren el
// modulo apenas aparece o desaparece un cristal, en el mismo hilo del juego y
// sin esperar al siguiente tick (hasta 50 ms menos por cada paso del ciclo).
static LocalPlayer* g_acxLp = nullptr;  // el del ultimo tick; los pases rapidos solo corren con ese
static double g_acxTickAt = 0.0;
static int g_acxFastBudget = 0;         // pases rapidos que quedan en este tick
static const int kAcxFastPerTick = 8;

// ID Predict: el mayor runtime ID visto (el servidor los da en orden: el del
// proximo cristal es uno de los siguientes) y el tick de la ultima tanda.
static uint64_t g_acxLastId = 0;
static uint32_t g_acxIdTick = 0;

// ItemUseOnActorInventoryTransaction armada como la arma GameMode::_attack
// (0xCCC075C) y enviada por LocalPlayer::sendInventoryTransaction, pero con el
// runtime ID que uno quiera: no hace falta que el actor exista en el cliente.
namespace AcxIdTx {
	enum : uintptr_t {
		Vtable = 0x103EDE48,         // ItemUseOnActorInventoryTransaction (punto de la vtable)
		ItemInit = 0xD3DAA80,        // base del descriptor del item (+96)
		ItemVtable = 0xFF2A9F0,      // NetworkItemStackDescriptor
		SetItem = 0xCCCF364,         // copia el ItemStack de la mano al descriptor
		SelectedItem = 0xCE0ABF4,    // Player: ItemStack de la mano
		CanSend = 0xC93BAE8,         // Player: el _attack lo mira antes de enviar
	};
	static const int kSize = 200;
	static const int kRid = 80, kAction = 88, kSlot = 92, kPlayerPos = 176;
	static const int kSupplies = 1392, kSuppliesSlot = 16;  // Player -> PlayerInventory -> slot elegido
	static const int kSendTx = 1848;                          // vtable de LocalPlayer: sendInventoryTransaction
	static const uint32_t kActionAttack = 1;
}

static void AcxSendIdAttack(LocalPlayer* lp, uint64_t rid) {
	uintptr_t base = OffhandBase();
	if ((((uint64_t (*)(void*))(base + AcxIdTx::CanSend))(lp) & 1) == 0) return;
	char* tx = (char*)::operator new(AcxIdTx::kSize);
	memset(tx, 0, AcxIdTx::kSize);
	*(uintptr_t*)tx = base + AcxIdTx::Vtable;
	*(uint32_t*)(tx + 8) = 3;              // tipo: UseItemOnEntity
	*(uint32_t*)(tx + 48) = 0x3F800000;    // 1.0f del mapa interno
	*(uint64_t*)(tx + AcxIdTx::kAction) = 0xFFFFFFFF00000000ull;
	((void (*)(void*))(base + AcxIdTx::ItemInit))(tx + 96);
	*(uintptr_t*)(tx + 96) = base + AcxIdTx::ItemVtable;
	((void (*)(void*, void*))(base + AcxIdTx::SetItem))(tx, ((void* (*)(void*))(base + AcxIdTx::SelectedItem))(lp));
	char* supplies = *(char**)((char*)lp + AcxIdTx::kSupplies);
	*(uint32_t*)(tx + AcxIdTx::kSlot) = supplies ? *(uint32_t*)(supplies + AcxIdTx::kSuppliesSlot) : 0;
	*(uint32_t*)(tx + AcxIdTx::kAction) = AcxIdTx::kActionAttack;
	*(uint64_t*)(tx + AcxIdTx::kRid) = rid;
	GaxV3 pos = GaxPos(lp);
	float* p = (float*)(tx + AcxIdTx::kPlayerPos);
	p[0] = pos.x; p[1] = pos.y; p[2] = pos.z;
	void* owned = tx;  // unique_ptr<InventoryTransaction>: el juego se lo lleva
	typedef void (*SendFn)(void*, void**);
	(*(SendFn*)(*(uintptr_t*)lp + AcxIdTx::kSendTx))(lp, &owned);
	if (owned) (*(void (**)(void*))(*(uintptr_t*)owned + 8))(owned);
}

// Mayor runtime ID entre los actores del Level (el del jugador falso es
// inventado y enorme: no cuenta).
static void AcxNoteIds(Level* level) {
	for (Mob* mob : level->getRuntimeActorList()) {
		if (!GaxValid(mob)) continue;
		uint64_t rid = AcRuntimeId(mob);
		if (rid < (1ull << 48) && rid > g_acxLastId) g_acxLastId = rid;
	}
}

// Velocidad estimada por objetivo (EMA) para el dinamico. La clave es el
// runtime ID del jugador (el RPC del fake player vale 0).
struct AcxTrack {
	GaxV3 vel = {0, 0, 0};
	uint32_t lastTick = 0;
};
static std::unordered_map<uint64_t, AcxTrack> g_acxVel;

// Soportes de obsidiana esperando que el siguiente tick los vea como base.
struct AcxSupport {
	uint64_t cell;
	uint32_t tick;
};
static std::vector<AcxSupport> g_acxTerrain;

// Marcas del frame para el overlay (las publica el flush de colocaciones).
static std::vector<AcMark> g_acxFrameMarks;

static void AcxReset() {
	g_acxWas = false;
	g_acxLastBreak = 0;
	g_acxLastPlace = 0;
	g_acxLastTerrain = 0;
	g_acxAttackedThisTick = false;
	g_acxPlacedThisTick = false;
	g_acxHits.clear();
	g_acxLastId = 0;
	g_acxIdTick = 0;
	g_acxLp = nullptr;
	g_acxFastBudget = 0;
	g_acxVel.clear();
	g_acxTerrain.clear();
	g_acxFrameMarks.clear();
}

// ---------------------------------------------------------------------------
// Dinamico: velocidad estimada + box desplazada + intercepto
// ---------------------------------------------------------------------------
static void AcxUpdateVel(const std::vector<AcEntity>& targets) {
	for (const AcEntity& t : targets) {
		if (t.self) continue;
		AcxTrack& st = g_acxVel[t.rid];
		GaxV3 cur = GaxVel(t.actor);
		const float k = 0.35f;  // suavizado del EMA del original
		st.vel.x += (cur.x - st.vel.x) * k;
		st.vel.y += (cur.y - st.vel.y) * k;
		st.vel.z += (cur.z - st.vel.z) * k;
		st.lastTick = g_acTick;
	}
}

static void AcxPruneVel() {
	for (auto it = g_acxVel.begin(); it != g_acxVel.end(); ) {
		if ((int32_t)(g_acTick - it->second.lastTick) > 20) it = g_acxVel.erase(it);
		else ++it;
	}
}

// Box del objetivo desplazada por la prediccion (ticks * peso de velocidad).
static GaxBox AcxPredictedBox(const AcEntity& t, const AcxTrack& tr) {
	GaxBox b = t.box;
	float p = (float)acxPredictTicks * acxVelWeight;
	b.lower.x += tr.vel.x * p; b.upper.x += tr.vel.x * p;
	b.lower.z += tr.vel.z * p; b.upper.z += tr.vel.z * p;
	b.lower.y += tr.vel.y * p; b.upper.y += tr.vel.y * p;
	return b;
}

// Danio ACX de un cristal sobre un box dado (el del actor o el predicho),
// con exposicion en cache y la armadura del actor.
static float AcxDamageAt(const AcEntity& who, BlockSource* region, const GaxBox& box, const glm::vec3& exp) {
	return AcxDamage(box, exp, AcSeenPercentCached(who.rid, region, box, exp), who.armor, who.armorPieces);
}

// Intercepto: si el cristal cae en la direccion de movida del objetivo, el
// danio esperado sube. El original lo deja solo con Proximity >= 12.
static float AcxIntercept(const AcEntity& t, const AcxTrack* tr, const glm::vec3& exp) {
	if (!tr || acxProximity < 12.0f) return 0.0f;
	float speed = sqrtf(tr->vel.x * tr->vel.x + tr->vel.z * tr->vel.z);
	if (speed < 0.05f) return 0.0f;
	float dx = exp.x - t.pos.x, dz = exp.z - t.pos.z;
	float d = sqrtf(dx * dx + dz * dz);
	if (d < 0.1f) return 0.0f;
	float align = (dx / d) * (tr->vel.x / speed) + (dz / d) * (tr->vel.z / speed);
	if (align <= 0.0f) return 0.0f;
	return align * speed * (float)acxPredictTicks * acxIntercept * 0.1f;
}

// Vecino solido donde apoyar el soporte de obsidiana: devuelve el bloque a
// tocar y la cara que mira a la celda (FacingID: 0 abajo, 1 arriba, 2 norte,
// 3 sur, 4 oeste, 5 este). Primero el de abajo, como un bloque puesto a mano.
static bool AcxAnchor(BlockSource* region, const vec3_ti& cell, vec3_ti& clicked, unsigned char& face) {
	static const int kdirs[5][4] = {{0, -1, 0, 1}, {1, 0, 0, 4}, {-1, 0, 0, 5}, {0, 0, 1, 2}, {0, 0, -1, 3}};
	for (const auto& d : kdirs) {
		vec3_ti n{cell.x + d[0], cell.y + d[1], cell.z + d[2]};
		if (AcIsAir(AcBlockAt(region, n))) continue;
		clicked = n;
		face = (unsigned char)d[3];
		return true;
	}
	return false;
}

static bool AcxRecentlyHit(uint64_t rid, int ticks) {
	auto it = g_acxHits.find(rid);
	return it != g_acxHits.end() && AcTicksSince(it->second) < ticks;
}

// ---------------------------------------------------------------------------
// Tick (fast: pase rapido desde un paquete; no avanza el EMA ni el terreno)
// ---------------------------------------------------------------------------
static void AcxRun(LocalPlayer* lp, Level* level, GameMode* gm, bool fast) {
	void* ci = (void*)CI;
	BlockSource* region = lp->getDimensionBlockSource();
	if (!region) return;

	AcSlotsBegin(lp);
	AcClearExpCache();
	g_acxAttackedThisTick = false;
	g_acxPlacedThisTick = false;
	g_acxFrameMarks.clear();

	// Alternado: una sola accion de la suite del cristal por tick.
	bool onePerTick = acxAlternate;
	bool eaterPaused = (acxEatStop || !acxMultitask) && AcEatingActive(lp);
	bool attackWindow = acxSync && AcSyncOpen(acxSyncDelay);

	float collectRange = ImMax(ImMax(acxBreakRange, acxPlaceRange), acxTargetRange) + 1.0f;
	AcEntity me = AcSelfEntity(lp);  // danio propio: box, rid y armadura una vez por tick
	// en creativo (o espectador) no hay danio propio: con la escala de ACX
	// (hasta ~97 sin armadura) todo lugar a mano pasaba el tope de 20 y no
	// colocaba nada
	bool selfImmune = !lp->isAttackableGamemode();
	auto selfDamageAt = [&](const glm::vec3& exp) {
		return selfImmune ? 0.0f : AcxDamageAt(me, region, me.box, exp);
	};
	std::vector<AcEntity> targets = AcCollectTargets(lp, level, collectRange + 2.0f, acxSelf);
	std::sort(targets.begin(), targets.end(), [](const AcEntity& a, const AcEntity& b) {
		return a.dist < b.dist;
	});
	if (targets.size() > 6) targets.resize(6);
	if (!fast) {
		if (acxDynamic) AcxUpdateVel(targets);
		AcxPruneVel();
	}
	std::vector<GaxBox> boxes = AcCollectBoxes(level, lp);
	std::vector<AcEntity> crystals = AcCollectCrystals(lp, level, collectRange);
	if (acxIDPredict) AcxNoteIds(level);

	// --------------------------------------------------------------------------
	// Rompe
	// --------------------------------------------------------------------------
	if (!eaterPaused && acxBreak && !(onePerTick && g_acxPlacedThisTick)) {
		bool window = attackWindow || AcTicksSince(g_acxLastBreak) >= acxBreakDelay;
		if (window) {
			struct Pick {
				AcEntity* c;
				glm::vec3 exp;
				float dmg;
			};
			std::vector<Pick> picks;
			picks.reserve(crystals.size());
			float selfCap = acxSelfDamage + ImMax(0.0f, acxWasteAmount);
			for (AcEntity& c : crystals) {
				// la lista llega hasta el rango de objetivos (13): sin este corte
				// golpeaba cada tick cristales fuera de alcance y, como el golpe
				// cerraba el tick, nunca colocaba
				if (c.dist > acxBreakRange) continue;
				if (AcxRecentlyHit(c.rid, kAcxRehitTicks)) continue;  // ya va en camino: el golpe va a otro
				glm::vec3 exp(c.pos.x, c.pos.y, c.pos.z);
				float selfD = selfDamageAt(exp);
				if (selfD >= (float)lp->getHealth()) continue;
				if (acxSelfDamage > 0.0f && selfD > selfCap) continue;
				float best = 0.0f;
				for (AcEntity& t : targets) {
					GaxBox box = acxDynamic ? AcxPredictedBox(t, g_acxVel[t.rid]) : t.box;
					float d = AcxDamageAt(t, region, box, exp);
					if (d > best) best = d;
				}
				if (best <= 0.0f || (acxEnemyDamage > 0.0f && best < acxEnemyDamage)) continue;
				picks.push_back({&c, exp, best});
			}
			std::sort(picks.begin(), picks.end(), [](const Pick& a, const Pick& b) {
				return a.dmg > b.dmg;
			});
			if (!picks.empty()) {
				Pick& best = picks.front();
				AcAttack(gm, best.c->actor);
				g_acxHits[best.c->rid] = g_acTick;
				lp->swing();
				g_acxLastBreak = g_acTick;
				g_acxAttackedThisTick = true;
				if (acxRotate) AcAimAt(GaxPos(lp), best.exp);
			}
		}
	}

	// --------------------------------------------------------------------------
	// Coloca
	// --------------------------------------------------------------------------
	bool hasCrystal = AcHasItem(lp, Ac::NameEndCrystal);
	int status = -1;  // -1: este tick no dice nada nuevo (retardo o alternado)
	int statBases = 0, statLow = 0, statSelf = 0;
	float statMinSelf = 1e9f;
	bool switchFailed = false;
	if (!eaterPaused && acxPlace && !(onePerTick && g_acxAttackedThisTick) && hasCrystal) {
		bool window = attackWindow || AcTicksSince(g_acxLastPlace) >= ImMax(0, acxPlaceDelay);
		if (window) {
			std::unordered_set<uint64_t> used;
			struct AcxCand {
				uint64_t key;
				vec3_ti base;
				glm::vec3 exp;
				float enemy;
				float self;
				float dist;
			};
			std::vector<AcxCand> cands;
			cands.reserve(64);
			for (AcEntity& t : targets) {
				if (cands.size() >= 96) break;
				int span = (int)ceilf(acxPlaceRange);
				if (span > 8) span = 8;
				int tx = (int)floorf(t.pos.x), tz = (int)floorf(t.pos.z), ty = (int)floorf(t.pos.y);
				const AcxTrack* tr = acxDynamic ? &g_acxVel[t.rid] : nullptr;
				GaxBox box = tr ? AcxPredictedBox(t, *tr) : t.box;
				GaxV3 lpPos = GaxPos(lp);
				for (int dx = -span; dx <= span; dx++) {
					int x = tx + dx;
					float pdx = (float)x + 0.5f - lpPos.x;
					for (int dz = -span; dz <= span; dz++) {
						int z = tz + dz;
						float pdz = (float)z + 0.5f - lpPos.z;
						if (pdx * pdx + pdz * pdz > acxPlaceRange * acxPlaceRange) continue;
						for (int y = ty - 3; y <= ty + 3; y++) {
							vec3_ti cell{x, y, z};
							glm::vec3 exp = AcExplosionOf(cell);
							float toT = AcDistTo(t.pos, GaxV3{exp.x, exp.y, exp.z});
							if (acxProximity > 0.0f && toT > acxProximity) continue;
							// jaula: dos aires (uno en modo Java)
							if (!AcIsAir(AcBlockAt(region, cell.x, cell.y + 1, cell.z))) continue;
							if (!acxJava && !AcIsAir(AcBlockAt(region, cell.x, cell.y + 2, cell.z))) continue;
							// base: obsidiana/bedrock (el juego no pone el
							// cristal sobre otra cosa)
							if (!AcIsBase(AcBlockAt(region, cell))) continue;
							// jaula libre de entidades (con fase el objetivo no
							// cuenta)
							if (!AcCageFree(boxes, cell, acxPhase ? &t.box : nullptr)) continue;
							uint64_t key = AcPackCell(x, y, z);
							if (used.count(key)) continue;
							bool occupied = false;
							for (const AcEntity& c : crystals) {
								if (AcxRecentlyHit(c.rid, kAcxGoneTicks)) continue;  // golpeado: el reemplazo va ya
								if (AcPackCell((int)floorf(c.pos.x), (int)(c.pos.y - 1.0f), (int)floorf(c.pos.z)) == key) { occupied = true; break; }
							}
							if (occupied) continue;
							statBases++;
							float e = AcxDamageAt(t, region, box, exp) + AcxIntercept(t, tr, exp);
							if (e < acxMinDamage) { statLow++; continue; }
							float selfD = selfDamageAt(exp);
							AcxCand cand{key, cell, exp, e, selfD, toT};
							cands.push_back(cand);
						}
					}
				}
			}
			// filtro de dano propio (con el Dinero desperdiciado ensanchando)
			float selfCap = acxSelfDamage + ImMax(0.0f, acxWasteAmount);
			for (AcxCand& c : cands) {
				if (acxSelfDamage > 0.0f && c.self > selfCap) {
					c.enemy = -1.0f;
					statSelf++;
					statMinSelf = ImMin(statMinSelf, c.self);
				}
			}
			std::sort(cands.begin(), cands.end(), [](const AcxCand& a, const AcxCand& b) {
				if (a.enemy < 0.0f != (b.enemy < 0.0f)) return a.enemy > b.enemy;
				// prioridad: 0 = mas danio; 1 = mas cerca (desempata danio)
				if (acxPriority == 1) {
					if (a.dist < b.dist - 0.5f) return true;
					if (b.dist < a.dist - 0.5f) return false;
				}
				if (a.enemy != b.enemy) return a.enemy > b.enemy;
				return a.dist < b.dist;
			});
			const int flushCap = ImClamp(acxPlaceCount, 1, 6);  // el original suelta hasta dos por tick
			int flushed = 0;
			float placedBest = 0.0f;
			std::vector<vec3_ti> placed;
			for (AcxCand& c : cands) {
				if (c.enemy < 0.0f) continue;
				if (flushed >= flushCap) break;
				if (used.count(c.key)) continue;  // la misma base vista desde otro objetivo
				if (acxSpread) {
					// repartidos: ninguno en las 26 celdas alrededor de otro de este gesto
					bool near = false;
					for (const vec3_ti& p : placed) {
						if (abs(p.x - c.base.x) <= 1 && abs(p.y - c.base.y) <= 1 && abs(p.z - c.base.z) <= 1) { near = true; break; }
					}
					if (near) continue;
				}
				int slot = AcSwitchSlot(lp, ci, acxSwitch, Ac::NameEndCrystal);
				if (slot < 0) {
					switchFailed = true;  // modo Ninguno sin el cristal en la mano
					break;
				}
				if (acxRotate) AcAimAt(GaxPos(lp), c.exp);
				OffhandFn<void (*)(void*, const void*, unsigned char, bool)>(Ac::GameModeBuildBlock)(
					(void*)gm, &c.base, 0, false);
				used.insert(c.key);
				placed.push_back(c.base);
				placedBest = ImMax(placedBest, c.enemy);
				g_acxLastPlace = g_acTick;
				flushed++;
				g_acxPlacedThisTick = true;
				if (onePerTick) { g_acxLastBreak = g_acTick; }  // (Alternado: el golpe ya llego)
				AcMark m;
				m.x = (float)c.base.x + 0.5f;
				m.y = (float)c.base.y + 0.5f;
				m.z = (float)c.base.z + 0.5f;
				m.enemy = c.enemy;
				m.self = c.self;
				m.flat = acxFlat;
				g_acxFrameMarks.push_back(m);
			}
			// ID Predict: el servidor procesa la colocacion y despues estos
			// golpes; el cristal nuevo toma uno de los IDs siguientes
			if (acxIDPredict && flushed > 0 && g_acxLastId && placedBest >= acxIDDamage &&
				(!g_acxIdTick || AcTicksSince(g_acxIdTick) >= acxIDDelay)) {
				int n = ImClamp(acxIDPackets, 1, 20);
				for (int i = 1; i <= n; i++) AcxSendIdAttack(lp, g_acxLastId + (uint64_t)i);
				static double idLogAt = 0.0;
				if (AcNow() - idLogAt >= 2.0) {  // GATYO_PROBE: tandas del ID Predict
					idLogAt = AcNow();
					__android_log_print(ANDROID_LOG_INFO, "Gatyo", "acx: id predict %llu..%llu",
						(unsigned long long)(g_acxLastId + 1), (unsigned long long)(g_acxLastId + n));
				}
				g_acxIdTick = g_acTick;
			}
			if (flushed > 0) status = ACX_ST_PLACING;
			else if (switchFailed) status = ACX_ST_NO_SWITCH;
			else if (statBases == 0) status = ACX_ST_NO_BASE;
			else if (statSelf > 0) status = ACX_ST_SELF_DAMAGE;
			else status = ACX_ST_LOW_DAMAGE;
		}
	}
	if (eaterPaused) status = ACX_ST_PAUSED;
	else if (!acxPlace) status = ACX_ST_OFF;
	else if (!hasCrystal) status = ACX_ST_NO_CRYSTAL;
	else if (targets.empty()) status = ACX_ST_NO_TARGET;
	if (status >= 0 && (!fast || status == ACX_ST_PLACING)) {
		// justo despues de colocar, el mejor lugar queda ocupado por el cristal
		// nuevo: eso no es un problema
		if (status >= ACX_ST_NO_BASE && status <= ACX_ST_SELF_DAMAGE && g_acxLastPlace && AcTicksSince(g_acxLastPlace) <= 10) status = ACX_ST_PLACING;
		g_acxStatBases = statBases;
		g_acxStatLow = statLow;
		g_acxStatSelf = statSelf;
		g_acxStatMinSelf = statSelf > 0 ? statMinSelf : 0.0f;
		AcxPublishStatus(status);
	}

	// --------------------------------------------------------------------------
	// Terreno: sin cristal puesto este tick (y con presupuesto y retardo
	// propios) coloca un soporte de obsidiana anclado cerca del objetivo. El
	// cristal sale el tick siguiente: la celda queda de obsidiana y el escaneo
	// la ve como base material.
	// --------------------------------------------------------------------------
	if (!fast && !eaterPaused && acxTerrain && !g_acxPlacedThisTick && AcHasItem(lp, Ac::NameObsidian)) {
		bool terrainNow = attackWindow || AcTicksSince(g_acxLastTerrain) >= ImMax(0, acxTerrainDelay);
		if (terrainNow) {
			int budget = ImMax(1, acxBlocksPerTick);
			std::unordered_set<uint64_t> skipped;
			for (AcEntity& t : targets) {
				if (budget <= 0) break;
				int span = (int)ceilf(acxTerrainProx);
				if (span > 6) span = 6;
				int tx = (int)floorf(t.pos.x), tz = (int)floorf(t.pos.z), ty = (int)floorf(t.pos.y);
				for (int dx = -span; dx <= span && budget > 0; dx++) {
					for (int dz = -span; dz <= span && budget > 0; dz++) {
						for (int y = ty - 2; y <= ty + 2 && budget > 0; y++) {
							vec3_ti cell{tx + dx, y, tz + dz};
							uint64_t key = AcPackCell(cell.x, cell.y, cell.z);
							if (skipped.count(key)) continue;
							bool queued = false;
							for (const AcxSupport& s : g_acxTerrain) if (s.cell == key) { queued = true; break; }
							if (queued) { skipped.insert(key); continue; }
							glm::vec3 exp = AcExplosionOf(cell);
							float toT = AcDistTo(t.pos, GaxV3{exp.x, exp.y, exp.z});
							if (acxProximity > 0.0f && toT > acxProximity) { skipped.insert(key); continue; }
							if (!AcIsAir(AcBlockAt(region, cell.x, cell.y, cell.z))) { skipped.insert(key); continue; }
							if (!AcIsAir(AcBlockAt(region, cell.x, cell.y + 1, cell.z))) { skipped.insert(key); continue; }
							if (!AcIsAir(AcBlockAt(region, cell.x, cell.y + 2, cell.z))) { skipped.insert(key); continue; }
							// se toca el vecino solido por la cara que mira a la
							// celda; sin vecino solo con Air Place (se toca la
							// celda de aire)
							vec3_ti clicked = cell;
							unsigned char face = 0;
							if (!AcxAnchor(region, cell, clicked, face) && !acxAirPlace) { skipped.insert(key); continue; }
							GaxBox box = acxDynamic ? AcxPredictedBox(t, g_acxVel[t.rid]) : t.box;
							float e = AcxDamageAt(t, region, box, exp);
							if (e < acxMinDamage) { skipped.insert(key); continue; }
							// jaula libre (con fase el objetivo no cuenta) y el
							// soporte mismo fuera de cualquier entidad (la jaula de
							// la celda de abajo es la celda del soporte)
							if (!AcCageFree(boxes, cell, acxPhase ? &t.box : nullptr)) { skipped.insert(key); continue; }
							if (!AcCageFree(boxes, vec3_ti{cell.x, cell.y - 1, cell.z}, nullptr)) { skipped.insert(key); continue; }
							int slot = AcSwitchSlot(lp, ci, acxSwitch, Ac::NameObsidian);
							if (slot < 0) break;  // sin obsidiana en el inventario
							if (acxRotate) AcAimAt(GaxPos(lp), exp);
							OffhandFn<void (*)(void*, const void*, unsigned char, bool)>(Ac::GameModeBuildBlock)(
								(void*)gm, &clicked, face, false);
							AcxSupport s{key, g_acTick};
							g_acxTerrain.push_back(s);
							g_acxLastTerrain = g_acTick;
							budget--;
						}
					}
				}
			}
			// purga: soportes maduros o muertos
			for (auto it = g_acxTerrain.begin(); it != g_acxTerrain.end(); ) {
				if ((int32_t)(g_acTick - it->tick) > 100) it = g_acxTerrain.erase(it);
				else ++it;
			}
		}
	}

	// Fin del gesto: el slot vuelve a su estado original (cliente y servidor).
	AcSlotsEnd(lp, ci);
	if (!fast || !g_acxFrameMarks.empty()) AcStoreMarks(g_acxMarks, g_acxFrameMarks);
	g_acxFrameMarks.clear();
	AcClearExpCache();
}

static void AutoCrystalXOnNormalTick(LocalPlayer* lp, Level* level, GameMode* gm) {
	if (!autoCrystalX) {
		if (g_acxWas) {
			AcxReset();
			g_acxStatus = ACX_ST_OFF;
		}
		return;
	}
	g_acxWas = true;
	AcAdvanceTick();
	g_acxLp = nullptr;
	if (panic || inMenu || !lp || !level || !gm || !GaxValid(lp) || lp->getHealth() <= 0) return;
	for (auto it = g_acxHits.begin(); it != g_acxHits.end(); ) {
		if (AcTicksSince(it->second) > 40) it = g_acxHits.erase(it);
		else ++it;
	}
	AcxRun(lp, level, gm, false);
	g_acxLp = lp;
	g_acxTickAt = AcNow();
	g_acxFastBudget = kAcxFastPerTick;
}

// Pase rapido: solo con el jugador del ultimo tick, todavia vigente.
static bool AcxFastReady() {
	if (!autoCrystalX || panic || inMenu || !g_acxLp || localPlayer != g_acxLp) return false;
	if (g_acxFastBudget <= 0 || AcNow() - g_acxTickAt > 0.25) return false;
	return GaxValid(g_acxLp) && g_acxLp->getHealth() > 0;
}

// Cristales a mano (para ver si un RemoveActor se llevo uno).
static int AcxCrystalCount() {
	if (!AcxFastReady()) return 0;
	Level* level = g_acxLp->getLevel();
	if (!level) return 0;
	GaxV3 l = GaxPos(g_acxLp);
	float r = ImMax(acxBreakRange, acxPlaceRange) + 2.0f;
	int n = 0;
	for (Mob* mob : level->getRuntimeActorList()) {
		if (AcIsCrystal(mob) && AcDistTo(l, GaxPos(mob)) <= r) n++;
	}
	return n;
}

// Lo llama netinject_gatyo.h despues de entregar el paquete al juego.
static void AcxOnNetActor(bool added, int before) {
	if (!AcxFastReady()) return;
	LocalPlayer* lp = g_acxLp;
	Level* level = lp->getLevel();
	GameMode* gm = lp->getGameMode();
	if (!level || !gm) return;
	if (added) {
		// solo si aparecio un cristal que todavia nadie golpeo
		if (!acxBreak) return;
		GaxV3 l = GaxPos(lp);
		bool fresh = false;
		for (Mob* mob : level->getRuntimeActorList()) {
			if (!AcIsCrystal(mob) || AcDistTo(l, GaxPos(mob)) > acxBreakRange) continue;
			if (AcxRecentlyHit(AcRuntimeId(mob), kAcxRehitTicks)) continue;
			fresh = true;
			break;
		}
		if (!fresh) return;
	} else {
		if (!acxPlace || before <= 0 || AcxCrystalCount() >= before) return;
	}
	g_acxFastBudget--;
	AcxRun(lp, level, gm, true);
}

// ---------------------------------------------------------------------------
// Render overlay (copia + deslizamiento/lerp + fade por celda)
// ---------------------------------------------------------------------------
struct AcxFadeState {
	float yOffset = 0.5f;
	float alpha = 0.0f;
	double lastSeen = -1000.0;
};

static std::vector<AcMark> g_acxOverlay;
static std::unordered_map<uint64_t, AcxFadeState> g_acxFade;
static double g_acxOverlayLast = 0.0;

static inline uint64_t AcxRenderKey(const AcMark& m) {
	int x = (int)floorf(m.x), y = (int)floorf(m.y), z = (int)floorf(m.z);
	return (uint64_t)(uint32_t)(x & 0x1FFFFF) |
		   ((uint64_t)(uint32_t)(z & 0x1FFFFF) << 21) |
		   ((uint64_t)(uint32_t)(y & 0x1FFFFF) << 42);
}

static void RenderAutoCrystalX(ImDrawList* dl, vec3_t cameraPos, glm::vec2 axisFov, glm::mat4 viewMatrix) {
	if (!g_viewValid || !autoCrystalX || !acxRender) {
		if (g_acxFade.size() > 256) g_acxFade.clear();
		return;
	}
	double now = AcNow();
	float dt = (float)ImMax(0.001, now - g_acxOverlayLast);
	g_acxOverlayLast = now;
	float fadeDur = ImMax(0.25f, (float)acxFadeDuration * 0.05f);

	{  // copia del snapshot del juego
		std::lock_guard<std::mutex> lock(g_acxMarks.mutex);
		g_acxOverlay = g_acxMarks.shared;
	}

	for (AcMark& m : g_acxOverlay) {
		uint64_t key = AcxRenderKey(m);
		auto it = g_acxFade.find(key);
		if (it == g_acxFade.end()) {
			AcxFadeState st;
			g_acxFade[key] = st;
			it = g_acxFade.find(key);
		}
		it->second.lastSeen = now;
	}

	for (auto it = g_acxFade.begin(); it != g_acxFade.end(); ) {
		AcxFadeState& st = it->second;
		bool seen = (st.lastSeen >= now);
		if (seen) {
			st.alpha = acxFade ? ImMin(1.0f, st.alpha + dt * (1.0f / ImMax(0.2f, fadeDur * 0.25f))) : 1.0f;
			st.yOffset = acxLerp ? AcApproach(st.yOffset, 0.0f, ImMax(1.0f, acxSpeed), dt) : 0.0f;
			++it;
		} else if (acxFade) {
			st.alpha -= dt / fadeDur;
			if (st.alpha <= 0.0f) it = g_acxFade.erase(it);
			else ++it;
		} else {
			it = g_acxFade.erase(it);
		}
	}

	for (AcMark& m : g_acxOverlay) {
		auto it = g_acxFade.find(AcxRenderKey(m));
		if (it == g_acxFade.end() || it->second.alpha <= 0.0f) continue;
		float a = it->second.alpha;
		glm::vec3 lo(m.x - 0.5f, m.y + 0.5f + it->second.yOffset, m.z - 0.5f);
		glm::vec3 hi(m.x + 0.5f, lo.y + (m.flat ? 0.08f : 1.0f), m.z + 0.5f);
		ImVec4 fill(acxFillColor[0], acxFillColor[1], acxFillColor[2], acxFillColor[3] * a);
		ImVec4 line(acxLineColor[0], acxLineColor[1], acxLineColor[2], acxLineColor[3] * a);
		GatyoBox3D(dl, g_view, lo, hi,
				   ImGui::ColorConvertFloat4ToU32(line), ImMax(1.0f, 1.2f * scaleGlobal),
				   ImGui::ColorConvertFloat4ToU32(fill), 0);
		if (acxDamageText) {
			char txt[8];
			snprintf(txt, sizeof(txt), "%.0f", m.enemy);
			float fs = 9.0f * ImMax(0.6f, scaleGlobal);
			glm::vec3 top(m.x, hi.y + 0.05f, m.z);
			GatyoText3D(dl, g_view, top, txt,
						ImGui::ColorConvertFloat4ToU32(ImVec4(acxTextColor[0], acxTextColor[1], acxTextColor[2], acxTextColor[3] * a)), fs);
			if (m.self > 0.4f) {
				snprintf(txt, sizeof(txt), "-%.0f", m.self);
				glm::vec3 below(m.x, hi.y + 0.5f, m.z);
				GatyoText3D(dl, g_view, below, txt,
							ImGui::ColorConvertFloat4ToU32(ImVec4(1.0f, 0.35f, 0.35f, acxTextColor[3] * a)), fs * 0.8f);
			}
		}
	}
}

#else
// Otros ABIs: no-ops con la misma firma.
static void AutoCrystalXOnNormalTick(LocalPlayer*, Level*, GameMode*) {}
static int AcxCrystalCount() { return 0; }
static void AcxOnNetActor(bool, int) {}
static void RenderAutoCrystalX(ImDrawList*, vec3_t, glm::vec2, glm::mat4) {}
#endif
