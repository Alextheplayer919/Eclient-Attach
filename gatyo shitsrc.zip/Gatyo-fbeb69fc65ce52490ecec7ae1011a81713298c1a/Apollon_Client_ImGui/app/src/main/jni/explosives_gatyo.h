#pragma once
// Base comun de AutoAnchor, AutoBed, AutoCity, AutoTrap y PacketMine. Reusa la
// capa de la suite de cristales (crystal_common_gatyo.h: objetivos, slots,
// paquetes, rotacion) y le suma lo que estos modulos necesitan y los cristales
// no:
//
//   - offsets de libminecraftpe.so 1.21.111 arm64 (IDA, imagebase 0): nombres
//     de item/bloque (respawn_anchor, glowstone, bed), vtables de las
//     dimensiones, las funciones de minado de GameMode y el estado de carga del
//     anchor
//   - dimension del jugador por RTTI: el anchor solo explota fuera del Nether y
//     la cama solo dentro de el (y en el End); el Dimension* de un BlockSource
//     vive en +56 (lo guarda el constructor, 0xCEE24A4)
//   - estados de bloque: Block::getState<int> esta inlinado (asi lo lee
//     RespawnAnchorBlock, 0xDC7BB90). BlockType (Block + 0x78) guarda en +560 un
//     std::map id de estado -> {bit final, bits}; los datos del bloque son un
//     uint16 en Block + 112. Con eso se lee la carga real del anchor
//   - dano de explosion con radio propio (el cristal usa 12; el anchor y la
//     cama son potencia 5 = radio 10) y exposicion que puede ignorar una celda
//     (el bloque que se va a romper cuenta como aire)
//   - un ancla de colocacion que evita bloques con interaccion (cofres, mesas,
//     camas, anchors...) y liquidos: hacerles clic abriria la interfaz o
//     cargaria el bloque en vez de apoyar el nuevo
//   - render (hilo de ImGui, solo copias): cajas sombreadas que deslizan, laten
//     y se desvanecen, texto de dano, luces de carga, barras de progreso, cama
//     plana, cristal girando y ondas al explotar

#if defined(__aarch64__)
#include <sys/uio.h>
#include <unistd.h>

namespace Ex {
	enum : uintptr_t {
		// HashedString de VanillaItemNames / VanillaBlockTypeIds (los dos grupos de
		// globals guardan el mismo texto: isInstance compara hash + cadena)
		NameRespawnAnchor = 0x10747450,  // "minecraft:respawn_anchor"
		NameGlowstone = 0x10742A68,      // "minecraft:glowstone" (no "glowstone_dust")
		NameBed = 0x1073F0C0,            // "minecraft:bed" (todos los colores, sin aux)
		NameEnderPearl = 0x1071F768,     // los mismos de visuals_gatyo.h
		NameXpBottle = 0x1071F7B8,

		// VanillaStates::RespawnAnchorCharge (BlockState): +8 id (113), +0x10
		// variantes (5). Lo construye 0xD90F1BC.
		StateAnchorCharge = 0x10736C20,

		// vtables (punto de la vtable = _ZTV + 0x10) de Dimension: Overworld,
		// Nether y TheEnd
		VtblOverworld = 0xFF1EF58 + 0x10,
		VtblNether = 0xFF1EC68 + 0x10,
		VtblEnd = 0xFF1CAB0 + 0x10,

		// GameMode (vtable 0x1037C3A8): 2 startDestroyBlock, 3 destroyBlock,
		// 4 continueDestroyBlock. buildBlock es el 7 (Ac::GameModeBuildBlock).
		GameModeStartDestroy = 0xCCC0BB8,    // (GameMode*, BlockPos const&, uchar face, bool& hasDestroyed)
		GameModeDestroyBlock = 0xCCC1260,    // (GameMode*, BlockPos const&, uchar face); en server-auth exige progreso 1
		GameModeContinueDestroy = 0xCCC1890, // (GameMode*, BlockPos const&, uchar face, vec3 const& pos, bool& hasDestroyed)
		GameModeDestroyRate = 0xCCC1F38,     // float (GameMode*, Block const&): progreso por tick con la mano actual
	};
	static const int kBlockSourceDimension = 56;  // BlockSource -> Dimension*
	static const int kGameModeProgress = 36;      // GameMode: float del progreso de minado
	static const int kBlockData = 112;            // Block: uint16 con los bits de los estados
	static const int kTypeStateMap = 560;         // BlockType: nodo final del std::map de estados
	static const int kStateId = 8;                // BlockState: id
}

enum ExDim { EX_DIM_OVERWORLD = 0, EX_DIM_NETHER = 1, EX_DIM_END = 2, EX_DIM_UNKNOWN = 3 };

// Lectura que falla en vez de crashear si la direccion no es valida.
static bool ExSafeRead(uintptr_t address, void* out, size_t size) {
	struct iovec local = {out, size}, remote = {(void*)address, size};
	return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) == (ssize_t)size;
}

// Dimension del BlockSource por la vtable de su objeto Dimension. Cualquier
// otra (dimensiones a medida) cuenta como desconocida; los modulos la tratan
// como el Overworld.
static int ExDimensionOf(BlockSource* region) {
	if (!region) return EX_DIM_UNKNOWN;
	uintptr_t dim = 0, vtable = 0;
	if (!ExSafeRead((uintptr_t)region + Ex::kBlockSourceDimension, &dim, 8) || !dim) return EX_DIM_UNKNOWN;
	if (!ExSafeRead(dim, &vtable, 8) || !vtable) return EX_DIM_UNKNOWN;
	uintptr_t base = OffhandBase();
	if (vtable == base + Ex::VtblNether) return EX_DIM_NETHER;
	if (vtable == base + Ex::VtblEnd) return EX_DIM_END;
	if (vtable == base + Ex::VtblOverworld) return EX_DIM_OVERWORLD;
	return EX_DIM_UNKNOWN;
}

// El anchor explota fuera del Nether; la cama, en el Nether y en el End.
static bool ExAnchorExplodes(int dim) { return dim != EX_DIM_NETHER; }
static bool ExBedExplodes(int dim) { return dim == EX_DIM_NETHER || dim == EX_DIM_END; }

// ---------------------------------------------------------------------------
// Bloques
// ---------------------------------------------------------------------------
// Nombre sin prefijo ("obsidian", "bed"): la std::string de BlockType + 8, la
// misma que lee AcBlockIs.
static const char* ExBlockName(Block* block) {
	if (!block) return "";
	BlockType* type = block->getBlockTypeClassCustom();
	if (!type) return "";
	const std::string& name = *(const std::string*)((char*)type + 8);
	size_t cut = name.find_last_of(".:");
	return name.c_str() + (cut == std::string::npos ? 0 : cut + 1);
}

static bool ExIsAnchorBlock(Block* block) { return AcBlockIs(block, "respawn_anchor"); }
static bool ExIsBedBlock(Block* block) { return AcBlockIs(block, "bed"); }

// Valor de un estado del bloque, como Block::getState<int> (inlinado en el
// juego): lower_bound del id en el std::map del BlockType y los bits que dice
// la entrada, sobre los datos del bloque. -1 si el bloque no tiene ese estado.
static int ExBlockState(Block* block, uint64_t stateId) {
	if (!block) return -1;
	char* type = (char*)block->getBlockTypeClassCustom();
	if (!type) return -1;
	char* end = type + Ex::kTypeStateMap;
	char* node = *(char**)end;  // raiz (el __left_ del nodo final)
	char* best = end;
	for (int guard = 0; node && guard < 48; guard++) {
		if (*(uint64_t*)(node + 32) >= stateId) {
			best = node;
			node = *(char**)node;          // izquierda
		} else {
			node = *(char**)(node + 8);    // derecha
		}
	}
	if (best == end || stateId < *(uint64_t*)(best + 32)) return -1;
	int endBit = *(int*)(best + 40), numBits = *(int*)(best + 44);
	if (numBits <= 0 || numBits > 16 || endBit < numBits - 1 || endBit > 15) return -1;
	uint16_t data = *(uint16_t*)((char*)block + Ex::kBlockData);
	return (data >> (endBit - numBits + 1)) & (0xFFFF >> (16 - numBits));
}

// Cargas del anchor (0..4); -1 si no es un anchor o no se pudo leer.
static int ExAnchorCharge(Block* block) {
	if (!ExIsAnchorBlock(block)) return -1;
	uint64_t id = *(uint64_t*)(OffhandBase() + Ex::StateAnchorCharge + Ex::kStateId);
	int charge = ExBlockState(block, id);
	return charge >= 0 && charge <= 4 ? charge : -1;
}

static bool ExIsLiquid(Block* block) {
	const char* n = ExBlockName(block);
	return strstr(n, "water") || strstr(n, "lava");
}

// Bloques que reaccionan al clic: apoyar algo contra ellos abre la interfaz,
// carga el bloque o lo activa en vez de colocar.
static bool ExIsInteractive(Block* block) {
	const char* n = ExBlockName(block);
	if (!*n) return false;
	// "bed" a secas: como subcadena atraparia "bedrock", y el techo y el piso del
	// Nether son de bedrock
	if (strcmp(n, "bed") == 0 || strcmp(n, "respawn_anchor") == 0) return true;
	static const char* const kParts[] = {
		"chest", "barrel", "shulker", "furnace", "smoker", "table", "anvil", "hopper", "dropper", "dispenser",
		"crafter", "door", "gate", "button", "lever", "sign", "beacon", "brewing", "jukebox", "note_block",
		"noteblock", "loom", "grindstone", "stonecutter", "lectern", "command", "bell", "composter", "cauldron",
		"repeater", "comparator", "daylight", "campfire", "candle", "cake", "flower_pot", "potted", "bookshelf",
		"vault", "spawner", "portal_frame",
	};
	for (const char* part : kParts) {
		if (strstr(n, part)) return true;
	}
	return false;
}

// Como AcxAnchor pero sin liquidos ni bloques con interaccion, y con el de
// arriba como ultima opcion. Devuelve el bloque a tocar y la cara que mira a la
// celda (FacingID: 0 abajo, 1 arriba, 2 norte, 3 sur, 4 oeste, 5 este).
static bool ExAnchor(BlockSource* region, const vec3_ti& cell, vec3_ti& clicked, unsigned char& face) {
	static const int kDirs[6][4] = {{0, -1, 0, 1}, {1, 0, 0, 4}, {-1, 0, 0, 5}, {0, 0, 1, 2}, {0, 0, -1, 3}, {0, 1, 0, 0}};
	for (const auto& d : kDirs) {
		vec3_ti n{cell.x + d[0], cell.y + d[1], cell.z + d[2]};
		Block* b = AcBlockAt(region, n);
		if (AcIsAir(b) || ExIsLiquid(b) || ExIsInteractive(b)) continue;
		clicked = n;
		face = (unsigned char)d[3];
		return true;
	}
	return false;
}

// Bloque macizo debajo para sostener una cama o un anchor: no aire, no liquido.
static bool ExHasSupport(BlockSource* region, int x, int y, int z) {
	Block* b = AcBlockAt(region, x, y - 1, z);
	return !AcIsAir(b) && !ExIsLiquid(b);
}

// ---------------------------------------------------------------------------
// Geometria
// ---------------------------------------------------------------------------
// Distancia del ojo a la caja del bloque (el punto mas cercano), lo que mide el
// alcance del juego.
static float ExDistToBlock(const GaxV3& eye, const vec3_ti& b) {
	float cx = ImClamp(eye.x, (float)b.x, (float)b.x + 1.0f);
	float cy = ImClamp(eye.y, (float)b.y, (float)b.y + 1.0f);
	float cz = ImClamp(eye.z, (float)b.z, (float)b.z + 1.0f);
	return AcDist3F(eye.x, eye.y, eye.z, cx, cy, cz);
}

// Cara del bloque que mira al jugador (FacingID), para el inicio de minado.
static unsigned char ExFaceToward(const GaxV3& eye, const vec3_ti& b) {
	float dx = eye.x - ((float)b.x + 0.5f), dy = eye.y - ((float)b.y + 0.5f), dz = eye.z - ((float)b.z + 0.5f);
	float ax = fabsf(dx), ay = fabsf(dy), az = fabsf(dz);
	if (ay >= ax && ay >= az) return dy > 0.0f ? 1 : 0;
	if (ax >= az) return dx > 0.0f ? 5 : 4;
	return dz > 0.0f ? 3 : 2;
}

static bool ExSameCell(const vec3_ti& a, const vec3_ti& b) { return a.x == b.x && a.y == b.y && a.z == b.z; }

// Huella del AABB en celdas (puede cruzar el borde de un bloque).
struct ExFootprint {
	int x0, z0, x1, z1, feetY;
};
static ExFootprint ExFootprintOf(const GaxBox& b) {
	ExFootprint f;
	f.x0 = (int)floorf(b.lower.x + 0.001f);
	f.x1 = ImMax(f.x0, (int)floorf(b.upper.x - 0.001f));
	f.z0 = (int)floorf(b.lower.z + 0.001f);
	f.z1 = ImMax(f.z0, (int)floorf(b.upper.z - 0.001f));
	f.feetY = (int)floorf(b.lower.y + 0.01f);
	return f;
}

// ---------------------------------------------------------------------------
// Dano de explosion con radio propio y exposicion que ignora una celda
// ---------------------------------------------------------------------------
// Anchor y cama: potencia 5, radio 10 (el cristal es potencia 6, radio 12).
static const float kExBlastRadius = 10.0f;

// Raycast a celdas igual que AcRayClear, pero la celda "ignore" cuenta como
// aire (el bloque que AutoCity esta por romper) y la de la explosion siempre
// queda libre.
static bool ExRayClear(BlockSource* region, const glm::vec3& from, const glm::vec3& to, const vec3_ti* ignore) {
	if (!region) return true;
	glm::vec3 dir = to - from;
	float dist = glm::length(dir);
	if (dist < 0.1f) return true;
	dir /= dist;
	int steps = (int)(dist / 0.25f);
	if (steps < 1) steps = 1;
	float stepLen = dist / (float)steps;
	glm::vec3 explosionCell = glm::floor(to);
	for (int i = 1; i < steps; i++) {
		glm::vec3 p = from + dir * (stepLen * (float)i);
		glm::vec3 cell = glm::floor(p);
		if (cell == explosionCell) continue;
		if (ignore && (int)cell.x == ignore->x && (int)cell.y == ignore->y && (int)cell.z == ignore->z) continue;
		Block* b = region->getBlock(vec3_ti{(int)cell.x, (int)cell.y, (int)cell.z});
		if (!AcIsAir(b)) return false;
	}
	return true;
}

static float ExSeenPercent(BlockSource* region, const GaxBox& box, const glm::vec3& center, const vec3_ti* ignore) {
	glm::vec3 lo(box.lower.x, box.lower.y, box.lower.z);
	glm::vec3 hi(box.upper.x, box.upper.y, box.upper.z);
	int seen = 0;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				glm::vec3 p(
					lo.x + (hi.x - lo.x) * (0.25f + 0.25f * i),
					lo.y + (hi.y - lo.y) * (0.25f + 0.25f * j),
					lo.z + (hi.z - lo.z) * (0.25f + 0.25f * k));
				if (ExRayClear(region, p, center, ignore)) seen++;
			}
		}
	}
	return (float)seen / 27.0f;
}

// Misma escala que AcxDamage (hasta ~80 sin armadura con radio 10), con la
// armadura y la proteccion estimada del original.
static float ExBlastDamage(const GaxBox& box, const glm::vec3& center, float exposure, int armor, int pieces, float radius) {
	float cx = (box.lower.x + box.upper.x) * 0.5f;
	float cy = (box.lower.y + box.upper.y) * 0.5f;
	float cz = (box.lower.z + box.upper.z) * 0.5f;
	float d = AcDist3F(cx, cy, cz, center.x, center.y, center.z);
	float v = d / radius;
	if (v > 1.0f) return 0.0f;
	float impact = (1.0f - v) * exposure;
	if (impact <= 0.0f) return 0.0f;
	float raw = (float)(int)(((impact * impact + impact) * 0.5f) * 8.0f * radius + 1.0f);
	float afterArmor = raw - ((float)ImClamp(armor, 0, 255) * raw) * 0.04f;
	float prot = ImMin(20.0f, ceilf(ImMin(25.0f, (float)(pieces * 5)) * 0.5f));
	return ImMax(afterArmor - (prot * afterArmor) * 0.04f, 0.0f);
}

// Dano de una explosion de bloque en "center" sobre un actor.
static float ExDamageTo(const AcEntity& who, BlockSource* region, const glm::vec3& center, const vec3_ti* ignore) {
	float exposure = ExSeenPercent(region, who.box, center, ignore);
	return ExBlastDamage(who.box, center, exposure, who.armor, who.armorPieces, kExBlastRadius);
}

static glm::vec3 ExCenterOf(const vec3_ti& c) {
	return glm::vec3((float)c.x + 0.5f, (float)c.y + 0.5f, (float)c.z + 0.5f);
}

// ---------------------------------------------------------------------------
// Slots
// ---------------------------------------------------------------------------
// Como AcSwitchSlot pero a un slot ya elegido (hotbar). Hay que haber abierto
// el gesto con AcSlotsBegin.
static int ExSwitchTo(LocalPlayer* lp, void* ci, int mode, int slot) {
	if (slot < 0 || slot >= kAcHotbarSlots) return -1;
	int client = AcClientSlot(lp);
	if (mode == AC_SW_NONE) return client == slot ? slot : -1;
	if (client != slot) {
		AcWriteClientSlot(lp, slot);
		g_acSlots.wroteClient = true;
	}
	g_acSlots.switched = slot;
	if (mode != AC_SW_SILENT && g_acSlots.server != slot) {
		AcSendMobEquipment(lp, ci, slot);
		g_acSlots.server = slot;
	}
	return slot;
}

// Slot para detonar con la carga confirmada: cualquiera que no sea glowstone
// (con glowstone el anchor se carga en vez de explotar).
static int ExNonGlowstoneSlot(LocalPlayer* lp) {
	int client = AcClientSlot(lp);
	if (client >= 0 && client < kAcHotbarSlots && !AcStackIs(AcItemInSlot(AcContainer(lp), client), Ex::NameGlowstone)) return client;
	for (int i = 0; i < kAcHotbarSlots; i++) {
		if (!AcStackIs(AcItemInSlot(AcContainer(lp), i), Ex::NameGlowstone)) return i;
	}
	return -1;
}

// Un clic a un anchor SIN carga con un bloque en la mano coloca ese bloque
// encima (asi se apilaban los anchors sin explotar): para detonar sin saber si
// la carga llego solo sirve un item que no sea bloque, o la mano vacia. Las
// manzanas, perlas y botellas tampoco: el clic las usaria.
static bool ExSafeDetonatorItem(void* stack) {
	if (!stack || OffhandFn<bool (*)(void*)>(GatyoInventory::ItemStackIsNull)(stack)) return true;
	if (*(void**)((char*)stack + kAcStackBlock) != nullptr) return false;
	if (AcStackIs(stack, Ac::NameGoldenApple) || AcStackIs(stack, Ac::NameEnchantedApple)) return false;
	if (AcStackIs(stack, Ex::NameEnderPearl) || AcStackIs(stack, Ex::NameXpBottle)) return false;
	return true;
}

// Primero el que el jugador tenia en la mano (llamar despues de AcSlotsBegin y
// antes de cambiar nada), despues el primero de la hotbar. -1 si no hay.
static int ExSafeDetonatorSlot(LocalPlayer* lp) {
	void* container = AcContainer(lp);
	int client = AcClientSlot(lp);
	if (client >= 0 && client < kAcHotbarSlots && ExSafeDetonatorItem(AcItemInSlot(container, client))) return client;
	for (int i = 0; i < kAcHotbarSlots; i++) {
		if (ExSafeDetonatorItem(AcItemInSlot(container, i))) return i;
	}
	return -1;
}

// Apunta el yaw (la cama se orienta hacia donde mira el jugador); el pitch se
// deja como esta.
static void ExAimYaw(LocalPlayer* lp, float yaw) {
	vec2_t* rot = lp->getRotation();
	g_crystalPitch = AcWrap90(rot ? rot->x : 0.0f);
	g_crystalYaw = AcWrap180(yaw);
	g_crystalAimTick = g_acTick;
	g_crystalAimOn = true;
}

// ---------------------------------------------------------------------------
// Secuencias de explosivos (las usan AutoAnchor/AutoBed y AutoCity)
// ---------------------------------------------------------------------------
enum ExRun {
	EXR_DONE,          // se mando la detonacion
	EXR_PENDING,       // se coloco o se cargo y falta que el servidor responda: se retoma el tick siguiente
	EXR_AIMING,        // el yaw de la cama se esta entregando al servidor
	EXR_NO_ITEM,       // el anchor / la cama no esta en la hotbar
	EXR_NO_GLOWSTONE,
	EXR_NO_SWITCH,     // esta en la hotbar pero Cambio de slot esta en Ninguno
	EXR_NO_DETONATOR,  // la carga no se ve todavia y no hay un item que no sea bloque para detonar
	EXR_REJECTED,      // el servidor no acepta la carga de este anchor: se abandona
};

static void ExBuildAt(GameMode* gm, const vec3_ti& clicked, unsigned char face) {
	OffhandFn<void (*)(void*, const void*, unsigned char, bool)>(Ac::GameModeBuildBlock)((void*)gm, &clicked, face, false);
}

// El anchor que se esta trabajando.
struct ExAnchorJob {
	bool valid = false;
	vec3_ti cell{0, 0, 0};
	uint64_t key = 0;
	uint32_t tick = 0;         // desde cuando se trabaja (o se puso)
	uint32_t chargedAt = 0;    // ultimo glowstone mandado
	uint32_t detonatedAt = 0;  // ultima detonacion mandada
	int charges = 0;           // glowstone mandados sin que la carga se viera
	int lastCharge = -1;       // la carga leida la ultima vez
};
static const int kExChargeWait = 4;    // ticks que se espera la respuesta de un glowstone
static const int kExChargeTries = 4;   // glowstone sin efecto antes de abandonar el anchor

// Colocar -> cargar -> detonar, lo que se pueda en este tick, decidiendo con la
// carga REAL del bloque:
//   - sin anchor: se coloca; si el cliente todavia no lo ve, se sigue al tick
//     siguiente (hacerle clic al aire pondria el glowstone encima)
//   - carga 0: un glowstone, y no otro hasta que el servidor tuvo tiempo de
//     responder. Si varios glowstone no cambian la carga, el servidor la esta
//     rechazando y el anchor se abandona
//   - detonar: con un item que no sea bloque siempre (si la carga no llego, el
//     clic no hace nada); con la carga ya vista, con cualquier cosa menos
//     glowstone. Nunca con un bloque sobre un anchor sin carga: eso los apilaba
static int ExRunAnchor(LocalPlayer* lp, GameMode* gm, BlockSource* region, const vec3_ti& cell, const vec3_ti& clicked,
					   unsigned char face, int mode, ExAnchorJob& job, AcRetryRing& retry) {
	void* ci = (void*)CI;
	uint64_t key = AcPackCell(cell.x, cell.y, cell.z);
	if (!job.valid || job.key != key) {
		job = ExAnchorJob();
		job.valid = true;
		job.cell = cell;
		job.key = key;
		job.tick = g_acTick;
	}
	int result = EXR_DONE;
	AcSlotsBegin(lp);
	int safeSlot = ExSafeDetonatorSlot(lp);  // con el slot del jugador, antes de cambiar nada
	Block* block = AcBlockAt(region, cell);
	bool exists = ExIsAnchorBlock(block);
	if (!exists) {
		if (!AcHasItem(lp, Ex::NameRespawnAnchor)) {
			result = EXR_NO_ITEM;
		} else if (AcSwitchSlot(lp, ci, mode, Ex::NameRespawnAnchor) < 0) {
			result = EXR_NO_SWITCH;
		} else {
			ExBuildAt(gm, clicked, face);
			retry.Note(key);
			job.tick = g_acTick;
			job.chargedAt = job.detonatedAt = 0;
			job.charges = 0;
			block = AcBlockAt(region, cell);
			exists = ExIsAnchorBlock(block);  // el cliente predice la colocacion
			if (!exists) result = EXR_PENDING;
		}
	}
	int charge = exists ? ExAnchorCharge(block) : -1;
	if (result == EXR_DONE) {
		if (charge > 0) job.charges = 0;  // la carga llego
		bool waiting = job.chargedAt != 0 && AcTicksSince(job.chargedAt) < kExChargeWait;
		// sin poder leer la carga se vuelve a cargar solo de vez en cuando
		bool needCharge = charge == 0 || (charge < 0 && (job.chargedAt == 0 || AcTicksSince(job.chargedAt) > 60));
		if (needCharge && !waiting) {
			if (charge == 0 && job.charges >= kExChargeTries) {
				result = EXR_REJECTED;
			} else if (!AcHasItem(lp, Ex::NameGlowstone)) {
				result = EXR_NO_GLOWSTONE;
			} else if (AcSwitchSlot(lp, ci, mode, Ex::NameGlowstone) < 0) {
				result = EXR_NO_SWITCH;
			} else {
				ExBuildAt(gm, cell, 1);  // glowstone sobre la cara de arriba del anchor
				job.chargedAt = g_acTick;
				if (charge == 0) job.charges++;
				int now = ExAnchorCharge(AcBlockAt(region, cell));  // si el cliente lo predijo, ya se ve
				if (now >= 0) charge = now;
			}
		}
	}
	if (result == EXR_DONE) {
		int slot = safeSlot;
		if (slot < 0 && charge > 0) slot = ExNonGlowstoneSlot(lp);
		// sin item seguro: con carga 0 se espera a verla llegar (despues sirve
		// cualquier cosa menos glowstone); sin poder leerla no se detona
		if (slot < 0) {
			result = charge == 0 ? EXR_PENDING : EXR_NO_DETONATOR;
		} else if (ExSwitchTo(lp, ci, mode, slot) < 0) {
			result = EXR_NO_SWITCH;
		} else {
			ExBuildAt(gm, cell, 1);  // con la carga puesta, explota
			job.detonatedAt = g_acTick;
			if (charge == 0) result = EXR_PENDING;  // si la carga no llego, el clic no hizo nada
		}
	}
	job.lastCharge = charge;
	AcSlotsEnd(lp, ci);
	lp->swing();
	return result;
}

// La cama que se esta trabajando y el yaw que se le esta entregando al servidor.
struct ExBedJob {
	bool valid = false;
	vec3_ti foot{0, 0, 0};
	vec3_ti head{0, 0, 0};
	uint32_t tick = 0;
	uint32_t detonatedAt = 0;
};
struct ExBedAim {
	float yaw = 0.0f;
	uint32_t since = 0, last = 0;
};

// El yaw llega al servidor en el paquete de movimiento, que sale DESPUES de la
// colocacion del mismo tick: se apunta un tick y se coloca al siguiente.
static bool ExBedAimed(ExBedAim& aim, float yaw) {
	bool same = aim.last != 0 && AcTicksSince(aim.last) <= 2 && fabsf(AcWrap180(aim.yaw - yaw)) < 0.5f;
	if (!same) {
		aim.yaw = yaw;
		aim.since = g_acTick;
	}
	aim.last = g_acTick;
	return same && AcTicksSince(aim.since) >= 1;
}

// Clic a la cama: con un item que no sea bloque si hay (nada puede quedar
// encima), si no con lo que haya en la mano.
static void ExBedClick(LocalPlayer* lp, GameMode* gm, void* ci, int mode, const vec3_ti& at) {
	int slot = ExSafeDetonatorSlot(lp);
	if (slot >= 0) ExSwitchTo(lp, ci, mode, slot);
	ExBuildAt(gm, at, 1);
}

// Apuntar -> colocar -> explotar. Si la cama ya esta, solo la hace explotar.
static int ExRunBed(LocalPlayer* lp, GameMode* gm, BlockSource* region, const vec3_ti& foot, const vec3_ti& head,
					const vec3_ti& clicked, unsigned char face, float yaw, bool rotate, int mode, ExBedJob& job,
					ExBedAim& aim, AcRetryRing& retry) {
	void* ci = (void*)CI;
	bool footBed = ExIsBedBlock(AcBlockAt(region, foot));
	bool headBed = ExIsBedBlock(AcBlockAt(region, head));
	if (footBed || headBed) {
		AcSlotsBegin(lp);
		ExBedClick(lp, gm, ci, mode, footBed ? foot : head);
		AcSlotsEnd(lp, ci);
		lp->swing();
		job.detonatedAt = g_acTick;
		return EXR_DONE;
	}
	if (!AcHasItem(lp, Ex::NameBed)) return EXR_NO_ITEM;
	if (rotate) {
		ExAimYaw(lp, yaw);
		if (!ExBedAimed(aim, yaw)) return EXR_AIMING;
	}
	AcSlotsBegin(lp);
	if (AcSwitchSlot(lp, ci, mode, Ex::NameBed) < 0) {
		AcSlotsEnd(lp, ci);
		return EXR_NO_SWITCH;
	}
	ExBuildAt(gm, clicked, face);
	retry.Note(AcPackCell(foot.x, foot.y, foot.z));
	job.valid = true;
	job.foot = foot;
	job.head = head;
	job.tick = g_acTick;
	job.detonatedAt = 0;
	int result = EXR_PENDING;
	if (ExIsBedBlock(AcBlockAt(region, foot))) {  // el cliente predice la colocacion
		ExBedClick(lp, gm, ci, mode, foot);
		job.detonatedAt = g_acTick;
		result = EXR_DONE;
	}
	AcSlotsEnd(lp, ci);
	lp->swing();
	return result;
}

#endif  // __aarch64__

// ---------------------------------------------------------------------------
// Render (hilo de ImGui). El tick publica marcas; aca se animan: fade de
// entrada y salida (la salida se encoge hacia el centro), la marca principal
// de cada modulo desliza entre posiciones, el relleno late, las caras se
// sombrean como un bloque, y encima van el texto de dano, las luces de carga
// del anchor y la barra de progreso. Las explosiones dejan una onda.
// ---------------------------------------------------------------------------
enum ExMarkStyle : uint8_t {
	EXM_BOX = 0,    // caja comun
	EXM_ANCHOR,     // caja + cuatro luces de carga arriba
	EXM_BED,        // cama plana (pie + cabeza) con almohada
	EXM_CRYSTAL,    // rombo que gira y flota
	EXM_CITY,       // el bloque que se mina: borde que late y barra de progreso
	EXM_TRAP,       // hueco pendiente
	EXM_TRAP_HOT,   // hueco que se coloca en este tick (late mas fuerte)
};

struct ExMark {
	float x0 = 0.0f, y0 = 0.0f, z0 = 0.0f, x1 = 1.0f, y1 = 1.0f, z1 = 1.0f;
	float enemy = -1.0f, self = -1.0f;  // dano en texto (<0: sin texto)
	float progress = -1.0f;             // barra 0..1 (<0: sin barra)
	int8_t charge = -1;                 // cargas del anchor (-1: no se sabe)
	int8_t hx = 0, hz = 0;              // cama: direccion de la cabeza desde el pie
	uint8_t style = EXM_BOX;
	uint8_t slot = 0;                   // >0: marca principal del modulo, desliza entre posiciones
	char label[16] = {0};
};

static ExMark ExMarkCell(const vec3_ti& c, uint8_t style, uint8_t slot = 0) {
	ExMark m;
	m.x0 = (float)c.x; m.y0 = (float)c.y; m.z0 = (float)c.z;
	m.x1 = m.x0 + 1.0f; m.y1 = m.y0 + 1.0f; m.z1 = m.z0 + 1.0f;
	m.style = style;
	m.slot = slot;
	return m;
}

struct ExOverlay {
	std::mutex mutex;
	std::vector<ExMark> shared;
	struct Live {
		ExMark mark;
		glm::vec3 lo{0.0f}, hi{1.0f};  // donde se dibuja ahora (desliza hacia la marca)
		float alpha = 0.0f;
		float born = 0.0f;
		bool live = false;
	};
	std::unordered_map<uint64_t, Live> lives;  // solo el hilo de ImGui
};

static void ExPublish(ExOverlay& ov, const std::vector<ExMark>& marks) {
	std::lock_guard<std::mutex> lock(ov.mutex);
	ov.shared = marks;
}

static uint64_t ExMarkKey(const ExMark& m) {
	if (m.slot) return 0x7F00000000000000ull | m.slot;
	int x = (int)floorf(m.x0 + 0.01f), y = (int)floorf(m.y0 + 0.01f), z = (int)floorf(m.z0 + 0.01f);
	return ((uint64_t)(uint32_t)(x & 0x1FFFFF)) | ((uint64_t)(uint32_t)(z & 0x1FFFFF) << 21) | ((uint64_t)(uint32_t)(y & 0x1FFFFF) << 42);
}

static ImVec4 ExLerpColor(const float* a, const float* b, float t) {
	t = ImClamp(t, 0.0f, 1.0f);
	return ImVec4(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t);
}

// Caja con las caras sombreadas como un bloque (arriba clara, abajo oscura; las
// de atras mas tenues para que se lea a traves) y un borde con sombra.
static void ExDrawBox(ImDrawList* dl, glm::vec3 lo, glm::vec3 hi, ImVec4 fill, ImVec4 line, float th) {
	glm::vec3 c[8];
	GatyoBoxCorners(lo, hi, c);
	if (fill.w > 0.003f) {
		glm::vec3 center = (lo + hi) * 0.5f;
		for (const auto& f : kGatyoBoxFaces) {
			glm::vec3 face[4] = {c[f[0]], c[f[1]], c[f[2]], c[f[3]]};
			ImVec4 col = fill;
			if (fxShaded) {
				glm::vec3 fc = (face[0] + face[1] + face[2] + face[3]) * 0.25f;
				glm::vec3 out = fc - center;
				float len = ImMax(glm::length(out), 1e-4f);
				float up = out.y / len;
				float light = up > 0.5f ? 1.25f : (up < -0.5f ? 0.55f : (fabsf(out.x) > fabsf(out.z) ? 0.9f : 0.75f));
				bool facing = glm::dot(out, g_view.cam - fc) > 0.0f;
				col = ImVec4(ImMin(1.0f, fill.x * light), ImMin(1.0f, fill.y * light), ImMin(1.0f, fill.z * light), fill.w * (facing ? 1.0f : 0.4f));
			}
			GatyoFillPolygon3D(dl, g_view, face, 4, GatyoU32(col));
		}
	}
	if (line.w > 0.003f) {
		ImU32 shadow = GatyoU32(ImVec4(0.0f, 0.0f, 0.0f, line.w * 0.35f));
		ImU32 edge = GatyoU32(line);
		for (const auto& e : kGatyoBoxEdges) GatyoLine3D(dl, g_view, c[e[0]], c[e[1]], shadow, th + 1.6f);
		for (const auto& e : kGatyoBoxEdges) GatyoLine3D(dl, g_view, c[e[0]], c[e[1]], edge, th);
	}
}

// Rectangulo horizontal a la altura y.
static void ExFlatQuad(ImDrawList* dl, float x0, float z0, float x1, float z1, float y, ImVec4 color) {
	glm::vec3 q[4] = {glm::vec3(x0, y, z0), glm::vec3(x1, y, z0), glm::vec3(x1, y, z1), glm::vec3(x0, y, z1)};
	GatyoFillPolygon3D(dl, g_view, q, 4, GatyoU32(color));
}

// Cuatro luces en la cara de arriba: una por carga.
static void ExDrawCharge(ImDrawList* dl, glm::vec3 lo, glm::vec3 hi, int charge, float alpha, float now) {
	if (charge < 0) return;
	float w = hi.x - lo.x, d = hi.z - lo.z, y = hi.y + 0.015f;
	static const float kPos[4][2] = {{0.3f, 0.3f}, {0.7f, 0.3f}, {0.3f, 0.7f}, {0.7f, 0.7f}};
	float glow = fxPulse ? 0.8f + 0.2f * sinf(now * 6.0f) : 1.0f;
	for (int i = 0; i < 4; i++) {
		float cx = lo.x + w * kPos[i][0], cz = lo.z + d * kPos[i][1], s = ImMin(w, d) * 0.11f;
		bool lit = i < charge;
		ImVec4 col = lit ? ImVec4(1.0f, 0.62f, 0.12f, 0.95f * alpha * glow) : ImVec4(0.12f, 0.08f, 0.2f, 0.55f * alpha);
		ExFlatQuad(dl, cx - s, cz - s, cx + s, cz + s, y, col);
		if (lit) ExFlatQuad(dl, cx - s * 1.8f, cz - s * 1.8f, cx + s * 1.8f, cz + s * 1.8f, y - 0.004f, ImVec4(1.0f, 0.55f, 0.1f, 0.22f * alpha * glow));
	}
}

// Barra de progreso sobre la cara de arriba, del color de inicio al de final.
static void ExDrawProgress(ImDrawList* dl, glm::vec3 lo, glm::vec3 hi, float progress, float alpha) {
	float p = ImClamp(progress, 0.0f, 1.0f);
	float y = hi.y + 0.02f;
	float x0 = lo.x + (hi.x - lo.x) * 0.08f, x1 = hi.x - (hi.x - lo.x) * 0.08f;
	float zc = (lo.z + hi.z) * 0.5f, hw = (hi.z - lo.z) * 0.09f;
	ExFlatQuad(dl, x0, zc - hw, x1, zc + hw, y, ImVec4(0.0f, 0.0f, 0.0f, 0.45f * alpha));
	if (p > 0.001f) {
		ImVec4 col = ExLerpColor(pmStartColor, pmEndColor, p);
		col.w = ImMin(1.0f, col.w * alpha * 1.1f);
		ExFlatQuad(dl, x0, zc - hw, x0 + (x1 - x0) * p, zc + hw, y + 0.003f, col);
	}
}

// Texto con contorno en pantalla, centrado en x, con la base en y.
static void ExText(ImDrawList* dl, ImVec2 at, const char* text, ImU32 color, float fontSize) {
	ImVec2 size = ImGui::CalcTextSize(text);
	size.x *= fontSize / ImGui::GetFontSize();
	size.y *= fontSize / ImGui::GetFontSize();
	ImVec2 pos(at.x - size.x * 0.5f, at.y - size.y);
	ImU32 outline = GatyoU32(GatyoAlpha(GatyoState::Shadow, 0.9f * ((color >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f));
	dl->AddText(nullptr, fontSize, ImVec2(pos.x - 1, pos.y - 1), outline, text);
	dl->AddText(nullptr, fontSize, ImVec2(pos.x + 1, pos.y + 1), outline, text);
	dl->AddText(nullptr, fontSize, ImVec2(pos.x - 1, pos.y + 1), outline, text);
	dl->AddText(nullptr, fontSize, ImVec2(pos.x + 1, pos.y - 1), outline, text);
	dl->AddText(nullptr, fontSize, pos, color, text);
}

// Etiqueta, dano al rival y dano propio, apilados sobre la caja.
static void ExDrawLabels(ImDrawList* dl, const ExMark& m, glm::vec3 lo, glm::vec3 hi, float alpha) {
	if (!fxText) return;
	ImVec2 s;
	if (!GatyoWorldToScreen(g_view, glm::vec3((lo.x + hi.x) * 0.5f, hi.y + 0.2f, (lo.z + hi.z) * 0.5f), s)) return;
	float fs = 11.0f * ImMax(0.6f, scaleGlobal);
	ImU32 text = GatyoU32(ImVec4(fxTextColor[0], fxTextColor[1], fxTextColor[2], fxTextColor[3] * alpha));
	char buf[32];
	if (m.self >= 0.05f) {
		snprintf(buf, sizeof(buf), "-%.1f", m.self);
		ExText(dl, s, buf, GatyoU32(ImVec4(1.0f, 0.38f, 0.38f, 0.95f * alpha)), fs * 0.8f);
		s.y -= fs * 0.85f;
	}
	if (m.enemy >= 0.0f) {
		snprintf(buf, sizeof(buf), "%.1f", m.enemy);
		ExText(dl, s, buf, text, fs * 1.1f);
		s.y -= fs * 1.15f;
	}
	if (m.label[0]) ExText(dl, s, m.label, GatyoU32(ImVec4(fxTextColor[0], fxTextColor[1], fxTextColor[2], 0.75f * fxTextColor[3] * alpha)), fs * 0.8f);
}

// Cama plana (9/16 de alto) sobre el pie y la cabeza, con la almohada clara en
// la cabeza.
static void ExDrawBed(ImDrawList* dl, glm::vec3 footLo, const ExMark& m, ImVec4 fill, ImVec4 line, float th, float scale) {
	glm::vec3 headLo = footLo + glm::vec3((float)m.hx, 0.0f, (float)m.hz);
	glm::vec3 lo = glm::min(footLo, headLo), hi = glm::max(footLo, headLo) + glm::vec3(1.0f, 0.0f, 1.0f);
	hi.y = lo.y + 0.5625f;
	if (scale < 0.999f) {
		glm::vec3 c = (lo + hi) * 0.5f, h = (hi - lo) * 0.5f * scale;
		lo = c - h;
		hi = c + h;
		headLo = c + (headLo - c) * scale;
	}
	ExDrawBox(dl, lo, hi, fill, line, th);
	float ps = scale;
	glm::vec3 pLo(headLo.x + 0.12f * ps, hi.y, headLo.z + 0.12f * ps), pHi(headLo.x + 0.88f * ps, hi.y + 0.12f * ps, headLo.z + 0.88f * ps);
	ImVec4 pillow(ImMin(1.0f, fill.x * 0.4f + 0.6f), ImMin(1.0f, fill.y * 0.4f + 0.6f), ImMin(1.0f, fill.z * 0.4f + 0.6f), ImMin(1.0f, fill.w * 1.8f));
	ExDrawBox(dl, pLo, pHi, pillow, ImVec4(line.x, line.y, line.z, line.w * 0.6f), ImMax(1.0f, th * 0.7f));
}

// Rombo (octaedro) que gira y flota, donde va el cristal.
static void ExDrawCrystal(ImDrawList* dl, glm::vec3 lo, glm::vec3 hi, ImVec4 fill, ImVec4 line, float th, float now) {
	glm::vec3 c = (lo + hi) * 0.5f;
	float r = (hi.x - lo.x) * 0.5f;
	c.y += sinf(now * 3.0f) * 0.08f;
	float ang = now * 2.2f;
	glm::vec3 top = c + glm::vec3(0.0f, r * 1.5f, 0.0f), bottom = c - glm::vec3(0.0f, r * 1.5f, 0.0f);
	glm::vec3 ring[4];
	for (int i = 0; i < 4; i++) {
		float a = ang + (float)i * 1.5707963f;
		ring[i] = c + glm::vec3(cosf(a) * r, 0.0f, sinf(a) * r);
	}
	for (int i = 0; i < 4; i++) {
		glm::vec3 t1[3] = {top, ring[i], ring[(i + 1) % 4]};
		glm::vec3 t2[3] = {bottom, ring[(i + 1) % 4], ring[i]};
		float light = (i % 2) ? 1.2f : 0.8f;
		ImVec4 f1(ImMin(1.0f, fill.x * light), ImMin(1.0f, fill.y * light), ImMin(1.0f, fill.z * light), fill.w * 1.6f);
		ImVec4 f2(fill.x * 0.6f, fill.y * 0.6f, fill.z * 0.6f, fill.w * 1.4f);
		GatyoFillPolygon3D(dl, g_view, t1, 3, GatyoU32(f1));
		GatyoFillPolygon3D(dl, g_view, t2, 3, GatyoU32(f2));
	}
	ImU32 edge = GatyoU32(line);
	for (int i = 0; i < 4; i++) {
		GatyoLine3D(dl, g_view, top, ring[i], edge, th);
		GatyoLine3D(dl, g_view, bottom, ring[i], edge, th);
		GatyoLine3D(dl, g_view, ring[i], ring[(i + 1) % 4], edge, th);
	}
}

static void ExDrawMark(ImDrawList* dl, const ExOverlay::Live& l, const float* fill, const float* line, float now) {
	const ExMark& m = l.mark;
	float a = l.alpha;
	glm::vec3 lo = l.lo, hi = l.hi;
	// entrada: crece un poco (pop); salida: se encoge hacia el centro
	float scale = l.live ? ImMin(1.0f, 0.7f + (now - l.born) * 3.0f) : 0.5f + 0.5f * a;
	if (scale < 0.999f && m.style != EXM_BED) {
		glm::vec3 c = (lo + hi) * 0.5f, h = (hi - lo) * 0.5f * scale;
		lo = c - h;
		hi = c + h;
	}
	float pulse = 1.0f;
	if (fxPulse) pulse = m.style == EXM_TRAP_HOT ? 1.0f + 0.45f * sinf(now * 14.0f) : 0.8f + 0.2f * sinf(now * 4.0f);
	else if (m.style == EXM_TRAP_HOT) pulse = 1.35f;
	ImVec4 fc(fill[0], fill[1], fill[2], ImClamp(fill[3] * a * pulse, 0.0f, 1.0f));
	ImVec4 lc(line[0], line[1], line[2], line[3] * a);
	if (m.style == EXM_CITY && fxPulse) lc.w = ImClamp(lc.w * (0.75f + 0.35f * sinf(now * 6.0f)), 0.0f, 1.0f);
	float th = ImMax(1.0f, 1.4f * scaleGlobal);
	switch (m.style) {
		case EXM_BED: ExDrawBed(dl, lo, m, fc, lc, th, scale); break;
		case EXM_CRYSTAL: ExDrawCrystal(dl, lo, hi, fc, lc, th, now); break;
		default: ExDrawBox(dl, lo, hi, fc, lc, th); break;
	}
	if (m.style == EXM_ANCHOR) ExDrawCharge(dl, lo, hi, m.charge, a, now);
	if (m.progress >= 0.0f) ExDrawProgress(dl, lo, hi, m.progress, a);
	glm::vec3 textHi = hi;
	if (m.style == EXM_BED) textHi.y = lo.y + 0.7f;
	ExDrawLabels(dl, m, lo, textHi, a);
}

static void ExRenderOverlay(ImDrawList* dl, ExOverlay& ov, bool enabled, bool useFade, const float* fill, const float* line) {
	if (!enabled || !g_viewValid) {
		ov.lives.clear();
		return;
	}
	std::vector<ExMark> marks;
	{
		std::lock_guard<std::mutex> lock(ov.mutex);
		marks = ov.shared;
	}
	float now = (float)ImGui::GetTime();
	float dt = ImClamp(ImGui::GetIO().DeltaTime, 0.0f, 0.1f);
	for (auto& kv : ov.lives) kv.second.live = false;
	for (const ExMark& m : marks) {
		uint64_t key = ExMarkKey(m);
		glm::vec3 lo(m.x0, m.y0, m.z0), hi(m.x1, m.y1, m.z1);
		auto it = ov.lives.find(key);
		if (it == ov.lives.end()) {
			ExOverlay::Live fresh;
			fresh.lo = lo;
			fresh.hi = hi;
			fresh.born = now;
			it = ov.lives.emplace(key, fresh).first;
		}
		ExOverlay::Live& l = it->second;
		// una marca que reaparece despues de irse arranca donde esta ahora
		if (l.alpha <= 0.02f) {
			l.lo = lo;
			l.hi = hi;
			l.born = now;
		}
		l.mark = m;
		l.live = true;
		if (fxSlide && m.slot) {
			float k = ImMin(1.0f, dt * ImMax(1.0f, fxSlideSpeed));
			l.lo += (lo - l.lo) * k;
			l.hi += (hi - l.hi) * k;
		} else {
			l.lo = lo;
			l.hi = hi;
		}
	}
	for (auto it = ov.lives.begin(); it != ov.lives.end();) {
		ExOverlay::Live& l = it->second;
		l.alpha = l.live ? ImMin(1.0f, l.alpha + dt * 6.0f) : (useFade ? l.alpha - dt * 2.2f : 0.0f);
		if (!l.live && l.alpha <= 0.0f) {
			it = ov.lives.erase(it);
			continue;
		}
		ExDrawMark(dl, l, fill, line, now);
		++it;
	}
}

// ---------------------------------------------------------------------------
// Ondas de explosion: el tick avisa, el render dibuja un anillo que se abre, un
// destello y chispas.
// ---------------------------------------------------------------------------
struct ExBurst {
	float x, y, z;
	ImVec4 color;
	float size;
	float start;  // <0: todavia no lo vio el render
};
static std::mutex g_exBurstMutex;
static std::vector<ExBurst> g_exBurstPending;  // tick -> render
static std::vector<ExBurst> g_exBursts;        // solo el hilo de ImGui

static void ExPushBurst(float x, float y, float z, const float* color, float size) {
	if (!fxShockwave) return;
	std::lock_guard<std::mutex> lock(g_exBurstMutex);
	if (g_exBurstPending.size() < 16) g_exBurstPending.push_back({x, y, z, ImVec4(color[0], color[1], color[2], 1.0f), size, -1.0f});
}

static void RenderExBursts(ImDrawList* dl) {
	{
		std::lock_guard<std::mutex> lock(g_exBurstMutex);
		for (const ExBurst& b : g_exBurstPending) g_exBursts.push_back(b);
		g_exBurstPending.clear();
	}
	if (!g_viewValid || !fxShockwave) {
		g_exBursts.clear();
		return;
	}
	float now = (float)ImGui::GetTime();
	const float dur = 0.75f;
	float th = ImMax(1.0f, 1.6f * scaleGlobal);
	for (auto it = g_exBursts.begin(); it != g_exBursts.end();) {
		if (it->start < 0.0f) it->start = now;
		float t = (now - it->start) / dur;
		if (t >= 1.0f) {
			it = g_exBursts.erase(it);
			continue;
		}
		float ease = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
		float fade = powf(1.0f - t, 1.6f);
		glm::vec3 c(it->x, it->y, it->z);
		ImVec4 col = it->color;
		ImU32 ring = GatyoU32(ImVec4(col.x, col.y, col.z, 0.9f * fade));
		// dos anillos: uno en el piso que se abre y otro mas chico que sube
		for (int r = 0; r < 2; r++) {
			float radius = it->size * (r == 0 ? (0.3f + 3.0f * ease) : (0.2f + 1.8f * ease));
			float y = c.y + (r == 0 ? -0.45f : 0.6f * ease) * it->size;
			glm::vec3 prev(c.x + radius, y, c.z);
			for (int i = 1; i <= 40; i++) {
				float a = (float)i / 40.0f * 6.2831853f;
				glm::vec3 p(c.x + cosf(a) * radius, y, c.z + sinf(a) * radius);
				GatyoLine3D(dl, g_view, prev, p, ring, th * (r == 0 ? 1.3f : 1.0f));
				prev = p;
			}
		}
		// destello: una caja que crece y se apaga rapido
		float flash = ImMax(0.0f, 1.0f - t * 2.2f);
		if (flash > 0.0f) {
			float h = 0.5f * it->size * (1.0f + 0.9f * ease);
			GatyoBox3D(dl, g_view, c - glm::vec3(h), c + glm::vec3(h), GatyoU32(ImVec4(1.0f, 1.0f, 1.0f, 0.5f * flash)), th,
					   GatyoU32(ImVec4(col.x, col.y, col.z, 0.3f * flash)));
		}
		// chispas hacia afuera y arriba
		ImU32 spark = GatyoU32(ImVec4(ImMin(1.0f, col.x + 0.3f), ImMin(1.0f, col.y + 0.3f), ImMin(1.0f, col.z + 0.3f), fade));
		for (int i = 0; i < 10; i++) {
			float a = (float)i * 0.6283185f + 0.3f;
			glm::vec3 dir(cosf(a), 0.55f + 0.35f * sinf((float)i * 2.1f), sinf(a));
			float len = it->size * 2.2f;
			GatyoLine3D(dl, g_view, c + dir * (len * ease * 0.55f), c + dir * (len * ease), spark, th);
		}
		++it;
	}
}

// Onda en el centro de una celda.
static void ExBurstAtCell(const vec3_ti& c, const float* color, float size) {
	ExPushBurst((float)c.x + 0.5f, (float)c.y + 0.5f, (float)c.z + 0.5f, color, size);
}
