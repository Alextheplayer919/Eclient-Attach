// Excerpt of Apollon main.cpp: Intersects (target lock / rotations), NormalTick (KillAura target collection + attack), PlayerAuthInputPacket (rotation write).
// Lines 407-905 of the original main.cpp, unmodified.

void *(*old_Intersects)(Mob *thiz, vec3_t *a2, vec3_t *a3);
void *Intersects(Mob *thiz, vec3_t *a2, vec3_t *a3) {
	if (panic) return old_Intersects(thiz, a2, a3);
	if (inMenu) return old_Intersects(thiz, a2, a3);
	if (thiz == localPlayer) {
		
		if (look360) {
			if (notSaved) {
				saveAngle = *thiz->getRotation();
				saveYHeadRot = thiz->getYHeadRot();
				notSaved = false;
		    }
			thiz->setRotationX(saveAngle.x);
			thiz->setRotationY(saveAngle.y);
			thiz->setYHeadRot(saveYHeadRot);
		} else {
			notSaved = true;
		}
		
		if (!isLANGame) {
		    if (derp) {
				thiz->setYHeadRot(derpGradys);
			    thiz->setYBodyRotation(derpGradys);
		    }
		}
		
		if (fireballRotation || itemRotation || !mobList.empty() || !playerList.empty()) {
			if (rotations) {
                if (!isLANGame && !emulateNativeAttack) thiz->setYBodyRotation(auraAngle.y);
			    thiz->setYHeadRot(auraAngle.y);
                thiz->setRotationX(auraAngle.x);
            }
            if (targetLock) {
                thiz->setRotationY(auraAngle.y);
            }
		}
    }
    return old_Intersects(thiz, a2, a3);
}

void *(*old_NormalTick)(LocalPlayer *thiz);
void *NormalTick(LocalPlayer *thiz) {
	if (panic) return old_NormalTick(thiz);
	localPlayer = NULL;
	if (inMenu) {
		isLoaded = true;
		return old_NormalTick(thiz);
	}
	
	//inMemoryFunction = format("Instance: %llX", thiz);
	
	if (isLoaded) {
		thiz->displayClientMessage(oxorany("§l§0[§5Apollon Client§0]§r Good Luck, Have Fun!"), "");
		isLoaded = false;
	}
	
	localPlayer = thiz;
	vec2_t *playerRot = thiz->getRotation();
	vec3_t *playerPos = thiz->getPosition();
	globalPlayerRot = *playerRot;
	globalPlayerPos = *playerPos;
	Level *myLevel = thiz->getLevel();
	GameMode *myGameMode = thiz->getGameMode();
	BlockSource *myBlockSource = thiz->getDimensionBlockSource();

	if (myBlockSource && xrayDefault) {
    for (int i = renderOresESP.size() - 1; i >= 0; i--) {
        vec3_t orePosition = {(float)renderOresESP[i].orePos.x, (float)renderOresESP[i].orePos.y, (float)renderOresESP[i].orePos.z};
        vec3_t camPos = {CameraPos.x, CameraPos.y, CameraPos.z};
        float distanceToBlock = distanceTo(&camPos, &orePosition);
        
        if (distanceToBlock > 32.0f) {
            renderOresESP.erase(renderOresESP.begin() + i);
            removedCount++;
            continue;
        }
        
        // ПРОВЕРКА НА AIR БЛОК
        Block *currentBlock = myBlockSource->getBlock(renderOresESP[i].orePos);
        if (!allowToXrayRender(renderOresESP[i].oreName) || currentBlock->isAir()) {
            renderOresESP.erase(renderOresESP.begin() + i);
            removedCount++;
			continue;
        }
    }
    
    if (removedCount >= 32) {
        rebuildChunkGeometry = true;
        removedCount = 0;
    }
} else {
    renderOresESP.clear();
}
	
	if (showPosition) {
	    playerPosX = playerPos->x;
	    playerPosY = playerPos->y;
	    playerPosY = playerPosY - 1.62;
	    playerPosZ = playerPos->z;
	}
	
	if (thiz->getHealth() == 0) {
		if (deathPosition) {
			vec3_t *deathPos = thiz->getPosition();
	        playerDeathPosX = deathPos->x;
	        playerDeathPosY = deathPos->y;
	        playerDeathPosY = playerDeathPosY - 1.62;
	        playerDeathPosZ = deathPos->z;
		}
		return old_NormalTick(thiz);
	}
	
	if (damageFly) {
		myGameMode->attack(thiz, true);
		myGameMode->attack(thiz, true);
		thiz->swing();
	}
	
	if (!isLANGame) {
		#if defined(__ARM_ARCH_7A__)
		LocalPlayer *EntityAccess = (LocalPlayer *)((char *)thiz + 4);
		#else
		LocalPlayer *EntityAccess = (LocalPlayer *)((char *)thiz + 8);
		#endif
	    if (strafe) {
			EntityAccess->setOnGround(1, true);
			EntityAccess->setIsJumping(0, true);
		}
		if (noJumpDelay) EntityAccess->setNoJumpDelay(1, 0);
		if (alwaysSprinting) thiz->setSprinting(true);
	    if (ladderFly) thiz->setClimbing(true);
	    if (step) {
	        thiz->initializeMaxAutoStep(1.0625);
	    } else {
		    thiz->initializeMaxAutoStep(0.5625);
	    }
		if (creativeFly) {
			thiz->getAbilities()->getLayer(2)->setAbility(10, true);
			activatedCreativeFly = true;
		} else if (activatedCreativeFly && !creativeFly) {
			if (thiz->isAttackableGamemode()) thiz->getAbilities()->getLayer(2)->setAbility(10, false);
			activatedCreativeFly = false;
		}
		if (forceCreativeFly) {
			thiz->getAbilities()->getLayer(2)->setAbility(9, true);
			activatedForceCreativeFly = true;
		} else if (activatedForceCreativeFly && !forceCreativeFly) {
			if (thiz->isAttackableGamemode()) thiz->getAbilities()->getLayer(2)->setAbility(9, false);
			activatedCreativeFly = false;
		}
	} else thiz->initializeMaxAutoStep(0.5625);
	
	std::vector<Mob*> actors = myLevel->getRuntimeActorList();
	nearestMob = NULL;
	fireballRotation = false;
	itemRotation = false;
	mobList.clear();
	
	for (Mob *object : actors) {
		if (object != thiz) {
			if (antiInvis) object->setInvisible(false);
			vec3_t *targetPos = object->getPosition();
			vec2_t *targetHitBox = object->getAABBDim();
			vec2_t calcTargetHitBox = *targetHitBox;
			float distanceToActor = mobDistanceTo(playerPos, targetPos, calcTargetHitBox.y);
			
			int ActorId = object->getEntityTypeId();
			if (distanceToActor <= 10 && ActorId == 4194389) {
			    if (antiFireball) {
					if (rotations) {
                        vec3_t calcObjPos = *targetPos;
                        auraAngle = globalPlayerPos.CalcPlayerAngle(calcObjPos);
						fireballRotation = true;
				    }
					myGameMode->attack(object, true);
			        if (swing) thiz->swing();
				}
				continue;
			} else if (distanceToActor <= 7 && ActorId == 64) {
			    if (killItems) {
					if (rotations) {
                        vec3_t calcObjPos = *targetPos;
                        auraAngle = globalPlayerPos.CalcPlayerAngle(calcObjPos);
						itemRotation = true;
				    }
				    myGameMode->attack(object, true);
			        if (swing) thiz->swing();
			    }
				continue;
			} else {
				if (mobAura) {
				    if (distanceToActor <= mobAuraRange && object->getHealth() != 0 && MobDetected(ActorId)) mobList.push_back(object);
                }
			}
		}
	}
	
	nearestTarget = NULL;
	nearestKillTarget = NULL;
	nearFriendList.clear();
	playerList.clear();
	nearPlayerList.clear();
	nearPlayer.clear();
	std::vector<Player*> nearPlayers;
	
    myLevel->getGameplayUserManager()->forEachActivePlayer([&](Player& objectt) {
        nearPlayers.push_back(&objectt);
		return true;
    }, true);

	for (Player *objectt : nearPlayers) {
		 if (objectt == thiz) continue;
		vec2_t* AABB = objectt->getAABBDim();
		const std::string PlayerName = objectt->getName();
		const std::string PlayerNameTag = objectt->getNameTag();
		vec2_t Hitbox = *AABB;
				
        if (antiBot) {
            if (PlayerName.length() <= 1) continue;
			if (PlayerNameTag.length() <= 1) continue;
            if (!AABB) continue;
            if (Hitbox.y < 0.05f || Hitbox.x < 0.05f || Hitbox.y > 2.1f || Hitbox.x > 10.9f) continue;
        }
		
			bool isFriend = false;
			bool isBotList = false;

			for (std::string currentPlayer : botList) {
				if (currentPlayer == PlayerName) {
				    isBotList = true;
					break;
				}
			}
			
			if (!isBotList) {
				for (std::string currentPlayer : friendList) {
				    if (currentPlayer == PlayerName) {
					    if (playerNear) nearFriendList.push_back(PlayerName);
				        isFriend = true;
						break;
				    }
			    }
			}
			
			bool isAttackable = objectt->isAttackableGamemode();
			if (!isFriend && !isBotList) {
				AABB->x = hitBox ? hitBoxValue : 0.6;
				nearPlayer.push_back(PlayerName);
			}
					
			int targetHealth = objectt->getHealth();
			vec3_t* targetPos = objectt->getPosition();
			
            nearPlayerList.push_back({PlayerName, PlayerNameTag, targetPos, Hitbox, targetHealth, objectt->getHurtTime(), objectt->getPlatform(), !isAttackable, isFriend, isBotList});
					
            if (killAura) {
				float distanceTo = hackDistanceTo(playerPos, targetPos);
				if (distanceTo <= rotationsRange) {
                    if (isAttackable && !isFriend && !isBotList && targetHealth != 0) {
                        if (rotations || targetLock) {
                            if (distanceTo <= rotationsRange) {
                                playerList.push_back(objectt);
                            }
                        } else {
                            if (distanceTo <= killRange) {
                                playerList.push_back(objectt);
                            }
                        }
                    }
			    }
            }
	}
	
		if (!mobList.empty()) {
			switch (auraType) {
				case 0: {
					if (rotations || targetLock) {
						vec3_t *objPos = mobList[0]->getPosition();
						vec2_t *hitBox = mobList[0]->getAABBDim();
                        vec3_t calcObjPos = *objPos;
						vec2_t calcHitBox = *hitBox;
                        auraAngle = globalPlayerPos.CalcMobAngle(calcObjPos, calcHitBox.y);
					}
					bool canHurt = true;
					if (hurtCheck) canHurt = mobList[0]->canBeHurted();
					if (canMobAuraDamage && canHurt) {
						myGameMode->attack(mobList[0], true);
                        if (swing) thiz->swing();
                        canMobAuraDamage = false;
                    }
				break;
				}
				case 1: {
					float nearestMobDistance = 9999;
                    for (Mob *potentialTarget : mobList) {
						if (potentialTarget != NULL) {
							vec2_t *potentialHitBox = potentialTarget->getAABBDim();
							vec2_t calcPotentialHitBox = *potentialHitBox;
							float potentialDistance = mobDistanceTo(playerPos, potentialTarget->getPosition(), calcPotentialHitBox.y);
                            if (potentialDistance < nearestMobDistance && potentialDistance <= mobAuraRange) {
                                nearestMobDistance = potentialDistance;
                                nearestMob = potentialTarget;
                            }
						}
                    }
					if (nearestMob != NULL) {
						//inMemoryFunction = nearestMob->getNameTag();
						//nearActorId = nearestMob->getEntityTypeId();
						if (rotations || targetLock) {
							vec3_t* objPos = nearestMob->getPosition();
							vec2_t *hitBox = nearestMob->getAABBDim();
                            vec3_t calcObjPos = *objPos;
							vec2_t calcHitBox = *hitBox;
                            auraAngle = globalPlayerPos.CalcMobAngle(calcObjPos, calcHitBox.y);
						}
						bool canHurt = true;
						if (hurtCheck) canHurt = nearestMob->canBeHurted();
                        if (canMobAuraDamage && canHurt) {
                            myGameMode->attack(nearestMob, true);
                            if (swing) thiz->swing();
                            canMobAuraDamage = false;
                        }
					}
                break;
                }
				case 2: {
					float nearestMobDistance = 9999;
                    for (Mob *potentialTarget : mobList) {
						if (potentialTarget != NULL) {
							vec2_t *potentialHitBox = potentialTarget->getAABBDim();
							vec2_t calcPotentialHitBox = *potentialHitBox;
							float potentialDistance = mobDistanceTo(playerPos, potentialTarget->getPosition(), calcPotentialHitBox.y);
                            if (potentialDistance < nearestMobDistance && potentialDistance <= mobAuraRange) {
                                nearestMobDistance = potentialDistance;
                                nearestMob = potentialTarget;
                            }
						}
                    }
					if (nearestMob != NULL) {
						if (rotations || targetLock) {
							vec3_t* objPos = nearestMob->getPosition();
							vec2_t *hitBox = nearestMob->getAABBDim();
                            vec3_t calcObjPos = *objPos;
							vec2_t calcHitBox = *hitBox;
                            auraAngle = globalPlayerPos.CalcMobAngle(calcObjPos, calcHitBox.y);
						}
					    for (Mob*actors : mobList) {
						    if (maxMobAuraTick > currentMobTick) {
						        currentMobTick = currentMobTick + 1;
					        } else {
								bool canHurt = true;
						        if (hurtCheck) canHurt = actors->canBeHurted();
								if (canHurt) {
									myGameMode->attack(actors, true);
					                if (swing) thiz->swing();
						            currentMobTick = 1;
								}
						    }
					    }
					}
				break;
				}
			}
		}

    if (!playerList.empty()) {
        switch (auraType) {
			case 0: {
				vec3_t* objPos = playerList[0]->getPosition();
				if (rotations || targetLock) {
                    vec3_t calcObjPos = *objPos;
                    auraAngle = globalPlayerPos.CalcPlayerAngle(calcObjPos);
				}
				if (hackDistanceTo(playerPos, objPos) <= killRange) {
					bool canHurt = true;
					if (hurtCheck) canHurt = playerList[0]->canBeHurted();
					if (canKillAuraDamage && canHurt) {
						if (!emulateNativeAttack) {
                            myGameMode->attack(playerList[0], true);
						} else {
							doHandleAttack = true;
						}
                        if (swing) thiz->swing();
                        canKillAuraDamage = false;
                    }
				}
			break;
			}
            case 1: {
                float nearestDistance = 9999;
                for (Player *potentialTarget : playerList) {
					if (potentialTarget != NULL) {
						float potentialDistance = hackDistanceTo(playerPos, potentialTarget->getPosition());
                        if (potentialDistance < nearestDistance && potentialDistance <= rotationsRange) {
                            nearestDistance = potentialDistance;
                            nearestTarget = potentialTarget;
							if (potentialDistance <= killRange) {
								nearestKillTarget = potentialTarget;
							}
                        }
					}
                }
				if (nearestTarget != NULL) {
					//inMemoryFunction = std::to_string(*(int *)((uint64_t)nearestTarget + 0x47C));
					if (rotations || targetLock) {
                        vec3_t* objPos = nearestTarget->getPosition();
                        vec3_t calcObjPos = *objPos;
                        auraAngle = globalPlayerPos.CalcPlayerAngle(calcObjPos);
					}
					if (nearestKillTarget != NULL) {
						bool canHurt = true;
					    if (hurtCheck) canHurt = nearestTarget->canBeHurted();
						if (canKillAuraDamage && canHurt) {
						    if (!emulateNativeAttack) {
                                myGameMode->attack(nearestTarget, true);
						    } else {
							    doHandleAttack = true;
						    }
                            if (swing) thiz->swing();
                            canKillAuraDamage = false;
                        }
					}
				}
            break;
			}
            case 2: {
				float nearestDistance = 9999;
                for (Player *potentialTarget : playerList) {
					if (potentialTarget != NULL) {
						float potentialDistance = hackDistanceTo(playerPos, potentialTarget->getPosition());
                        if (potentialDistance < nearestDistance && potentialDistance <= rotationsRange) {
                            nearestDistance = potentialDistance;
                            nearestTarget = potentialTarget;
							if (potentialDistance <= killRange) {
								nearestKillTarget = potentialTarget;
							}
                        }
					}
                }
				if (nearestTarget != NULL) {
					if (rotations || targetLock) {
                        vec3_t* objPos = nearestTarget->getPosition();
                        vec3_t calcObjPos = *objPos;
                        auraAngle = globalPlayerPos.CalcPlayerAngle(calcObjPos);
					}
				    if (nearestKillTarget != NULL) {
						for (Player *actors : playerList) {
							if (maxKillTick > currentKillTick) {
                                currentKillTick = currentKillTick + 1;
                            } else {
								bool canHurt = true;
						        if (hurtCheck) canHurt = actors->canBeHurted();
								if (canHurt) {
							        myGameMode->attack(actors, true);
                                    if (swing) thiz->swing();
							        currentKillTick = 1;
								}
						    }
						}
                    }
				}
            break;
			}
        }
    }
    return old_NormalTick(thiz);
}

void *(*old_PlayerAuthInputPacket)(void *a1, void *a2);
void *PlayerAuthInputPacket(void *a1, void *a2) {
	if (panic) return old_PlayerAuthInputPacket(a1, a2);
	if (!inMenu) {
		if (!isLANGame) {
		if (derp) {
		    if (derpGradys < 360) {
			    derpGradys = derpGradys + 30;
		    } else {
			    derpGradys = 0;
		    }
			#if defined(__ARM_ARCH_7A__)
			*(float *)((int)a1 + 36) = derpGradys;
			#else
			*(float *)((__int64)a1 + 48) = derpGradys;
			#endif
		}
		if (rotations) {
			if (fireballRotation || itemRotation || !mobList.empty() || !playerList.empty()) {
				#if defined(__ARM_ARCH_7A__)
				*(float *)((int)a1 + 36) = auraAngle.y;
				#else
				*(float *)((__int64)a1 + 48) = auraAngle.y;
				#endif
			}
		}
		}
	}
	return old_PlayerAuthInputPacket(a1, a2);
}

