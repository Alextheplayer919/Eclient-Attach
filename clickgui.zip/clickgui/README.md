# Apollon ClickGUI (extracted from mc-src/Apollon_Client_ImGui)

Source: app/src/main/jni/. Original author @zeff_source (no license in the zip).

| File | What it is |
|---|---|
| menu.h | The clickgui itself: `BeginDraw()` (main window, left SidePanel, 8 pages via `pageId`), `TickFunctions()` |
| dark_theme.h | `embraceTheDarkness()` – purple/black ImGui style |
| menu_utils.h | UI helpers: `BackGroundDots`, `AddNotification`/`RenderNotifications`, `ImGuiColoredText`, `CreateTextureFromMemoryPNG`, `DrawSeparatorToWindowEdge`, res scaling (+ ESP drawing helpers) |
| variables.h | Globals the widgets bind to (checkboxes/sliders) |
| hotkeys.h / RGB.h | Hotkey panel + RGB colour helper used by the menu |
| Images/ | Embedded PNG icon headers used by menu.h / menu_utils.h |
| _main_init_excerpt.txt | How main.cpp wires it up (theme init, per-frame `BeginDraw(); RenderNotifications();`) |

Pages (side panel): Movement, Combat, Building, List, Visuals, Hotkeys, Other, Info.
Needs Dear ImGui (with Android + GLES3 backends) and `OBFUSCATE` from Includes/Utils.h.
